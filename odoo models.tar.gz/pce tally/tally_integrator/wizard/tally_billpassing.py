from odoo import api, fields, models, _
import os
import requests
import time
import datetime
import json
from odoo.exceptions import UserError
from random import randrange
from odoo.http import request
import urllib
import base64
	  

class account_invoice_sendtotally(models.Model):
    _inherit = "account.invoice"
    _description = "account invoice send to tally"

    # create_by | create_date | update_by | update_date
    # Ganesh      July 2019     Ganesh      July 2019           
    # Info : This function use to send the invoice data in TallyERP9
    @api.multi
    def tally_billpass(self):   

        account_invoice_data_obj = self.env['account.invoice']
        sale_order_data_obj=self.env['sale.order']
        purchase_order_data_obj=self.env['purchase.order']
        account_invoice_line_obj = self.env['account.invoice.line']
        res_company_obj = self.env['res.company']

        compdata = res_company_obj.search([('id','=',self.env.user.company_id.id)])        
        aidata = account_invoice_data_obj.search([('number','=',self.number)])

        sale_order = sale_order_data_obj.search([('name','=',aidata.origin)])      
        ail_data = account_invoice_line_obj.search([('invoice_id','=',aidata.id)])
       
        if sale_order.partner_invoice_id.street2:
            street2 = sale_order.partner_invoice_id.street2.replace('&','&amp;')
        else:
            street2 = ''

        datestr=datetime.datetime.strptime(aidata.date_invoice, "%Y-%m-%d")         #date format come from table and then convert into custome format
        invociedate = datestr.strftime("%d-%b-%Y at %H:%M")
        dateinvoice = datestr.strftime("%Y%m%d")      
        alterid = randrange(0, 100000)       
        masterid = randrange(0, 100000)       
        headers = {"Content-type": "text/xml"}        
        # ItemTaxdtl tag for get tax details from table 
        # It is for child tax calculation
        taxdata=''
        taxdatadtl=''
        itemtaxdtl=''
        self._cr.execute("select at.ttaxname,round(at.amount,0) as rate,a.amount from account_invoice_tax a \
        inner join account_tax at on at.id=a.tax_id  where a.invoice_id =%s",(aidata.id,))
        taxdata = self.env.cr.fetchall()            
        if taxdata:
            taxdatadtl = taxdata
        else:
            # It is for IGST 18 Parent tax calculation
            self._cr.execute("select at.ttaxname,round(at.amount,0) as rate,a.amount from account_invoice_tax a \
            inner join account_tax at on at.id=a.tax_id  where a.invoice_id =%s",(aidata.id,))
            taxdatadtl = self.env.cr.fetchall()  

        for res in taxdatadtl:                
            if int(res[2]) > 0:
                itemtaxdtl+="""<LEDGERENTRIES.LIST>
                     <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
                     <LEDGERFROMITEM>No</LEDGERFROMITEM>
                     <REMOVEZEROENTRIES>No</REMOVEZEROENTRIES>
                     <ISPARTYLEDGER>No</ISPARTYLEDGER>
                     <ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE>
                     <LEDGERNAME>"""+res[0]+"""</LEDGERNAME>
                     <UDF:RATEOFINVOICETAX.LIST DESC="RATEOFINVOICETAX" ISLIST="YES">
                     <UDF:RATEOFINVOICETAX DESC="RATEOFINVOICETAX" />
                     </UDF:RATEOFINVOICETAX.LIST>
                     <AMOUNT>-"""+format(res[2])+"""</AMOUNT>
                     <TAXCLASSIFICATIONNAME />
                  </LEDGERENTRIES.LIST>
                """	
        # Sales ledger name and basic ammount get from table
        saleledger=''
        salesdata=''
        self._cr.execute("select at.tallyledgername ,sum(ail.price_subtotal) as tax_amt \
        from account_invoice_line_tax ailt \
        inner join account_invoice_line ail on ail.id=ailt.invoice_line_id and ail.invoice_id = %s \
        inner join account_tax at on at.id=ailt.tax_id where ail.price_subtotal>0 \
        group by at.tallyledgername",(aidata.id,))
        salesdata = self.env.cr.fetchall()

        if salesdata:
            for data in salesdata:
                saleledger+="""<LEDGERENTRIES.LIST>
                     <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
                     <LEDGERFROMITEM>No</LEDGERFROMITEM>
                     <REMOVEZEROENTRIES>No</REMOVEZEROENTRIES>
                     <ISPARTYLEDGER>No</ISPARTYLEDGER>
                     <ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE>
                     <LEDGERNAME>"""+data[0]+"""</LEDGERNAME>
                     <AMOUNT>-"""+format(data[1])+"""</AMOUNT>
                     <TAXCLASSIFICATIONNAME />
                     </LEDGERENTRIES.LIST>"""  
               
        # Itemhdrdata tag is header tag with  taxdatadtl and pass item under "GST Net Sale LEDGER" name wise tag

        itemhdrdata=''
        if aidata.partner_id.tcustname:           
            
            itemhdrdata="""<ENVELOPE>
                <HEADER>
                <TALLYREQUEST>Import Data</TALLYREQUEST>
                </HEADER>
                <BODY>
                <IMPORTDATA>
                <REQUESTDESC>
                <REPORTNAME>All Masters</REPORTNAME>
                <STATICVARIABLES>
                <SVCURRENTCOMPANY />
                </STATICVARIABLES>
                </REQUESTDESC>
                <REQUESTDATA>
                <TALLYMESSAGE xmlns:UDF="TallyUDF">
                <VOUCHER REMOTEID="0" VCHTYPE="Purchase" ACTION="Create">
                <DATE>"""+format(dateinvoice)+"""</DATE>
                <GUID>0</GUID>
                <PARTYNAME>"""+format(aidata.partner_id.tcustname.replace('&','&amp;'))+"""</PARTYNAME>
                <PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW>
                <VOUCHERTYPENAME>Purchase</VOUCHERTYPENAME>
                <REFERENCE>0</REFERENCE>
                <PARTYLEDGERNAME>"""+format(aidata.partner_id.tcustname.replace('&','&amp;'))+"""</PARTYLEDGERNAME>
                <BASICBASEPARTYNAME>"""+format(aidata.partner_id.tcustname.replace('&','&amp;'))+"""</BASICBASEPARTYNAME>
                <EFFECTIVEDATE>"""+format(dateinvoice)+"""</EFFECTIVEDATE>
                <NARRATION>30067266*3</NARRATION>
                <LEDGERENTRIES.LIST>
                <LEDGERNAME>"""+format(aidata.partner_id.tcustname.replace('&','&amp;'))+"""</LEDGERNAME>
                <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
                <LEDGERFROMITEM>No</LEDGERFROMITEM>
                <REMOVEZEROENTRIES>No</REMOVEZEROENTRIES>
                <ISPARTYLEDGER>Yes</ISPARTYLEDGER>
                <ISLASTDEEMEDPOSITIVE>No</ISLASTDEEMEDPOSITIVE>
                <AMOUNT>"""+format(aidata.amount_total)+"""</AMOUNT>
                <BANKALLOCATIONS.LIST />
                <BILLALLOCATIONS.LIST>
                <NAME>0</NAME>
                <BILLTYPE>New Ref</BILLTYPE>
                <TDSDEDUCTEEISSPECIALRATE>No</TDSDEDUCTEEISSPECIALRATE>
                <AMOUNT>"""+format(aidata.amount_total)+"""</AMOUNT>
                </BILLALLOCATIONS.LIST>
                </LEDGERENTRIES.LIST>
                """+saleledger+""""""+itemtaxdtl+"""<LEDGERENTRIES.LIST>
                <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
                <LEDGERFROMITEM>No</LEDGERFROMITEM>
                <REMOVEZEROENTRIES>No</REMOVEZEROENTRIES>
                <ISPARTYLEDGER>No</ISPARTYLEDGER>
                <ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE>
                <LEDGERNAME>ROUNDING OFF</LEDGERNAME>
                <UDF:RATEOFINVOICETAX.LIST DESC="RATEOFINVOICETAX" ISLIST="YES">
                <UDF:RATEOFINVOICETAX DESC="RATEOFINVOICETAX"/>
                </UDF:RATEOFINVOICETAX.LIST>
                <AMOUNT>0</AMOUNT>
                <TAXCLASSIFICATIONNAME />
                </LEDGERENTRIES.LIST>
                <UDF:REFERENCEDATE.LIST DESC="ReferenceDate" ISLIST="YES" TYPE="Date" INDEX="10000">
                <UDF:REFERENCEDATE DESC="ReferenceDate">"""+format(dateinvoice)+"""</UDF:REFERENCEDATE>
                </UDF:REFERENCEDATE.LIST>
                </VOUCHER>
                </TALLYMESSAGE>
                </REQUESTDATA>
                </IMPORTDATA>
                </BODY>
                </ENVELOPE>"""
            # Update : Create XML File for Import Invoice entry in tally
            
            full_path = os.path.realpath(__file__)
            path, filename = os.path.split(full_path)
            save_path=path.replace('wizard','download/')
            file_name=''
            if len(itemhdrdata)>1:
                file_name=format(aidata.number.replace('/',''))
                file_name=format(file_name.replace(' ','')+'.xml')                
           
            outfile = open(save_path+file_name, 'w')
            outfile.write(itemhdrdata)             
            outfile.close()                                 
            result_file = open(save_path+file_name,'rb').read()   
            self._cr.execute("select id from tally_xml_report  where name=%s",(file_name,))
            fileexist = self.env.cr.fetchall()                   
            if fileexist:
                datet = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
                self._cr.execute("update tally_xml_report set report=%s ,write_date=%s, downloadid=downloadid+1  where name=%s",(base64.encodestring(result_file),datet,file_name,))
                attach_id = fileexist[0][0]                  
            else:
                ids = self.env['tally.xml.report'].create({
                                            'name':file_name,
                                            'report':base64.encodestring(result_file)
                        })
                attach_id = ids.id                
            return {
                'name': 'Tally XML Download',
                'context': self.env.context,
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'tally.xml.report',
                'res_id':attach_id,
                'data': None,
                'type': 'ir.actions.act_window',
                'target':'new'
            }
        else:
            raise UserError(_("Please fill tally customer name in customer master")) 


