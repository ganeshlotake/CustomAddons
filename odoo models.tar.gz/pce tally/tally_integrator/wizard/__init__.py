from . import tally_connection
from . import tally_billpassing


