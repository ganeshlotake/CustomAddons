
from odoo import api, fields, models, _
from odoo.resume_parser.resume_parser.resume_parser import ResumeParser, utils
import  os, subprocess, code, glob, traceback, sys, inspect
from odoo.exceptions import UserError
import re
import base64
import textwrap
import shutil



class doc_par(models.Model):
    _name = 'doc.parsing'

    name = fields.Char(string='Name')
    DOB = fields.Char('Date of Birth')
    email = fields.Char(string='Email')
    experience = fields.Integer(string='Exp.')
    mobile_number = fields.Char(string='Mobile')
    measurable_results = fields.Char(string='Measurable')
    skills = fields.Text(string='Skills')
    tag  = fields.Char(string='Tag')
    professional = fields.Text(string='Professional')
    education =  fields.Char(string='Education')
    competencies = fields.Text(string='Competencies')
    total_experience = fields.Char(string='Total Exp.')
    uploadfile = fields.Binary('File',filters='.pdf', readonly=True)
    fname = fields.Char('File Name',store=True,size=32)
    location = fields.Text(string='Location')
    personal = fields.Text(string='Personal Details')
    designation = fields.Text(string='Designation')
    addskills = fields.Text(string='Add Skills')
    body = fields.Html('Contents', default='', sanitize_style=True, strip_classes=True)
    user_type = fields.Char('User type')

    def _get_user_id(self):         
        return  self.env.uid 
 
    current_user = fields.Many2one('res.users','Current User', default=_get_user_id)

    company_id = fields.Many2one('res.company','Company',default=lambda self: self.env.user.company_id)

   

    @api.multi
    def doc_parse(self): 
        return True

    @api.multi
    def skill(self):
        print('id',self.env.ref('doc_parser.doc_parser_skill_add_view').id)       
        return {
            'name': _('Add Skills'),
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'doc.parsing',     
            'res_id': self.id,
            'view_id': self.env.ref('doc_parser.doc_parser_skill_add_view').id,
            'target': 'new',           
            'context': {'default_skills': self.skills},            
        }

    @api.multi
    def action_add(self):  
        if self.addskills:                       
            self.skills=self.skills+','+self.addskills
            full_path = os.path.realpath(__file__)
            path, filename = os.path.split(full_path)                   
            kaywordfile = open(path.split('0/')[0]+"0/odoo/resume_parser/resume_parser/kayword.txt","a")
            kaywordfile.write(','+self.addskills) 
            kaywordfile.close() 

    @api.model
    def create(self, values): 
        # print('usrr',self.env.uid)
        full_path = os.path.realpath(__file__)
        path, filename = os.path.split(full_path) 
        save_path=''
        if values['company_id']==3:
            save_path=path.replace('models','ST/')
        elif values['company_id']==4:
            save_path=path.replace('models','SP/')

        move_path=path.replace('models','move_file/')
        doc_files = glob.glob(save_path+"*.doc")
        docx_files = glob.glob(save_path+"*.docx")
        pdf_files = glob.glob(save_path+"*.pdf")
       
        files = set(doc_files + docx_files + pdf_files )
        files = list(files)
        print ("%d files identified" %len(files))
        if len(files) >0:
                
            for f in files:
                print("Reading File %s"%f)            
                path, filename = os.path.split(f)
                resume_parser = ResumeParser(f)            
                openfile = open(f, "rb")
                readfile = openfile.read()
                result={}
                skill=''
                education=''
                designation=''
                orgnization=''
                tags=''
                result= resume_parser.get_extracted_data()               
                src = f

                if values['company_id']==3:
                    dst = f.replace('ST','STmove_file')
                    shutil.move(src,dst)
                elif values['company_id']==4:
                    dst = f.replace('SP','SPmove_file')
                    shutil.move(src,dst)               
                
                tag=[]
                profiletag=[]                
                body = ''
                c=0
                skill=",".join(str(s) for s in result['skills'])
                education = ",".join(str(s) for s in result['education'])   
                designation = ",".join(str(s) for s in result['designation'])                  
                orgnization =  result['orgnization'] 
                body = result['body']

                new_skill=[]
                for item in skill.split(','):                    
                    c = body.lower().count(item.lower())
                    n_item = item+' '+'('+ str(c) +')'
                    new_skill.append(n_item)
                    body = body.lower().replace(item.lower(),'<font style="color:rgb(255, 0, 0)">'+item.lower()+'</font>')
                    data = self.env['skill.tag'].search([])
                    for i in data:                        
                        if item in i.skill:                            
                            tag.append(i.tag)                             
                        
                tags = ",".join(str(s)+' ('+str(tag.count(s))+')' for s in set(tag)) 
                skill=",".join(str(s) for s in new_skill)
                values['name']= result['name']
                values['email']= result['email']
                values['DOB']= result['DOB']
                values['mobile_number']= result['mobile_number']
                values['total_experience']= result['total_experience']
                values['skills']=  textwrap.fill(skill, 40) 
                values['education']= education
                values['uploadfile'] = base64.encodestring(readfile)
                values['location']= result['location']
                values['designation']= textwrap.fill(designation.replace('\n\n','\n'), 50)     
                values['fname']= filename
                values['addskills']= ""
                values['body']= body      
                values['professional']= result['professional']
                values['competencies'] = orgnization
                values['personal'] = result['personal']
                values['tag'] = tags
                
                doc = super(doc_par, self).create(values)        
            return doc  
        else:
            raise UserError(_('File not found'))