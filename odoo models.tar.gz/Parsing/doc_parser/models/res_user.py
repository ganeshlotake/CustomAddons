
from odoo import models, fields, api
from odoo.exceptions import Warning

class ResUsers(models.Model):
    _inherit = 'res.users'

    user_type = fields.Selection([('ST', 'ESP-ST'),('SP', 'ESP-SP')], string='User Type')

    
    # user_stock_picking_type_ids = fields.Many2many(
    #     'stock.picking.type',
    #     'stock_picking_type_user_rel',
    #     'user_id',
    #     'stock_picking_type_id',
    #     'Allowd Stock Picking Type')
