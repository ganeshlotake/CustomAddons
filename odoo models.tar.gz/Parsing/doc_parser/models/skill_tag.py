
from odoo import api, fields, models, _
from odoo.resume_parser.resume_parser.resume_parser import ResumeParser, utils
import  os, subprocess, code, glob, traceback, sys, inspect
import re
import base64
import textwrap
import shutil



class skill_tag(models.Model):
    _name = 'skill.tag'



    tag =  fields.Char(string='Tag')
    skill = fields.Text(string='Skill')
    
