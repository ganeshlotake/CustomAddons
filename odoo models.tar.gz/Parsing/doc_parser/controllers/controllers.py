# -*- coding: utf-8 -*-
from odoo import http

# class DocParser(http.Controller):
#     @http.route('/doc_parser/doc_parser/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/doc_parser/doc_parser/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('doc_parser.listing', {
#             'root': '/doc_parser/doc_parser',
#             'objects': http.request.env['doc_parser.doc_parser'].search([]),
#         })

#     @http.route('/doc_parser/doc_parser/objects/<model("doc_parser.doc_parser"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('doc_parser.object', {
#             'object': obj
#         })