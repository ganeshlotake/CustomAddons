odoo.define('tally_integrator.location', function(require) {
    "use strict";

var base = require('web_editor.base');

// alert("hello");

base.ready().then(function() {
    
        $('.o_tally_form').on('o_tally_send', function () {
            alert("hello");
        });
    
});

});
