# -*- coding: utf-8 -*-
from odoo import http

# class CalibrationCustomModel(http.Controller):
#     @http.route('/calibration_custom_model/calibration_custom_model/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/calibration_custom_model/calibration_custom_model/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('calibration_custom_model.listing', {
#             'root': '/calibration_custom_model/calibration_custom_model',
#             'objects': http.request.env['calibration_custom_model.calibration_custom_model'].search([]),
#         })

#     @http.route('/calibration_custom_model/calibration_custom_model/objects/<model("calibration_custom_model.calibration_custom_model"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('calibration_custom_model.object', {
#             'object': obj
#         })