# -*- coding: utf-8 -*-

from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT

import logging
_logger = logging.getLogger(__name__)

maintenance_calendar_start = ''
maintenance_calendar_end   = ''

class CalibrationInstrumentTransient(models.TransientModel):
    _name        = 'calibration.instrument.transient'
    _description = 'Calibration Instruemt Transient'

    @api.model
    def _get_start_date(self):
        maintenance_calendar_start = self.env['ir.config_parameter'].sudo().get_param('maintenance.maintenance_calendar_start')
        maintenance_calendar_start += ' 00:00:00'
#        raise UserError('maintenance_calendar_start = %s' % maintenance_calendar_start)
        return datetime.strptime(maintenance_calendar_start,'%Y-%m-%d %H:%M:%S').date()

    @api.model
    def _get_end_date(self):
        maintenance_calendar_end   = self.env['ir.config_parameter'].sudo().get_param('maintenance.maintenance_calendar_end')
        maintenance_calendar_end  += ' 00:00:00'
#        raise UserError('maintenance_calendar_end = %s' % maintenance_calendar_end)
        return datetime.strptime(maintenance_calendar_end,'%Y-%m-%d %H:%M:%S').date()

    start_date = fields.Date(string="Start Date", default=lambda self: self._get_start_date())
    end_date   = fields.Date(string="End Date", default=lambda self: self._get_end_date())

    @api.multi
    def generate_schedule(self, values):
        # raise UserError('Values Received = %s' % values)
        active_ids = values['active_ids']
        date_missing = self.env['calibration.instrument'].search([('last_calibration_date', '=', False), ('id', 'in', active_ids)])
        if date_missing or len(date_missing) > 0:
            raise UserError(_('You selected some records without Last Calibration Date set. Please set all the records with appropriate values for Last Calibration Date and try again ...'))

        for id in active_ids:
            instrument = self.env['calibration.instrument'].browse(id)
            if instrument.master_instrument_flag == True:
                continue
#                raise UserError(_('Instrument: %s (%s) is a Standard Instrument. Skipping ...' % (instrument.name,id)))
            if instrument.state == 'scheduled' or instrument.schedule_ids:
                continue

            frequency = instrument.calibration_frequency
            freq_type = instrument.calibration_frequency_type
            last_date = instrument.last_calibration_date
            if freq_type == 'months':
                due_date = last_date + relativedelta(months=frequency)
            else:
                due_date = last_date + relativedelta(days=frequency)

            maintenance_calendar_start = self.start_date
            maintenance_calendar_end   = self.end_date

            while due_date < maintenance_calendar_start:

                if freq_type == 'months':
                    due_date = last_date + relativedelta(months=frequency)
                else:
                    due_date = last_date + relativedelta(days=frequency)

                last_date = due_date

            schedule_ids = []

            while (due_date >= maintenance_calendar_start and due_date <= maintenance_calendar_end):
                date1 = due_date + relativedelta(days=instrument.negative_tolerance)
                date2 = due_date + relativedelta(days=instrument.positive_tolerance)
                # name = self.env['ir.sequence'].next_by_code('calibration.schedule') or _('New')
                schedule = {
                    'instrument_id'         : instrument.id,
                    'last_calibration_date' : last_date,
                    'master_instrument_ids' : instrument.master_instrument_ids.ids[0] if instrument.master_instrument_ids else None,
                    'planner_id'            : instrument.planner_ids[0].id if instrument.planner_ids else None,
                    'business_user_id'      : instrument.business_user_ids[0].id if instrument.business_user_ids else None,
                    'qa_user_id'            : instrument.qa_user_ids[0].id if instrument.qa_user_ids else None,
                    'technician_id'         : instrument.technician_ids[0].id if instrument.technician_ids else None,
                    'due_date'              : due_date,
                    'final_date'            : due_date,
                    'bu_approval'           : False,
                    'qa_approval'           : False,
                    'from_date'             : date1,
                    'to_date'               : date2,
                    'state'                 : 'draft',
                    'bu_approval'           : 'draft',
                    'qa_approval'           : 'draft',
                }
                newid = self.env['calibration.schedule'].create(schedule)
                schedule_ids.append(newid.id)
                last_date = due_date
                if freq_type == 'months':
                    due_date = last_date + relativedelta(months=frequency)
                else:
                    due_date = last_date + relativedelta(days=frequency)

            instrument.schedule_ids = schedule_ids
            instrument.state = 'created'
            schedule_template = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_gen_sch')
            schedule_template.send_mail(instrument.id,schedule_template.id) 
            # added by ajinkya joshi on 22-06-2020
            self.env.cr.commit()
            raise UserError(_("Schedule has been Created"))
