from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT
from odoo import http
import logging
_logger = logging.getLogger(__name__)

maintenance_calendar_start = ''
maintenance_calendar_end   = ''

class CalibrationScheduleTransient(models.TransientModel):
    _name = 'calibration.schedule.transient'
    _description = 'Calibration Schedule Wizard'

    name = fields.Char('Remark')


    @api.multi
    def set_to_draft(self, values):
        active_ids = values['active_ids']
        record_set = self.env['calibration.schedule'].search([('id', 'in', active_ids), ('state', '=', 'reject')])
        record_num = len(record_set)
        for rec in record_set:
#            _logger.info('state before update = %s' % rec.state)
            rec.write({'state':'draft',
                       'rejected_remark':False})
#            _logger.info('state after update = %s' % rec.state)
        self.env.cr.commit()
#        raise UserError('Completed ...\n\nProcessed %s records!' % (record_num))
        return {'type': 'ir.actions.act_window_close'}



    # Following logic is for to make calibration order
    # updated if condition | By Yogeshwar | 09/06/2020
    @api.multi
    def create_calibration_order(self,values):
        active_ids = values['active_ids']
        calibration_schedule_object = self.env['calibration.schedule'].search([('bu_approval','=','approve'),('qa_approval','=','approve'),('id', 'in', active_ids)])
        if not calibration_schedule_object:
            raise UserError(_('You selected some records without QA and BU Approval. Please set all the records with appropriate values for QA and BU Approval and try again ...'))
        MAINTENANCE_CALENDAR_START = self.env['ir.config_parameter'].sudo().get_param("maintenance.maintenance_calendar_start")
        MAINTENANCE_CALENDAR_END   = self.env['ir.config_parameter'].sudo().get_param("maintenance.maintenance_calendar_end")
        for id in active_ids:
#            import pdb; pdb.set_trace()
            instrument = self.env['calibration.schedule'].browse(id)
            #calibration_order_object=self.env['calibration.order'].search([('instrument_id','=',instrument.instrument_id.id), ('due_date','>=', MAINTENANCE_CALENDAR_START), ('due_date', '<=', MAINTENANCE_CALENDAR_END)])
            calibration_order_object=self.env['calibration.order'].search([('instrument_id','=',instrument.instrument_id.id), ('due_date','=',instrument.due_date)])
            if calibration_order_object:
                continue
            if not calibration_order_object:
                order_no = self.env['ir.sequence'].next_by_code('calibration.order') # or 'New'
                schedule = self.env['calibration.schedule'].browse(id)
                calibration_order = {
                    'order_no'               : order_no,
                    'order_date'             : date.today(),
                    'order_description'      : '',
                    'equipment_id'           : schedule.instrument_id.equipment_id.id,
                    'location_id'            : schedule.instrument_id.location_id.id,
                    'area'                   : '',
                    'instrument_tagid'       : schedule.instrument_id.tag_id,
                    'due_date'               : schedule.due_date,
                    'calibration_date_from'  : schedule.from_date,
                    'calibration_date_to'    : schedule.to_date,
                    'calibration_date_final' : schedule.final_date,
                    'instrument_id'          : schedule.instrument_id.id,
                    'master_instrument_id'   : (schedule.master_instrument_ids.ids[0] if schedule.master_instrument_ids else False),
                    'planner_id'             : schedule.planner_id.id,
                    'technician_id'          : schedule.technician_id.id,
                    'business_id'            : schedule.business_user_id.id,
                    'qa_id'                  : schedule.qa_user_id.id,
                    # 'state'                  : 'Draft',
                    'mandate'                : schedule.instrument_id.mandate,
                    'order_type'             : 'auto',
                }
                oid = self.env['calibration.order'].create(calibration_order)
                if oid:
                    schedule.write({'state': 'order_ok'})
                    if schedule.instrument_id:                         #Added By Yogeshwar | Added On 10/06/2020
                        for ids in schedule.instrument_id:
                            if ids.accuracy_type == 'percent':          # Added By Ajinkya | Added On 12/06/2020
                                percent_value = ids.accuracy * ids.range_to / 100       # Updated by ajinkya joshi on 17-june-2020
                                if ids.calibration_master_details_line:
                                    for line in ids.calibration_master_details_line:
                                        line.high_value = line.standard_instrument_value + percent_value
                                        line.low_value = line.standard_instrument_value - percent_value
                                        add_lines = {
                                                        'characteristics': line.characteristics,
                                                        'description':line.description,
                                                        'measuring_instrument_value':line.standard_instrument_value,
                                                        'instrument_uom':line.instrument_uom.id,
                                                        'high_value':line.high_value,
                                                        'low_value':line.low_value,
                                                        'order_id': oid.id,
                                                        'standard_instrument_value': 0,
						        'observed_standard_value': 0, 
							'recompute_vals': False,
                                                        'order_id' : oid.id,
                                                    }
                                        newid = self.env['calibration.order.line']
                                        newid.create(add_lines)
                            else:
                                if ids.accuracy_type == 'absolute':
                                    absolute_value = ids.accuracy
                                    if ids.calibration_master_details_line:
                                        for line in ids.calibration_master_details_line:
                                            if line.standard_instrument_value:
                                                line.high_value = line.standard_instrument_value + absolute_value
                                                line.low_value = line.standard_instrument_value - absolute_value
                                            add_lines = {
                                                        'characteristics': line.characteristics,
                                                        'description':line.description,
                                                        'measuring_instrument_value':line.standard_instrument_value,
                                                        'instrument_uom':line.instrument_uom.id,
                                                        'high_value':line.high_value,
                                                        'standard_instrument_value': 0,
                                                        'observed_standard_value': 0, 
                                                        'low_value':line.low_value,
                                                        'order_id': oid.id,
							                            'recompute_vals': False,
                                                        'order_id' : oid.id,
                                                    }
                                        newid = self.env['calibration.order.line']
                                        newid.create(add_lines)
                create_order_template = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_create_order')
                create_order_template.send_mail(oid.id,create_order_template.id)
        self.env.cr.commit()
        raise UserError(_("Order has been Successfully Created"))


    @api.multi
    def request_schedule_approvals(self, values):
        active_ids = values['active_ids']
        context = self.env.context
        mail_obj = self.env['mail.mail']
        planner  = self.env.uid
        mail_fr2 = self.env['res.users'].browse(planner)
        mail_frm = mail_fr2.login
        mail_buu = self.env['calibration.schedule'].read_group(domain=[('id', 'in', active_ids), ('bu_approval', '=', 'draft')], fields=['business_user_id'], groupby=['business_user_id'])
        mail_qau = self.env['calibration.schedule'].read_group(domain=[('id', 'in', active_ids), ('bu_approval', '=', 'draft'), ('qa_approval', '=', 'draft')], fields=['qa_user_id'], groupby=['qa_user_id'])
        mail_sub = " Calibration Schedule Approval Request"
        baseurl  = self.env['calibration.schedule']
        if active_ids:
            calibration_ids=self.env['calibration.schedule'].search([('id','in',active_ids)])
            for i in calibration_ids:
                if not i.bu_approval == 'draft':
                    raise UserError('Please ensure bu approval should be in draft...check at your end')
                if not i.qa_approval == 'draft':
                    raise UserError('Please ensure qa approval should be in draft...check at your end')
                if not i.state == 'draft':
                    raise UserError('Please ensure state should be in draft...check at your end')
                if i:
                    i.bu_approval = 'requested'
                    i.state = 'in_approval'
                if not i.business_user_id:
                    raise UserError('Please Ensure Business User And Other Users Are Assigned')
                if not i.qa_user_id:
                    raise UserError('Please Select QA User')

        for business_user in mail_buu:
            mail_to = self.env['res.users'].browse(business_user['business_user_id'][0]).login
            body_html = """<p>Dear User,<br/>
                The calibration schedule has been sent for you review and approval.<br/>
         
                Please access the schedule at 
                <div style="text-align: center; margin: 16px 0px 16px -1046px; font-size: 14px;">
                        <a href="""+str(baseurl.get_base_url()) +"""/web?&amp;action=679&amp;model=calibration.schedule&amp;view_type=list&amp;menu_id=497" target="_blank" style="text-decoration:none;background-color: #875A7B; padding: 8px 16px 8px 16px; text-decoration: none; color: #fff; border-radius: 5px; font-size:13px;">
                            View Requested Schedule
                        </a>
                </div>
                <br/><br/>

                Regards!<br/>
                It is a system generated message,please do not reply.</p>
                """.format(http.request.httprequest)
            mail_rec = {
                    'email_from': mail_frm,
                    'email_to'  : mail_to,
                    'body_html' : body_html,
                    'subject'   : mail_sub,
                }
            mail = mail_obj.create(mail_rec)
            mail.send()
            
        for qa_user in mail_qau:
            mail_to_qa = self.env['res.users'].browse(qa_user['qa_user_id'][0]).login
            body_html = """<p>Dear User,<br/>
                The calibration schedule has been sent for you review and approval.<br/>
         
                Please access the schedule at
                <div style="text-align: center; margin: 16px 0px 16px -1046px; font-size: 14px;">
                        <a href="""+ str(baseurl.get_base_url()) +"""/web?&amp;action=690&amp;model=calibration.schedule&amp;view_type=list&amp;menu_id=497" target="_blank" style="text-decoration:none;background-color: #875A7B; padding: 8px 16px 8px 16px; text-decoration: none; color: #fff; border-radius: 5px; font-size:13px;">
                            View Requested Schedule
                        </a>
                </div> 
                <br/>

                Regards!<br/>
                It is a system generated message,please do not reply.</p>
                """.format(http.request.httprequest)
            
            
            mail_rec_qa = {
                'email_from': mail_frm,
                'email_to'  : mail_to_qa,
                'body_html' : body_html,
                'subject'   : mail_sub,
            }

            mail = mail_obj.create(mail_rec)
            mail_qa = mail_obj.create(mail_rec_qa)
            mail.send()
            mail_qa.send()

        return {'type': 'ir.actions.act_window_close'}        

    



    # Added By Yogeshwar | On 11/06/2020
    # Updated By Ajinkya Joshi On 22/06/2020
    @api.multi
    def request_approvals_for_business_user(self,values):
        active_ids = values['active_ids']
        for activeid in active_ids:
            calibration_schedule_object=self.env['calibration.schedule'].search([('id','=',activeid)])
            for buapprovals in calibration_schedule_object:
                if buapprovals.bu_approval == 'requested':
                    buapprovals.write({'bu_approval':'approve',
                                       'state':'bu_approved',
                                       'rejected_remark':self.name})
                    approve_mail_template = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_approve_bu')
                    approve_mail_template.send_mail(buapprovals.id,approve_mail_template.id)
                    break
                if buapprovals.bu_approval == 'approve':
                    raise UserError(_("These Schedule is Already Approved."))

            # Updated By Ajinkya Joshi On 22/06/2020


    @api.multi
    def request_approvals_for_qa_user(self,values):
        active_ids = values['active_ids']
        for activeid in active_ids:
            calibration_schedule_object=self.env['calibration.schedule'].search([('id','=',activeid)])
            for qaapprovals in calibration_schedule_object:
                if qaapprovals.state == 'bu_approved':
                    qaapprovals.write({'qa_approval':'approve',
                                       'state':'qa_approved',
                                        'rejected_remark':self.name})
                    approve_mail_template = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_approve_qa')
                    approve_mail_template.send_mail(qaapprovals.id,approve_mail_template.id)
                else:
                    raise UserError(_("Bad request for qu approval...bu approval status should be approved please check"))

    # Updated by ajinkya joshi on 22-06-2020
    @api.multi
    def approvals_rejection_for_bu_and_qa(self,values):
        active_ids = values['active_ids']
        for activeid in active_ids:
            calibration_schedule_object=self.env['calibration.schedule'].search([('id','=',activeid)])
            for rejection in calibration_schedule_object:
                if rejection.state == 'draft' and rejection.bu_approval == 'draft' and rejection.qa_approval == 'draft':
                    raise UserError(_("Please check selectd schedule is in draft would not recject")) 
                else:
                    res_user_obj = self.env['res.users'].search([('id','=',self.env.uid)])
                    if res_user_obj.user_role =='business':
                        if rejection.bu_approval == 'approve':
                            raise UserError(_("Cannot Reject. It is already approved."))
                    if rejection.state == 'reject':
                        raise UserError(_("You are all ready rejected please check"))
                    if rejection.bu_approval == 'requested':
                        if not self.name:
                            raise UserError(_("Please Enter Rejection Remark"))
                        rejection.write({'rejected_remark':self.name,
                                         'bu_approval':'draft',
                                         'qa_approval':'draft',
                                         'state':'reject'})
                        reject_mail_template = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_reject_bu')
                        reject_mail_template.send_mail(rejection.id,reject_mail_template.id)
                    else:
                        if rejection.state == 'bu_approved':
                            if not self.name:
                                raise UserError(_("Please Enter Rejection Remark"))
                            rejection.write({'rejected_remark':self.name,
                                             'bu_approval':'draft',
                                             'qa_approval':'draft',
                                             'state':'reject'})
                            reject_mail_template = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_reject_qa')
                            reject_mail_template.send_mail(rejection.id,reject_mail_template.id)
