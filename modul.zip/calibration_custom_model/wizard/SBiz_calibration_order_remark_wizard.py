from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT


# create_by | create_date | update_by | update_date
# Yogeshwar |  26/03/2020 |           | 
    

class CalibrationOrderRemark(models.Model):
    _name        = 'calibration.order.remark'
    _description = 'Order Remarks'

            
    remark       = fields.Text(string='Remark')
    # updated by ajinkya joshi on 19-06-2020
    status       = fields.Char(string='Action (Reject or Approve)')
    user_id      = fields.Many2one(comodel_name='res.users')
    order_id     = fields.Many2one(comodel_name='calibration.order')
    order_status         = fields.Selection(related='order_id.order_status',string="Order Status", store=True)
    # <!--Added By Ganesh 11-04-20 -->
    safety_clearance     = fields.Boolean(string="Safety Clearance taken")
    production_clearance = fields.Boolean(string="Production Clearance Taken")
    electrical_clearance = fields.Boolean(string="Electrical Clearance Taken") 
    # Added By Yogeshwar 14-04-2020
    technician_id = fields.Many2one(comodel_name='res.users', string='Technician', domain="[('user_role','=',2)]")  
    remark_date   = fields.Datetime(string='Remark Date', default=datetime.now()) 
    # Added By Yogeshwar On 09/06/2020
    clearance_date  = fields.Date(string='Clearance Date', default=date.today())
    can_be_used     = fields.Boolean(string='Can Be Used',related="order_id.can_be_used",store=True,readonly=False)
    # can_not_be_used = fields.Boolean(string='Can Not Be Used')
    boolean_flag = fields.Boolean(string="Boolean Flag", related="order_id.order_success",store=True)

    # Following Logic Is For Remark Approve And Go To Next State Of Order
    @api.multi
    def approve(self,values):
        active_id = values['active_id']
        calibartion_order_object=self.env['calibration.order'].search([('id','=',active_id)])
        if calibartion_order_object:
            template              = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_stagewise_approval')
            template_assigned     = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_for_assigned_order')
            template_preapproval  = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_for_preapproval_order') 
            template_postapproval = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_for_postapproval_order')
            template_closed       = self.env['ir.model.data'].get_object('calibration_custom_model','to_send_mail_for_closed_order')
            template_complete     = self.env['ir.model.data'].get_object('calibration_custom_model','to_send_mail_for_complete_order')
            if calibartion_order_object.order_status == 'in_process':
                calibartion_order_object_line = self.env['calibration.order.line'].search([('pass_fail','=',False),('order_id','=',calibartion_order_object.id)])
                for i in calibartion_order_object_line:
                    if i:
                        raise UserError(_("Please enter the calibration measurments"))
            
            if calibartion_order_object.order_status == 'complete':     # Added By Yogeshwar | Added On 12/06/2020
                if self.can_be_used == False:
                    calibartion_order_object.can_be_used = self.can_be_used
                    instrument_obj = self.env['calibration.instrument'].search([('id','=',calibartion_order_object.instrument_id.id)])
                    instrument_obj.write({'active':False})
                    schedule_obj = self.env['calibration.schedule'].search([('instrument_id','=',calibartion_order_object.instrument_id.id),('due_date','>',calibartion_order_object.due_date)])
                    for i in schedule_obj:
                        i.write({'state':'expired'})
                    order_obj = self.env['calibration.order'].search([('instrument_id','=',calibartion_order_object.instrument_id.id),('order_status','!=','closed')])
                    for j in order_obj:
                        j.write({'order_status':'closed'})
                        calibration_hist = {
                        'order_no':j.id,
                        'instrument_id':j.instrument_id.id,
                        'last_calibration_date': date.today(),
                        'order_status': j.order_status,
                        'remark' : self.remark,
                        'planner_id': j.planner_id.id,
                        'bu_user_id': j.business_id.id,
                        'qauser_id': j.qa_id.id,
                        'result':'Pass' if j.order_success == True else 'Fail',
                        'company_id' : j.company_id.id,
                        'equipment_id': j.equipment_id.id
                        }
                        calibration_hist_obj = self.env['calibration.maintenance']
                        calibration_hist_obj.create(calibration_hist)
                if not self.remark:
                    raise UserError(_("Please Remark"))
                # if self.can_be_used ==  False and self.can_not_be_used == False:
                #     raise UserError(_("Please Select At Least One Can Be Used Or Can Not Be Used"))
            if calibartion_order_object.order_status == 'release':     # Added By Yogeshwar | Added On 09/06/2020
                if self.clearance_date:
                    if self.clearance_date < date.today():
                        raise UserError("Clerance Date Should Be Todays Date Or Future Date")
                if not self.remark:
                    raise UserError(_("Please Eneter Remark"))
            if calibartion_order_object.order_status == 'create':
                calibartion_order_object.write({'order_status':'active'})
                template.send_mail(calibartion_order_object.id, template.id)
            elif calibartion_order_object.order_status == 'active':
                if not self.technician_id :
                    raise UserError(_("Please Assign Technician"))
                calibartion_order_object.write({'order_status':'assign'})
                calibartion_order_object.write({'technician_id':self.technician_id.id})
                template_assigned.send_mail(calibartion_order_object.id, template_assigned.id)
            elif calibartion_order_object.order_status == 'assign':
                calibartion_order_object.write({'order_status':'start'})
                template.send_mail(calibartion_order_object.id, template.id)
            elif calibartion_order_object.order_status == 'start':
                calibartion_order_object.write({'order_status':'release'})
                template.send_mail(calibartion_order_object.id, template.id)
            elif calibartion_order_object.order_status == 'release':
                if not self.safety_clearance or not self.production_clearance or not self.electrical_clearance:
                    raise UserError(_("Please check Safety, Production and Electrical Clearance"))
                calibartion_order_object.write({'order_status':'in_process'})
                template_preapproval.send_mail(calibartion_order_object.id, template_preapproval.id)
                
            #elif calibartion_order_object.order_status == 'pre_approval':                  # comment by Yogeshwar | Added On 09/06/2020
                #calibartion_order_object.write({'order_status':'in_process'})
                #template.send_mail(calibartion_order_object.id, template.id)
            elif calibartion_order_object.order_status == 'in_process':
                calibartion_order_object.write({'order_status':'complete'})
                template_complete.send_mail(calibartion_order_object.id, template_complete.id)
            elif calibartion_order_object.order_status == 'complete':
                calibartion_order_object.write({'order_status':'post_approval'})
                template_postapproval.send_mail(calibartion_order_object.id, template_postapproval.id)
            elif calibartion_order_object.order_status == 'post_approval': 
                calibartion_order_object.write({'order_status':'closed'})
                calibration_hist = {
                    'order_no':calibartion_order_object.id,
                    'instrument_id':calibartion_order_object.instrument_id.id,
                    'last_calibration_date': date.today(),
                    'order_status': calibartion_order_object.order_status,
                    'remark' : self.remark,
                    'planner_id': calibartion_order_object.planner_id.id,
                    'bu_user_id': calibartion_order_object.business_id.id,
                    'qauser_id': calibartion_order_object.qa_id.id,
                    'result':'Pass' if calibartion_order_object.order_success == True else 'Fail',
                    'company_id' : calibartion_order_object.company_id.id,
                    'equipment_id': calibartion_order_object.equipment_id.id
                }
                calibration_hist_obj = self.env['calibration.maintenance']
                calibration_hist_obj.create(calibration_hist)
                template_closed.send_mail(calibartion_order_object.id, template_closed.id)
            elif calibartion_order_object.order_status == 'unassign':
                calibartion_order_object.write({'order_status':'assign'})
                calibartion_order_object.write({'technician_id':self.technician_id.id})
                template.send_mail(calibartion_order_object.id, template.id)  
            reject_vals = {
                'remark':self.remark,
                'status':'Approve',
                'user_id':values['uid'],
                'order_id':active_id,
                'remark_date':self.remark_date
            }
            calibration_remark=self.env['calibration.order.remark']
            calibration_remark.create(reject_vals)
            remarkdata = calibration_remark.search([('user_id','=',False),('safety_clearance','=',False),('production_clearance','=',False),('electrical_clearance','=',False),('boolean_flag','=',True)])
            remarkdata.unlink()
            

    # Added By Ganesh 11-04-20
    @api.multi
    def rework(self,values):
        active_id = values['active_id']
        calibartion_order_object=self.env['calibration.order'].search([('id','=',active_id)])
        if calibartion_order_object:
            if calibartion_order_object.order_status == 'post_approval':
                calibartion_order_object.write({'order_status':'complete'})
            elif calibartion_order_object.order_status == 'complete':
                calibartion_order_object.write({'order_status':'in_process'})
            elif calibartion_order_object.order_status == 'in_process':
                calibartion_order_object.write({'order_status':'pre_approval'})
            elif calibartion_order_object.order_status == 'pre_approval':
                calibartion_order_object.write({'order_status':'release'})
            elif calibartion_order_object.order_status == 'release':
                calibartion_order_object.write({'order_status':'start'})
            elif calibartion_order_object.order_status == 'start':
                calibartion_order_object.write({'order_status':'assign'})
            elif calibartion_order_object.order_status == 'assign':
                calibartion_order_object.write({'order_status':'active'})
            elif calibartion_order_object.order_status == 'active':
                calibartion_order_object.write({'order_status':'create'})           
            reject_vals = {
                'remark':self.remark,
                'status':'Rework',
                'user_id':values['uid'],
                'order_id':active_id,
                'remark_date':self.remark_date
            }
            calibration_remark=self.env['calibration.order.remark']
            calibration_remark.create(reject_vals)
            remarkdata = calibration_remark.search([('user_id','=',False),('safety_clearance','=',False),('production_clearance','=',False),('electrical_clearance','=',False),('boolean_flag','=',True)])
            remarkdata.unlink()

        # Following Logic Is For Remark Reject And Go To Rejected Order State
    @api.multi
    def reject(self,values):
        active_id = values['active_id']
        calibartion_order_object=self.env['calibration.order'].search([('id','=',active_id)])
        if calibartion_order_object:
            reject_vals = {
                'remark':self.remark,
                'status':'Reject',
                'user_id':values['uid'],
                'order_id':active_id,
                'remark_date':self.remark_date
            }
            calibartion_order_object.write({'order_status':'rejected'})
            calibration_remark=self.env['calibration.order.remark']
            calibration_remark.create(reject_vals)
            remarkdata = calibration_remark.search([('user_id','=',False),('safety_clearance','=',False),('production_clearance','=',False),('electrical_clearance','=',False),('boolean_flag','=',True)])
            remarkdata.unlink()

         # Added By Yogeshwar Following Logic Is For Unassign User With Remark 28/04/2020
    @api.multi
    def unassign_user(self,values):
        active_id = values['active_id']
        calibartion_order_object=self.env['calibration.order'].search([('id','=',active_id)])
        if calibartion_order_object:
            unassign_user_vals = {
                'remark':self.remark,
                'status':'Unassign',
                'user_id':values['uid'],
                'order_id':active_id,
                'remark_date':self.remark_date
            }
            calibartion_order_object.write({'order_status':'unassign'})
            calibartion_order_object.write({'technician_id':False})
            calibration_remark=self.env['calibration.order.remark']
            calibration_remark.create(unassign_user_vals)
            remarkdata = calibration_remark.search([('user_id','=',False),('safety_clearance','=',False),('production_clearance','=',False),('electrical_clearance','=',False),('boolean_flag','=',True)])
            remarkdata.unlink()
