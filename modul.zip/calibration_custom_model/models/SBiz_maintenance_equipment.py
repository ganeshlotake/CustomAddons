# -*- coding: utf-8 -*-

from datetime import date, datetime, timedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT

class MaintenanceEquipmentExtended(models.Model):
    _inherit = 'maintenance.equipment'

    image                   = fields.Binary(string='Image')
    location_id             = fields.Many2one(comodel_name='maintenance.location', string='Functional Location', required=True, track_visibility='onchange')
    parent_equipment_code   = fields.Char(string="Parent Equipment Code")
    equipment_abc_indicator = fields.Selection(selection=[('a', 'A'), ('b', 'B'), ('c', 'C')], string="ABC Indicator")
    equipment_asset_code    = fields.Char(string="Asset Number")

    @api.multi
    def unlink(self):
        if self.env.uid > 2:
            raise UserError(_('You are not authorized to delete the records from Equipment Master. Please contact System Administrator.'))
        res = super(MaintenanceEquipmentExtended, self).unlink()
        return res

