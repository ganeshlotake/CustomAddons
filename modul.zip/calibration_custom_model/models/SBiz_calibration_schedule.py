
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT


# create_by | create_date | update_by | update_date
# Yogeshwar |  19/02/2020 | 29/02/2020| Yogeshwar

MAINTENANCE_CALENDAR_START = ''
MAINTENANCE_CALENDAR_END   = ''

class CalibrationSchedule(models.Model):
    _name        = 'calibration.schedule'
    _description = 'Calibration Schedule'
    _inherit     = ['mail.thread', 'mail.activity.mixin']

    @api.model
    def _get_current_user(self):
        for rec in self:
            rec.current_user = self.env.uid

    name                  = fields.Char(string="Schedule ID",readonly=True,store=True,index=True,copy=False,default=lambda self: _('New'))
    current_user          = fields.Many2one(comodel_name='res.users', compute=_get_current_user, stored=True)
    instrument_id         = fields.Many2one('calibration.instrument', string='Instrument')
    last_calibration_date = fields.Date(string='Last Calibration Date', track_visibility='onchange')
    master_instrument_ids = fields.Many2one(comodel_name='calibration.instrument', string='Master Instrument', track_visibility='onchange')
    due_date              = fields.Date(string='Due Date')
    final_date            = fields.Date(string='Final Date', track_visibility='onchange')
    planner_id            = fields.Many2one(comodel_name='res.users', string="Planner", track_visibility='onchange',  domain="[('user_role','=',3)]")  # domain=[('planner_id', 'in', instrument_id.planner_ids)], 
    technician_id         = fields.Many2one(comodel_name='res.users', string="Technician", track_visibility='onchange', domain="[('user_role','=',5)]") # , domain=[('technician_id', 'in', instrument_id.technician_ids)]
    business_user_id      = fields.Many2one(comodel_name='res.users', string="Business User", track_visibility='onchange', domain="[('user_role','=',6)]") # , domain=[('business_user_id', 'in', instrument_id.business_user_ids)]
    qa_user_id            = fields.Many2one(comodel_name='res.users', string="QA User", track_visibility='onchange', domain="[('user_role','=',7)]") # , domain=[('qa_user_id', 'in', instrument_id.qa_user_ids)]
    from_date             = fields.Date(string='From Date')
    to_date               = fields.Date(string='To Date')
    state                 = fields.Selection(selection=[
        ('draft', 'Draft'), ('in_approval', 'In Approval'), ('bu_approved', 'Business Approved'), 
        ('qa_approved', 'QA Approved'), ('reject', 'Rejected'), ('order_ok', 'Order Created'), ('expired', 'Expired')], string='Status', track_visibility='onchange')
    order_created         = fields.Selection(selection=[('created','Created'),('notcreated','Not Created')],default='notcreated')
    bu_approval          = fields.Selection(string='BU Approval',selection=[('draft','Draft'),('approve','Approved'),('requested','Requested'),('reject','Rejected')],default='draft')
    qa_approval          = fields.Selection(string='QA Approval',selection=[('draft','Draft'),('approve','Approved'),('requested','Requested'),('reject','Rejected')],default='draft')
    rejected_remark      = fields.Char(string="Remark")
    company_id           = fields.Many2one(comodel_name='res.company', string='Company / Plant', required=True, store=True, default=1)

    #added by ajinkyajoshi on 15-june-2020
    @api.model
    def create(self, vals):
        if 'instrument_id' in vals:                         
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('calibration.schedule') or _('New')
            result = super(CalibrationSchedule, self).create(vals)        

            return result

    @api.onchange('final_date')
    def validate_final_date(self):
        if self.final_date < self.from_date or self.final_date > self.to_date:
            raise UserError(_('The Final Date MUST be between From and To dates'))


    @api.multi
    def get_remark(self):
        my_remark = ''
        if self:
            if self.rejected_remark:
                my_remark = self.rejected_remark
            else:
                my_remark = ''
        return my_remark
        
    #Following logic is for to make calibration schedule of instrument
    @api.multi
    def to_get_instrument_from_calibration_instrument(self):
        calibration_instrument_obj=self.env['calibration.instrument'].search([('master_instrument_flag','=',False)])
        for instrument in calibration_instrument_obj:
            calibration_schedule_object=self.env['calibration.schedule'].search([('instrument_id','=',instrument.id)])
            if not calibration_schedule_object:
                instrument_dictionary = {
                    'instrument_id':instrument.id,
                    'calibration_frequency':instrument.calibration_frequency,
                    'master_instrument_ids':[(6,0,[i.id for i in instrument.master_instrument_ids])]
                }
                self.env['calibration.schedule'].create(instrument_dictionary)


    @api.model
    def schedule_form_action(self, values):
        active_id = values
        context = self.env.context
        return {
                'name': _('Schedule Edit Form'),
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'calibration.schedule',
                'res_id': active_id,
                'context': context,
                'view_id': self.env.ref('calibration_custom_model.calibration_schedule_editing_form').id,
                'type': 'ir.actions.act_window',
                'target':'new'
            }


    @api.multi
    def unlink(self):
        if self.env.uid > 2:
            raise UserError(_('You are not authorized to delete the records from Calibration Schedule. Please contact System Administrator.'))
        res = super(CalibrationSchedule, self).unlink()
        return res
    
    @api.multi
    def get_base_url(self):
        """When using multi-website, we want the user to be redirected to the
        most appropriate website if possible."""
        base_url =  self.env['ir.config_parameter'].sudo().get_param('web.base.url')        
        return base_url
