# -*- coding: utf-8 -*-

from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT


# create_by | create_date | update_by | update_date
# Yogeshwar |  19/02/2020 | 29/02/2020| Yogeshwar

MAINTENANCE_CALENDAR_START = ''
MAINTENANCE_CALENDAR_END   = ''

class CalibrationOrder(models.Model):
    _name = 'calibration.order'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = 'Calibration Order'
    _order = 'order_no'
    _rec_name='order_no'

    order_no               = fields.Char(string="Order No", required=True, readonly=True, index=True, copy=False, default=lambda self: _('New'))
    order_date             = fields.Date(string="Order Date", default=date.today(),required=True)
    order_description      = fields.Char(string="Order Description")
    equipment_id           = fields.Many2one(comodel_name='maintenance.equipment', string="Equipment",track_visibility='onchange', required=True)
    location_id            = fields.Many2one(comodel_name='maintenance.location', string='Functional Location',track_visibility='onchange', required=True)
    area                   = fields.Char(string="Area", track_visibility='onchange')
    due_date               = fields.Date(string="Calibration Due Date", required=True, index=True, track_visibility='onchange')
    calibration_date_from  = fields.Date(string="Calibration Date - From", required=True, index=True, track_visibility='onchange')
    calibration_date_to    = fields.Date(string="Calibration Date - To", required=True, index=True, track_visibility='onchange')
    calibration_date_final = fields.Date(string="Calibration Final Date", required=True, index=True, track_visibility='onchange')
    clearance_date         = fields.Date(string="Business Clearance Date", required=False, track_visibility='onchange')
    actual_completion_date = fields.Date(string="Actual Completion Date", required=False, track_visibility='onchange')
    instrument_id          = fields.Many2one(comodel_name='calibration.instrument', string='Instrument UUC',track_visibility='onchange', domain="[('master_instrument_flag','=',False)]", required=True)
    master_instrument_id   = fields.Many2one(comodel_name='calibration.instrument', string='Standard Instrument',track_visibility='onchange', domain="[('master_instrument_flag','=',True)]", required=True)
    instrument_description = fields.Text(string='Instrument Description')
    instrument_tagid       = fields.Char(string='Instrument Tag ID', required=True)
    order_line             = fields.One2many(comodel_name='calibration.order.line',inverse_name='order_id')
    planner_id             = fields.Many2one(comodel_name='res.users', string='Engineering Planner', default = lambda self : self.env.uid,track_visibility='onchange', domain="[('user_role', '=',3)]")
    technician_id          = fields.Many2one(comodel_name='res.users', string='Technician',track_visibility='onchange', domain="[('user_role','=',5)]")
    business_id            = fields.Many2one(comodel_name='res.users', string='Business User',track_visibility='onchange', domain="[('user_role','=',6)]")
    qa_id                  = fields.Many2one(comodel_name='res.users', string='QA User',track_visibility='onchange', domain="[('user_role','=',7)]")
    order_status           = fields.Selection(string='Status',selection=[
                                ('draft', 'Draft'), ('create', 'Create'),
                                ('active', 'Active'),('assign','Assign'),
                                ('complete','Complete'),('planner_approve','Planner Approve'),
                                ('business_approve','Business Approve'),('qa_approve','QA Approve'),('done','Done')],
                                track_visibility='onchange',default='draft')

    attachment_ids             = fields.Many2many('ir.attachment', string='Files')
    mandate               = fields.Boolean(string="Has Measuring Points?")
    clearance_date        = fields.Date(string='Clearance Date')
    order_success         = fields.Boolean(string='Measurement Success', default=True)
    order_type            = fields.Selection(string='Order Type', selection=[('manual', 'Manual'), ('auto', 'Auto-Generated')], store=True, default='manual')
    material_consumed_ids = fields.One2many(comodel_name='calibration.material_consumed',inverse_name='order_id')
    env_condition         = fields.Char('Environmental Condition')
    ambient_temp          = fields.Char('Ambient Temp')
    humidity              = fields.Char('Humidity')
    other_remarks         = fields.Char('Other Remarks')
    # added by ajinkya joshi on 18-06-2020
    company_id                      = fields.Many2one(string='Company',related="instrument_id.company_id",store=True)
    # added by ajinkya joshi on 20-06-2020
    calibration_sop                 = fields.Char(related='instrument_id.sop_number',string="Calibration Sop Number",store=True)
    op_range_from                   = fields.Float(related='instrument_id.op_range_from',string="Operation range from",store=True)
    op_range_to                     = fields.Float(related='instrument_id.op_range_to',string="Operation range to",store=True)
    calibration_frequency           = fields.Integer(related='instrument_id.calibration_frequency',string="Frequency",store=True)
    calibration_frequency_type      = fields.Selection(related='instrument_id.calibration_frequency_type',string="Frequency Type",store=True)
    calibration_approval_type       = fields.Selection(related='instrument_id.calibration_approval_type',string="Certification Type",store=True)
    negative_tolerance              = fields.Float(related='instrument_id.negative_tolerance',string="Tolerance Range From",store=True)
    positive_tolerance              = fields.Float(related='instrument_id.positive_tolerance',store=True,string='Tolerance Range To')
    abc_indicator                   = fields.Selection(related='instrument_id.abc_indicator',store=True ,string='ABC Indicator')
    accuracy                        = fields.Float(string='Accuracy',related='instrument_id.accuracy',store=True)
    accuracy_type                   = fields.Selection(string='Accuracy Type',related='instrument_id.accuracy_type',store=True)
    least_count                     = fields.Float(string='Least Count',related='instrument_id.least_count',store=True)
    range_from                      = fields.Float(string='Range From',related='instrument_id.range_from',store=True)
    range_to                        = fields.Float(string='Range To',related='instrument_id.range_to',store=True)
    uom                             = fields.Many2one(string='Unit', related='instrument_id.uom',store=True)
    remark_id                       = fields.One2many(comodel_name='calibration.order.remark',inverse_name='order_id')
    order_status                    = fields.Selection(string='Status',selection=[
                                        ('create', 'Create'),('active', 'Active'),('assign','Assign'),('start','Start'),
                                        ('release','Release'),('pre_approval','Pre-Approval'),('in_process','In Process'),
                                        ('complete','Complete'),('post_approval','Post Approval'),('closed','Closed'),('rejected','Rejected'),('unassign','Unassign'),('expired','Expired')],
                                        default='create')
    can_be_used                     = fields.Boolean(string='Can Be Used',default=True)
     # Added By Yogeshwar 14-04-2020
    #clearance_date = fields.Date(string='Clearance Date', default=date.today())
    
    
    # Added By Ajinkya Joshi on 18-06-2020
    @api.multi
    def print_label(self):
        return self.env.ref('calibration_custom_model.action_report_print_label').report_action(self,config=False)
    
    @api.multi
    def get_status(self):
        my_status =''
        if self:
            if self.order_status == 'create':
                my_status = 'Create'
            elif self.order_status == 'active':
                my_status = 'Active'
            elif self.order_status == 'assign':
                my_status = 'Assign'
            elif self.order_status == 'start':
                my_status = 'Start'
            elif self.order_status == 'release':
                my_status = 'Release'
            elif self.order_status == 'pre_approval':
                my_status = 'Pre-Approval'
            elif self.order_status == 'in_process':
                my_status = 'In-Process'
            elif self.order_status == 'complete':
                my_status = 'Complete'
            elif self.order_status == 'post_approval':
                my_status = 'Post-Approval'
            elif self.order_status == 'closed':
                my_status = 'Closed'
            elif self.order_status == 'rejected':
                my_status = 'Rejected'
            elif self.order_status == 'unassign':
                my_status = 'Un-Assign'
        return my_status
    # Added By Ajinkya Joshi on 18-06-2020
    @api.multi
    def print_calibration_report(self):
        return self.env.ref('calibration_custom_model.action_report_calibration_print').report_action(self,config=False)

    @api.constrains('order_line')
    def validate_passfail(self):
        myflag = True
        for line in self.order_line:
            if line.pass_fail == 'fail':
                myflag = False
                break
        self.order_success = myflag
        return myflag

    # Added by ajinkya joshi on 30-june-2020
    @api.multi
    def result_passfail(self):
        myflag = ''
        for line in self.order_line:
            if line.pass_fail == 'fail':
                myflag = 'Fail'
                break
            else:
                myflag = 'Pass'
        return myflag
    
    @api.multi
    def get_base_url(self):
        base = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        return base

    # Added by ajinkya joshi on 30-june-2020
    @api.onchange('calibration_date_final')
    def validate_calibration_final_date(self):
        if self.calibration_date_final < self.calibration_date_from or self.calibration_date_final > self.calibration_date_to:
            raise UserError(_('The Final Date Must be between From and To dates'))

    # added by ajinkya joshi on 23-06-2020
    @api.multi
    def _get_default_userole(self):
        res_obj = self.env['res.users'].search([('id','=',self.env.uid)])
        if res_obj:
            if res_obj.user_role == 1 or res_obj.user_role == 3 or res_obj.user_role == 4 :
                self.access_field_tech = True
            else:
                self.access_field_tech = False
    access_field_tech          = fields.Boolean(string="Access Field Tech",compute='_get_default_userole')
    
    @api.multi
    def _get_default_userole_plan(self):
        res_obj = self.env['res.users'].search([('id','=',self.env.uid)])
        if res_obj:
            if res_obj.user_role == 2 or res_obj.user_role == 3 or res_obj.user_role == 4 :
                self.access_field_plan = True
            else:
                self.access_field_plan = False
    access_field_plan          = fields.Boolean(string="Access Field Plan",compute='_get_default_userole_plan')
    

     # Added BY Yogeshwar | On 10/06/2020
    @api.multi
    def to_activate_calibration_order(self):
        calibration_order_object = self.env['calibration.order'].search([])
        for order in calibration_order_object:
            if order:
                current_date = date.today()
                if order.calibration_date_from and order.calibration_date_to:
                    if current_date >= order.calibration_date_from and current_date <= order.calibration_date_to :
                        if order.order_status == 'create':
                            order.order_status = 'active'


    # Added By Yogeshwar Chaudhari On 05/05/2020
    # To populate instrument_tag_id for respective selected instrument
    @api.multi
    @api.onchange('instrument_id')
    def to_populate_on_instrument(self):
        if self.instrument_id:
            calibration_instrument_object = self.env['calibration.instrument'].search([('id','=',self.instrument_id.id)])
            for instrument in calibration_instrument_object:
                if instrument:
                    self.instrument_tagid       = instrument.tag_id if instrument.tag_id else False
                    self.location_id            = instrument.location_id.id if instrument.location_id else False
                    self.equipment_id           = instrument.equipment_id.id if instrument.equipment_id else False
                    self.planner_id             = instrument.planner_ids[0]  if instrument.planner_ids else False
                    self.technician_id          = instrument.technician_ids[0]  if instrument.technician_ids else False
                    self.business_id            = instrument.business_user_ids[0] if instrument.business_user_ids else False
                    self.qa_id                  = instrument.qa_user_ids[0] if instrument.qa_user_ids else False
                    self.master_instrument_id   = instrument.master_instrument_ids[0] if instrument.master_instrument_ids else False


    # Added By Yogeshwar Chaudhari On 05/05/2020
    # To get standard instrument for respective selected instrument
    @api.multi
    @api.onchange('instrument_id')
    def to_get_standard_instrument_for_respective_selected_instrument(self):
        std_instrument_list=[]
        domain={}
        if self.instrument_id:
            calibration_instrument_object = self.env['calibration.instrument'].search([('id','=',self.instrument_id.id)])
            for instrument in calibration_instrument_object:
                if instrument.master_instrument_ids:
                    for standardinstrument in instrument.master_instrument_ids:
                        if standardinstrument:
                            std_instrument_list.append(standardinstrument.id)
                    domain['master_instrument_id']=[('id','in',std_instrument_list)]
                    return {'domain':domain}


    # Added By Yogeshwar Chaudhari On 05/05/2020
    # To get planner for respective selected instrument
    @api.multi
    @api.onchange('instrument_id')
    def to_get_planner_for_respective_selected_instrument(self):
        planner_list=[]                    
        domain={}
        if self.instrument_id:
            calibration_instrument_object = self.env['calibration.instrument'].search([('id','=',self.instrument_id.id)])
            for instrument in calibration_instrument_object:
                if instrument.planner_ids:
                    for pid in instrument.planner_ids:
                        if pid:
                            planner_list.append(pid.id)
                    domain['planner_id']=[('id','in',planner_list)]
                    return {'domain':domain}

    # Added By Yogeshwar Chaudhari On 05/05/2020
    # To get technician for respective selected instrument
    @api.multi
    @api.onchange('instrument_id')
    def to_get_technician_for_respective_selected_instrument(self):
        technician_list=[]                    
        domain={}
        if self.instrument_id:
            calibration_instrument_object = self.env['calibration.instrument'].search([('id','=',self.instrument_id.id)])
            for instrument in calibration_instrument_object:
                if instrument.technician_ids:
                    for tid in instrument.technician_ids:
                        if tid:
                            technician_list.append(tid.id)
                    domain['technician_id']=[('id','in',technician_list)]
                    return {'domain':domain}

    # Added By Yogeshwar Chaudhari On 05/05/2020
    # To get business user for respective selected instrument
    @api.multi
    @api.onchange('instrument_id')
    def to_get_business_user_for_respective_selected_instrument(self):
        bu_user_list=[]                    
        domain={}
        if self.instrument_id:
            calibration_instrument_object = self.env['calibration.instrument'].search([('id','=',self.instrument_id.id)])
            for instrument in calibration_instrument_object:
                if instrument.business_user_ids:
                    for buid in instrument.business_user_ids:
                        if buid:
                            bu_user_list.append(buid.id)
                    domain['business_id']=[('id','in',bu_user_list)]
                    return {'domain':domain}


    # Added By Yogeshwar Chaudhari On 05/05/2020
    # To get qa user for respective selected instrument
    @api.multi
    @api.onchange('instrument_id')
    def to_get_qa_user_for_respective_selected_instrument(self):
        qa_user_list=[]                    
        domain={}
        if self.instrument_id:
            calibration_instrument_object = self.env['calibration.instrument'].search([('id','=',self.instrument_id.id)])
            for instrument in calibration_instrument_object:
                if instrument.qa_user_ids:
                    for quid in instrument.qa_user_ids:
                        if quid:
                            qa_user_list.append(quid.id)
                    domain['qa_id']=[('id','in',qa_user_list)]
                    return {'domain':domain}


    @api.model
    def create(self, vals):
        if vals.get('order_no', _('New')) == _('New'):
            vals['order_no'] = self.env['ir.sequence'].next_by_code('calibration.order') or _('New')
        result = super(CalibrationOrder, self).create(vals)
        return result

    @api.multi
    def active_calibration_order(self):
        return self.write({'order_status':'active'})

    @api.multi
    def assigned_calibration_order(self):
        for order in self:
            if not order.planner_id:
                raise UserError(_("Please Select Engineering Planner"))
            elif not order.technician_id:
                raise UserError(_("Please Select Technician"))
            elif not order.business_id:
                raise UserError(_("Please Select Business User"))
            elif not order.qa_id:
                raise UserError(_("Please Select QA User"))
        return self.write({'order_status':'assign'})

    @api.multi
    def completed_calibration_order(self):
        return self.write({'order_status':'complete'})

    @api.multi
    def planner_approved_calibration_order(self):
        return self.write({'order_status':'planner_approve'})

    @api.multi
    def business_approved_calibration_order(self):
        return self.write({'order_status':'business_approve'})

    @api.multi
    def qa_approved_calibration_order(self):
        return self.write({'order_status':'qa_approve'})

    @api.multi
    def done_calibration_order(self):
        return self.write({'order_status':'done'})

    # Added by Ganesh, date:13-04-20 
    @api.onchange('master_instrument_id')
    def Get_orderline_data(self):
        if self.instrument_id.master_instrument_ids == self.master_instrument_id:
            idlist = []
            order_id=self.env['calibration.order'].search([('order_no','=',self.order_no )])
            masterdata = self.env['calibration.master.details'].search([('calibration_master_details_id','=',self.master_instrument_id.id)])
            for line in masterdata:
                addrow = {
                            'characteristics': line.characteristics,
                            'description':line.description,
                            'standard_instrument_value':line.standard_instrument_value,
                            'measuring_instrument_value':line.measuring_instrument_value,
                            'instrument_uom':line.instrument_uom.id,
                            'low_value': line.low_value,
                            'high_value':line.high_value,
                            'observed_standard_value':line.observed_standard_value,
                            'order_id': order_id.id,
                        }
                newid = self.env['calibration.order.line'].create(addrow)
                idlist.append(newid.id)

            self.order_line = idlist
        else:
            raise UserError(_("Master is not related to UUC Instrument"))

    @api.multi
    def unlink(self):
        if self.env.uid > 2:
            raise UserError(_('You are not authorized to delete the records from Calibration Orders. Please contact System Administrator.'))
        res = super(CalibrationOrder, self).unlink()
        return res


class CalibrationOrderLine(models.Model):
    _name = 'calibration.order.line'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = 'Calibration Order Line'
    _order = 'characteristics'

    characteristics            = fields.Char(string='Characteristics')
    description                = fields.Char(string='Description')
    standard_instrument_value  = fields.Float(string='Std Instrument Value',required=True,store=True)
    measuring_instrument_value = fields.Float(string='Measuring Point',required=True,store=True)
    instrument_uom             = fields.Many2one(comodel_name='uom.uom',string='Unit Of Measure')
    low_value                  = fields.Float(string='Low Value')
    high_value                 = fields.Float(string='High Value')
    error_value                = fields.Float(string='Error')
    pass_fail                  = fields.Selection(selection=[('pass','Pass'),('fail','Fail')],string='Pass/Fail')
    observed_standard_value    = fields.Float(string='UUC Value',required=True,store=True)
    order_id                   = fields.Many2one(comodel_name='calibration.order')
    attachment_ids             = fields.Many2many('ir.attachment', string='Files')
    mandate                    = fields.Boolean(string="Mandate", related='order_id.mandate', store=True)
    recompute_vals             = fields.Boolean(string="Re-Compute")
    company_id                 = fields.Many2one(comodel_name='res.company', string='Company / Plant',  store=True, related='order_id.company_id')


    # Added By Yogeshwar | 12/06/2020
    # updated by ajinkya joshi on 17-june-2020
    @api.onchange('observed_standard_value')
    def to_calculate_error_value(self):
        if self.observed_standard_value:
            self.error_value = self.observed_standard_value - self.measuring_instrument_value
        if self.observed_standard_value >= self.low_value and self.observed_standard_value <= self.high_value:
                self.pass_fail = 'pass'
        else:
            self.pass_fail = 'fail'

    @api.onchange('recompute_vals')
    def compute_value(self):
        if self.observed_standard_value: 
            self.error_value = self.observed_standard_value - self.measuring_instrument_value
        if self.observed_standard_value >= self.low_value and self.observed_standard_value <= self.high_value:
                self.pass_fail = 'pass'
        else:
            self.pass_fail = 'fail'

class CalibrationMaterialConsumed(models.Model):
    _name = 'calibration.material_consumed'
    _description = 'Calibration Order Material Consumed'
   
    order_id   = fields.Many2one('calibration.order')
    product_id = fields.Many2one('product.product',required=True,string='Product')
    quantity   = fields.Float('Quantity')
    remarks    = fields.Char('Remarks')
    company_id = fields.Many2one(comodel_name='res.company', string='Company / Plant',  store=True, related='order_id.company_id')
