# -*- coding: utf-8 -*-

from datetime import date, datetime, timedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT

class ResUsersExtended(models.Model):
    _inherit = 'res.users'

    # user_role  = fields.Selection(selection=[
    #     ('planner', 'Engineering Planner'), 
    #     ('technician', 'Technician'), 
    #     ('business', 'Business User'), 
    #     ('qa', 'QA User')], stored=True, required=True)
    user_role  = fields.Many2one(comodel_name="maintenance.user.role")
    maintenance_team_ids = fields.Many2many(comodel_name='maintenance.team', string='Responsible Team', 
        store=True, required=True)


    @api.constrains('user_role')
    def assign_groups_access(self):
        user_object=self.search([('id','=',self.id)])
        if  user_object:
            maintenance_user_object   = self.env['maintenance.user.role'].search([('id','=',user_object.user_role.id)])
            res_groups_object         = self.env['res.groups'].search([('name','=',maintenance_user_object.group_name)])
            if maintenance_user_object.user_role == 'Engineering Planner':
                if maintenance_user_object.group_name == 'Calibration Planner':
                    res_groups_object.users=[(4,user_object.id)]        
            elif maintenance_user_object.user_role == 'Technician':
                if maintenance_user_object.group_name == 'Calibration Technician':
                    res_groups_object.users=[(4,user_object.id)]
            elif maintenance_user_object.user_role == 'Business User':
                if maintenance_user_object.group_name == 'Calibration Business User':
                    res_groups_object.users=[(4,user_object.id)]
            elif maintenance_user_object.user_role == 'QA User':
                if maintenance_user_object.group_name == 'Calibration QA User':
                    res_groups_object.users=[(4,user_object.id)]
            
                        
            