
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT


# create_by | create_date | update_by | update_date
# Yogeshwar |  19/02/2020 | 29/02/2020| Yogeshwar

MAINTENANCE_CALENDAR_START = ''
MAINTENANCE_CALENDAR_END   = ''

class CalibrationInstrument(models.Model):
    _name = 'calibration.instrument'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = 'Instrument Master'
    _order = 'name'

    name                            = fields.Char('Instrument Name', required=True, track_visibility='onchange')
    image                           = fields.Binary(string="image", track_visibility='onchange')
    description                     = fields.Text('Description', track_visibility='onchange')
    category_id                     = fields.Many2one(comodel_name='maintenance.instrument.category', string='Instrument Category', required=True, track_visibility='onchange')
    tag_id                          = fields.Char(string='Instrument Tag ID', required=True, track_visibility='onchange')
    location_id                     = fields.Many2one(comodel_name='maintenance.location', string='Functional Location', store=True, help='Location of this Insrument', track_visibility='onchange')
    maintenance_team_ids            = fields.Many2many(comodel_name='maintenance.team', string='Responsible Team', store=True, required=True, track_visibility='onchange')
    responsible_id                  = fields.Many2one(comodel_name='res.users', string='Responsible', store=True, required=False, track_visibility='onchange')
    sop_number                      = fields.Char(string='Calibration SOP Number', track_visibility='onchange')
    accuracy                        = fields.Float(string='Accuracy', required=True,track_visibility='onchange' )
    accuracy_type                   = fields.Selection(selection=[('percent', 'Percentage'), ('absolute', 'Absolute')], default="percent", string='Accuracy Type', required=True, track_visibility='onchange')
    least_count                     = fields.Float(string='Least Count', required=True, track_visibility='onchange')
    range_from                      = fields.Float(string='Range From', required=True,track_visibility='onchange' )
    range_to                        = fields.Float(string='Range To', required=True, track_visibility='onchange')
    uom                             = fields.Many2one(comodel_name='uom.uom', string='Unit', required=True, track_visibility='onchange')
    op_range_from                   = fields.Float(string='Operation Range From', required=True, track_visibility='onchange')
    op_range_to                     = fields.Float(string='Operation Range To', required=True, track_visibility='onchange')
    calibration_ids                 = fields.One2many('calibration.maintenance', 'instrument_id', string='Calibration Details')
    calibration_frequency           = fields.Integer(string='Frequency', required=True, track_visibility='onchange')
    calibration_frequency_type      = fields.Selection(selection=[('days', 'Days'), ('months', 'Months')], default='months', string="Frequency Type", track_visibility='onchange')
    calibration_approval_type       = fields.Selection(selection=[('int', 'Internal'), ('ext', 'External')], default='int', string='Calibration Type', track_visibility='onchange')
    calibration_approver_ext        = fields.Many2one(comodel_name='res.partner', string='Certifying Agency', track_visibility='onchange')
    company_id                      = fields.Many2one('res.company', 'Company', track_visibility='onchange',store=True, default=1)
    color                           = fields.Integer('Color Index', track_visibility='onchange')
    master_instrument_flag          = fields.Boolean(string='Is Standard Instrument', track_visibility='onchange')
    calibration_master_details_line = fields.One2many(comodel_name='calibration.master.details', inverse_name='calibration_master_details_id')
    planner_ids                     = fields.Many2many(comodel_name='res.users', string='Planner',  domain=[('user_role','=',3)], required=True, store=True, track_visibility='onchange')
    technician_ids                  = fields.Many2many(comodel_name='res.users', string='Technician', store=True, domain=[('user_role','=',5)], track_visibility='onchange')
    business_user_ids               = fields.Many2many(comodel_name='res.users', string='Business User', store=True, domain=[('user_role','=',6)], track_visibility='onchange')
    qa_user_ids                     = fields.Many2many(comodel_name='res.users', string='QA User', store=True, domain=[('user_role','=',7)], track_visibility='onchange')
    master_instrument_ids           = fields.Many2many('calibration.instrument','calibration_instrument_rel','instrument_id','standard_id', string='Standard Instrument', domain="[('master_instrument_flag','=',True)]", track_visibility='onchange')
    state                           = fields.Selection(selection=[ ('created', 'Created'),
                                                                   ('scheduled', 'Scheduled'),
                                                                ], string="Status", readonly=True, index=True, default='created', track_visibility='onchange')
    last_calibration_date           = fields.Date(string='Last Calibration Date',required=True, track_visibility='onchange')
    negative_tolerance              = fields.Float(string='Tolerance Days From', track_visibility='onchange')
    positive_tolerance              = fields.Float(string='Tolerance Days To', track_visibility='onchange')
    characteristic_line             = fields.One2many(comodel_name='calibration.characteristics.master', inverse_name='calibration_id')
    attachment_line                 = fields.One2many(comodel_name='calibration.instrument.attachment', inverse_name='instrument_id')
    equipment_id                    = fields.Many2one('maintenance.equipment', 'Equipment ID', track_visibility='onchange')
    schedule_ids                    = fields.One2many(comodel_name="calibration.schedule", inverse_name="instrument_id", string="Schedule", stored=True)
    abc_indicator                   = fields.Selection(selection=[('a', 'A'), ('b', 'B'), ('c', 'C')], string="ABC Indicator", required=True, track_visibility='onchange')
    mandate                         = fields.Boolean('Has Measuring Points')
    active                          = fields.Boolean('Active',default=True)

    @api.multi
    def unlink(self):
        if self.env.uid > 2:
            raise UserError(_('You are not authorized to delete the records from Calibration Instrument. Please contact System Administrator.'))
        res = super(CalibrationInstrument, self).unlink()
        return res

    @api.onchange('category_id', 'accuracy')
    def standard_instrument_domain(self):
        res = {
            'domain': {
                'master_instrument_ids': [('master_instrument_flag', '=', True), ('category_id', '=', self.category_id.id), ('accuracy', '<=', self.accuracy)]
            }
        }
        return res

    @api.constrains('mandate')
    def validate_mandate(self):
        if self.mandate == True and not self.calibration_master_details_line:
          raise UserError('You marked the Instrument has Measuring Points but they are not entered')


    @api.onchange('positive_tolerance')
    def to_check_enter_value_ispositive(self):
        if self.positive_tolerance:
            if self.positive_tolerance < 0 :
                raise UserError(_("Please Enter Positive Value"))


    @api.onchange('negative_tolerance')
    def to_check_enter_value_isnegative(self):
        if self.negative_tolerance:
            if self.negative_tolerance > 0 :
                raise UserError(_('Please Enter Negative Value'))

        
    @api.constrains('id')
    def send_mail(self):
        template = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_create_instrument')
        template.send_mail(self.id,template.id) 
        
    @api.multi
    def write(self,vals):
        li=[]
        res = super(CalibrationInstrument,self).write(vals)
        mail_obj = self.env['mail.mail']
        mail_sub = " Instrument """+self.name +""" ID has been modified"""
        for i in self.planner_ids:
            if i:
                li.append(i.login)
        for j in li:
            #  template = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_modify_instrument')
            #  template.send_mail(i.id,template.id)
            body_html = """<p>Dear User,<br/>
                Instrument <strong>"""+self.name+"""</strong> ID has been modified <br/>
                
                Please access the Instrument"""+self.name+""" at 
                <div style="text-align: center; margin: 16px 0px 16px -1046px; font-size: 14px;">
                        <a href="""+str(self.get_base_url())+"""/web#id=${object.id}&amp;action=594&amp;model=calibration.instrument&amp;view_type=form&amp;menu_id=497" target="_blank" style="text-decoration:none;background-color: #875A7B; padding: 8px 16px 8px 16px; text-decoration: none; color: #fff; border-radius: 5px; font-size:13px;">
                            View Modified Instrument
                        </a>
                </div> for additional details.
                <br/><br/>

                Regards!<br/>
                It is a system generated message,please do not reply.</p>
                """
            mail_rec = {
                    'email_from': self.company_id.email,
                    'email_to'  : j,
                    'body_html' : body_html,
                    'subject'   : mail_sub,
                }
            mail = mail_obj.create(mail_rec)
            mail.send()
        return {'type': 'ir.actions.act_window_close'}
        
    @api.multi
    def get_base_url(self):
        base = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        return base
            
class CharacteristicsMasterDetails(models.Model):
    _name = 'calibration.characteristics.master'
    _description = 'Calibration Characteristics Master Details'
    _order = 'characteristic'

    characteristic   = fields.Char(string='Characteristics')
    value            = fields.Char(string='Values')
    calibration_id   = fields.Many2one(comodel_name='calibration.instrument')
    company_id       = fields.Many2one(comodel_name='res.company', string='Company / Plant',  store=True, related='calibration_id.company_id')


class InstrumentMasterAttachment(models.Model):
    _name = 'calibration.instrument.attachment'
    _description = 'Calibration Instrument Attachment'
    _order = 'attachment'

    name          = fields.Char(string='Name')
    instrument_id = fields.Many2one(comodel_name='calibration.instrument')
    attachment    = fields.Binary(string='Attachment', attachment="True")
    description   = fields.Char(string='Description')
    company_id    = fields.Many2one(comodel_name='res.company', string='Company / Plant',  store=True, related='instrument_id.company_id')


class Calibration(models.Model):
    _name = 'calibration.maintenance'
    _rec_name = 'instrument_id'
    _description = 'Calibration History of Instruments Master'

    
    instrument_id         = fields.Many2one(comodel_name='calibration.instrument', string='Instrument')
    order_no              = fields.Many2one('calibration.order',string='Calibration Order No')
    last_calibration_date = fields.Date('Order Calibrated On')
    order_status          = fields.Selection(string='Status',selection=[
                                        ('create', 'Create'),('active', 'Active'),('assign','Assign'),('start','Start'),
                                        ('release','Release'),('pre_approval','Pre-Approval'),('in_process','In Process'),
                                        ('complete','Complete'),('post_approval','Post Approval'),('closed','Closed'),('rejected','Rejected'),('unassign','Unassign'),('expired','Expired')])
    remark                = fields.Char('Remark')
    planner_id            = fields.Many2one('res.users',string="Planner")
    bu_user_id            = fields.Many2one('res.users',string="BU User")
    qauser_id             = fields.Many2one('res.users',string="QA User")
    order_success         =  fields.Boolean('Order Success')
    equipment_id          = fields.Many2one('maintenance.equipment',string='Master Equipment')
    result                = fields.Char('Result')
    calibration_cert      = fields.Char('Attachment') 
    # cert_no               = fields.Char('Certificate Number')
    # cert_date             = fields.Date('Certificate Date')
    # cert_file             = fields.Binary('Upload Document')
    company_id            = fields.Many2one(comodel_name='res.company', string='Company / Plant', required=True, store=True, related='instrument_id.company_id')



# create Ganesh , date 13-04-20
class CalibrationMasterDetails(models.Model):
    _name = 'calibration.master.details'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = 'Calibration Instrument Measuring Points'
    _order = 'characteristics'

    characteristics                 = fields.Char(string='Characteristics',required=True,store=True)
    description                     = fields.Char(string='Description')
    low_value                       = fields.Float(string='Low Value')
    high_value                      = fields.Float(string='High Value')
    instrument_uom                  = fields.Many2one(comodel_name='uom.uom',string='Unit Of Measure', related='calibration_master_details_id.uom', store=True)
    calibration_master_details_id   = fields.Many2one(comodel_name='calibration.instrument', track_visibility='onchange')
    error_value                     = fields.Float(string='Error')
    standard_instrument_value       = fields.Float(string='Measuring Point',required=True,store=True)
    measuring_instrument_value      = fields.Float(string='Measuring Instrument Value')
    pass_fail                       = fields.Selection(selection=[('pass','Pass'),('fail','Fail')],string='Pass/Fail')
    company_id                      = fields.Many2one(comodel_name='res.company', string='Company / Plant',  store=True, related='calibration_master_details_id.company_id')

    @api.onchange('standard_instrument_value')
    def Get_low_high_value(self):
        if self.standard_instrument_value:
            self.low_value = self.standard_instrument_value - float(self.calibration_master_details_id.accuracy)
            self.high_value = self.standard_instrument_value + float(self.calibration_master_details_id.accuracy)
        if self.standard_instrument_value:
            for order in self:
                if order.standard_instrument_value >= order.calibration_master_details_id.range_from and order.standard_instrument_value <= order.calibration_master_details_id.range_to:
                    pass
                else:
                    raise UserError(_("Please Enter the Measuring Point Between Instrument Range From and Range To"))

    # Added By Ajinkya Joshi , On 16/06/2020
    @api.onchange('instrument_uom')
    def check_instrument_uom(self):
        if self:
            for order in self:
                if order.calibration_master_details_id.uom:
                    if order.instrument_uom:
                        if order.instrument_uom == order.calibration_master_details_id.uom:
                            pass
                        else:
                            raise UserError(_("Please Select The UoM Same as Instrument Uom"))



class InstrumentCategory(models.Model):
    _name = 'maintenance.instrument.category'
    _description = 'Instrument Category Master'

    name        = fields.Char('Instrument Category', required=True)
    description = fields.Text('Description')
    company_id  = fields.Many2one(comodel_name='res.company', string='Company / Plant', store=True, default=1)


class UserRoleMasters(models.Model):
    _name        = 'maintenance.user.role'
    _description = 'User Role Master'
    _rec_name    = 'user_role'

    user_role    = fields.Char(string="User Role")
    group_name   = fields.Char(string="Group Name")
    menus        = fields.Char(string="Menus")
    company_id   = fields.Many2one(comodel_name='res.company', string='Company / Plant', required=True, store=True, default=1)


    @api.model
    def create(self, values):
        if values:
            if values['group_name'] not in ['Calibration Planner','Calibration Technician','Calibration Business User','Calibration QA User']: 
                raise UserError(_("Please Used Group Name As Calibration Planner or Calibration Technician or Calibration Business User or Calibration QA User"))
            elif values['user_role'] not in ['Engineering Planner','Technician','Business User','QA User']:
                raise UserError(_("Please Assign User Role As Engineering Planner or Technician or Business User or QA User")) 
            res = super(UserRoleMasters, self).create(values)
            return res

    # # Added By Yogeshwar | 03/07/20202
    # @api.constrains('group_name')
    # def check_group(self):
    #     if self.group_name:
    #         if self.group_name not in ['Calibration Planner','Calibration Technician','Calibration Business User','Calibration QA User']:
    #             raise UserError(_("Please Used Group Name As Calibration Planer or Calibration Technician or Calibration Business User or Calibration QA User"))

    
    # Added By Yogeshwar | 03/07/20202
    # @api.constrains('user_role')
    # def check_user_role(self):
    #     if self.user_role:
    #         if self.user_role not in ['Engineering Planner','Technician','Business User','QA User']:
    #             raise UserError(_("Please Assign User Role As Engineering Planner or Technician or Business User or QA User"))

