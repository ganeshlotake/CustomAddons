# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------------------------------#
#   Module Name:    SBiz_plant_maintenance                                                                       #
#   Description:    Collective Single Module for eCommerce related functionality                    #
#   File Name:      sbiz_config_settings.py (/models)                                               #
#   Purpose:        The model / classes to extend the Settings / Configurations for the eCom system #
#                   to accommodate addtional setting values that are needed for SBiz_ecom module    #
#   Author:         Jayant Bulbule                                                                  #
#   Date Created:   19-Mar-2020                                                                     #
#   Last Modified:  --/--/----                                                                      #
#   Last Mod. By:                                                                                   #
#---------------------------------------------------------------------------------------------------#

#---------------------------------------------------------------------------------------------------#
#                                   Modification History                                            #
#---------------------------------------------------------------------------------------------------#
#  Date        Modified By          Purpose                                           Change Mark   #
#  ----------  -------------------  -----------------------------------------------   ------------- #
#                                                                                                   #
#                                                                                                   #
#                                                                                                   #
#---------------------------------------------------------------------------------------------------#

from odoo import models, fields,api, _
import logging
from datetime import datetime,date,timedelta
from dateutil.relativedelta import relativedelta
_logger = logging.getLogger(__name__)


class ResConfigSettings(models.TransientModel):

    _inherit = 'res.config.settings'

    maintenance_calendar_start = fields.Char(
        string='Maintenance Calendar Start Date', 
        config_parameter='maintenance.maintenance_calendar_start',
        placeholder='yyyy-mm-dd',
        help='Enter the Start Date for the Maintenance Calendar Year in your company.',
        required=True)
    maintenance_calendar_end   = fields.Char(
        string='Maintenance Calendar End Date', 
        config_parameter='maintenance.maintenance_calendar_end',
        placeholder='yyyy-mm-dd',
        help='Enter the Last Date for the Maintenance Calendar Year in your company.',
        required=True)

    # @api.onchange('maintenance_calendar_start')
    # def set_end_date(self):
    #     if self.maintenance_calendar_start:
    #         self.maintenance_calendar_end = self.maintenance_calendar_start + relativedelta(years=1) - relativedelta(days=1)

    # @api.onchange('maintenance_calendar_end')
    # def set_start_date(self):
    #     if self.maintenance_calendar_end:
    #         self.maintenance_calendar_start = self.maintenance_calendar_end - relativedelta(years=1) + relativedelta(days=1)

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res.update(
            maintenance_calendar_start = self.env['ir.config_parameter'].sudo().get_param('maintenance.maintenance_calendar_start'),
            maintenance_calendar_end   = self.env['ir.config_parameter'].sudo().get_param('maintenance.maintenance_calendar_end')
        )
        return res
    
    def set_values(self):
        super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param('maintenance.maintenance_calendar_start', self.maintenance_calendar_start)
        self.env['ir.config_parameter'].sudo().set_param('maintenance.maintenance_calendar_end',   self.maintenance_calendar_end)

