# -*- coding: utf-8 -*-
{
    'name': "SBiz Calibration",

    'summary': """
        SBiz Calibration is a submodule of the main Plant Maintenance Module by SynerBize,
        The Plant Maintenance Module provides for functionalities of Calibration,
        Preventive Maintenance, Facilities Maintenance and Break-Down Maintenance.
        """,

    'description': """
        This module is part of the SBiz Plant Maintenance Module. It provides
        for the facilities to manage the activities pertaining to calibration
        of instruments in the factories such as Pharma, Food, Engineering, etc.

        With this module the business can track all their measuring instrument,
        their respective master or standard instruments and measurements taken
        on the Instruments Under Calibration or Units Under Calibration (UUC)
        and validate them against the 'Standard' Instruments.

        The module provides for the appropriate workflow management.
    """,

    'author': "SynerBize, Inc. (hello@synerbize.com)",
    'website': "https://www.synerbize.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/12.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Maintenance',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base', 'maintenance','hr_maintenance', 'mail','portal'],
    
    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'security/calibration_security_group.xml',
        
        # Views
        'views/sbiz_config_settings.xml',
        'wizard/SBiz_calibration_order_remark_wizard_view.xml',
        'views/SBiz_calibration_schedule_view.xml', 
        'views/SBiz_calibration_order_views.xml',  
        'views/SBiz_calibration_instrument_views.xml',
        'views/sbiz_maintenance_location_view.xml', 
        'views/sbiz_calibration_menu.xml',
        'views/SBiz_res_users_view.xml',
        'views/SBiz_maintenance_equipment_views.xml',
        'views/SBiz_email_templates.xml',
        # Wizard
        'wizard/SBiz_calibration_wizard_view.xml',   
        'wizard/SBiz_order_creation_wizard_view.xml',
               
        # Report added by ajinkya joshi on 18-june-2020
        'reports/print_label_main_menu.xml',
        'reports/report_label_doc.xml',
        'reports/label_header_footer.xml',
        'reports/calibration_report_doc.xml',
        'reports/calibration_report_header_footer.xml',        
    ],  
}
