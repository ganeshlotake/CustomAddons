# -*- coding: utf-8 -*-

from . import main
from . import fmcg_portal
