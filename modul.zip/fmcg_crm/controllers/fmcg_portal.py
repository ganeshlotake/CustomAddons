# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

# from odoo.addons.portal.controllers.mail import _message_post_helper
from odoo.exceptions import AccessError, MissingError
from odoo.addons.payment.controllers.portal import PaymentProcessing
from odoo.addons.portal.controllers.mail import _message_post_helper

from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager, get_records_pager
# from odoo.osv import expression
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo import http
from odoo.http import request


class CustomerPortal(CustomerPortal):

    CustomerPortal.MANDATORY_BILLING_FIELDS.remove('city')
    CustomerPortal.MANDATORY_BILLING_FIELDS.extend(["city_id", "suburb_id", "area_id"])
    CustomerPortal.OPTIONAL_BILLING_FIELDS.extend(['city', "society", "building", "flat_no"])

    def _prepare_portal_layout_values(self, context=None):
        values = super(CustomerPortal, self)._prepare_portal_layout_values()
        partner = request.env.user.partner_id

        SaleOrder = request.env['account.invoice.packing_items'].search([('invoice_id.partner_id', '=', partner.id)])

        mycount = 0
        mysum = 0
        my_ids = []
        for line in SaleOrder:
            if line.qty_used - line.qty_return > 0.00:
                my_ids.append(line.id)
                mycount += 1
                mysum += (line.qty_used - line.qty_return)

        SaleOrder = request.env['account.invoice.packing_items'].browse(my_ids)

        values.update({
            # 'pack_count': SaleOrder
            'pack_count': mycount,
            'packing_sum': mysum,
        })

        cities  = request.env['res.city'].sudo().search([])
        suburbs = request.env['geographies.suburbs'].sudo().search([])
        areas   = request.env['geographies.areas'].sudo().search([])
        countries = request.env['res.country'].sudo().search([])
        states    = request.env['res.country.state'].sudo().search([])

        values.update({
            'cities': cities,
            'suburbs': suburbs,
            'areas': areas,
            'countries': countries,
            'states': states,
        })

        return values

    @http.route('/my/packs', type='http', auth="user", website=True)
    def portal_my_packs(self, order_id=None, access_token=None, **kwargs):
        values = self._prepare_portal_layout_values()
        partner = request.env.user.partner_id
        SaleOrder = request.env['account.invoice.packing_items'].search([('invoice_id.partner_id', '=', partner.id)])
        pack_details = request.env['account.invoice.packing_items'].search([('invoice_id.partner_id', '=', partner.id)])

        values.update({
            'my_details': pack_details,
            'page_name': 'pack',
            'default_url': '/my/packs',
        })
        return request.render('fmcg_crm.portal_my_packing', values)

    def compute_bal(self, qty_used=0, qty_return=0):
        return (qty_used - qty_return)


    @http.route('/my/ledger', type='http', auth="user", website=True)
    def portal_my_ledger(self, order_id=None, access_token=None, **kwargs):
        values = self._prepare_portal_layout_values()
        partner = request.env.user.partner_id
        query = """ SELECT "account_move_line".date, j.code, acc.code as a_code,
                "account_move_line".ref, "account_move_line".debit,
                "account_move_line".credit
                FROM "account_move" as "account_move_line__move_id","account_move_line"
                LEFT JOIN account_journal j ON ("account_move_line".journal_id = j.id)
                LEFT JOIN account_account acc ON ("account_move_line".account_id = acc.id)
                LEFT JOIN res_currency c ON ("account_move_line".currency_id=c.id)
                LEFT JOIN account_move m ON (m.id="account_move_line".move_id)
                WHERE "account_move_line".partner_id = """+ str(partner.id)  +"""
                AND m.state IN ('posted' )
                AND "account_move_line".account_id IN (3)
                AND ("account_move_line"."move_id"="account_move_line__move_id"."id")
                AND (((("account_move_line"."journal_id" in (1,2,3,4,5,6,7,8,9,10,11,12,14,15,16)))
                AND  ("account_move_line__move_id"."state" = 'posted'))
                AND  ("account_move_line"."company_id" = 1))
                AND ("account_move_line"."company_id" IS NULL   OR  ("account_move_line"."company_id" in (1))) 
                AND "account_move_line".full_reconcile_id IS NULL
                ORDER BY "account_move_line".date
                """
        request.env.cr.execute(query)
        res = request.env.cr.dictfetchall()
        sum = 0.0
        full_account=[]
        mycount =0
        for r in res:
            mycount += 1
            sum += r['debit'] - r['credit']
            r['progress'] = sum
            full_account.append(r)


        values.update({
            'ledger_count':mycount,
            'my_details': full_account,
            'page_name': 'ledger',
            'default_url': '/my/ledger',
        })
        return request.render('fmcg_crm.portal_my_ledger', values)

