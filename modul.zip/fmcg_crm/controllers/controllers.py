# -*- coding: utf-8 -*-
import logging
import werkzeug
from odoo import http, _
from odoo.addons.auth_signup.controllers.main import AuthSignupHome
from odoo.addons.auth_signup.models.res_users import SignupError
from odoo.addons.website_sale.controllers.main import WebsiteSale
from odoo.exceptions import UserError
from odoo.http import request

_logger = logging.getLogger(__name__)


class website_yenth(WebsiteSale):

    @http.route(['/shop/extra_add_color'], type='http', auth="public", website=True)
    def add_color(self, **post):
        if post.get('color'):
            color = post.get('color')
#            cr, uid, context, pool = request.cr, request.uid, request.context, request.registry
            self.env['sale.colorpicker'].create({'name': color, 'website_publish': True})
            return request.make_response("<h1> Color : %s added ...</h1>" % color)
        return request.make_response("<h1> Color param missing...</h1>")

    @http.route(['/shop/extra'], type='http', auth="public", website=True)
    def extra(self, **post):
#        cr, uid, context, pool = request.cr, request.uid, request.context, request.registry
        order = request.website.sale_get_order()

        if post:
            if post.get('color'):
                order.write({'color': int(post.get('color'))})
            for line in order.order_line:
                line.write({
                    'isGift': bool(post.get('%s-%s' % (line.id, 'gift'))),
                    'numberOfUnits': int(post.get('%s-%s' % (line.id, 'qty')))
                })
            request.session['extra_info_done'] = True
            return request.redirect("/shop/checkout")
        color_ids = self.env['sale.colorpicker'].search([('website_publish', '=', True)])
        colors = self.env['sale.colorpicker'].browse(color_ids)
        values = dict(order=order, colors=colors)
        return request.render("ecom_yenth.extra", values)

    @http.route(['/shop/confirm_order'], type='http', auth="public", website=True)
    def confirm_order(self, **post):
        if not request.session.get('extra_info_done'):
            return request.redirect("/shop/extra")
        return super(website_yenth, self).confirm_order(**post)
