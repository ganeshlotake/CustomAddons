odoo.define('fmcg_crm.signup', function (require) {
    'use strict';

//        var base = require('web_editor.base');
        require('web.ajax');
        alert('I am in the function!');

        $(document).ready(function() {
            'use strict';
            $(".form-group > select.form-control").change(function(ev) {
                alert('Entered the document function thru ajax');
                var e = document.getElementsByName("city_id");
                var strUser = e.options[e.selectedIndex].text;
                var intUser = e.options[e.selectedIndex].value;
                var intIndex = e.selectedIndex - 1; // parseInt(strUser.substring(1,strUser.indexOf(')')))
                if (intIndex >= 1) {
                    var select = $("select[name='suburb_id']");
                    alert(suburb_options.val());
                    suburb_options.detach();
                    var displayed_suburb = suburb_options.filter("[data-city_id="+($(this).val() || 0)+"]");
                    var nb = displayed_suburb.appendTo(select).show().size();
                    select.parent().toggle(nb>=1);
                };
                $('.o_signup_fields').find("select[name='city_id']").change();
    
        });
    
        })
        
        // if (!$('.o_signup').length) {
        //     alert("SignUp DOM does not contain '.oe_signup_form'")
        //     return $.Deferred().reject("SignUp DOM doesn't contain '.oe_signup_form'");
        // }

        // if ($('.o_signup_fields').length) {
        //     alert('SignUp Entered the IF block!');
        //     var suburb_options = $("select[name='suburb_id']:enabled option:not(:first)");
        //     $('.o_signup_fields').on('change', "select[name='city_id']", function () {
        //         var select = $("select[name='suburb_id']");
        //         alert(suburb_options.val());
        //         suburb_options.detach();
        //         var displayed_suburb = suburb_options.filter("[data-city_id="+($(this).val() || 0)+"]");
        //         var nb = displayed_suburb.appendTo(select).show().size();
        //         select.parent().toggle(nb>=1);
        //     });
        //     $('.o_signup_fields').find("select[name='city_id']").change();
        // }

        // if ($('.o_signup_fields').length) {
        //     var area_options = $("select[name='area_id']:enabled option:not(:first)");
        //     $('.o_signup_fields').on('change', "select[name='suburb_id']", function () {
        //         var select = $("select[name='area_id']");
        //         area_options.detach();
        //         var displayed_area = area_options.filter("[data-suburb_id="+($(this).val() || 0)+"]");
        //         var nb = displayed_area.appendTo(select).show().size();
        //         select.parent().toggle(nb>=1);
        //     });
        //     $('.o_signup_fields').find("select[name='suburb_id']").change();
        // }
});
