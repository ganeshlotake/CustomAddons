odoo.define('fmcg_crm.geographies', function (require) {
    'use strict';
    
        require('web.dom_ready');
    
    
        if (!$('.o_geographies').length) {
            return $.Deferred().reject("DOM doesn't contain '.o_geographies'");
        }
    
        if ($('.o_geographies_details').length) {
            var state_options = $("select[name='state_id']:enabled option:not(:first)");
            $('.o_geographies_details').on('change', "select[name='country_id']", function () {
                var select = $("select[name='state_id']");
                state_options.detach();
                var displayed_state = state_options.filter("[data-country_id="+($(this).val() || 0)+"]");
                var nb = displayed_state.appendTo(select).show().size();
                select.parent().toggle(nb>=1);
            });
            $('.o_geographies_details').find("select[name='country_id']").change();
        }
    
        if ($('.o_geographies_details').length) {
            var suburb_options = $("select[name='suburb_id']:enabled option:not(:first)");
            $('.o_geographies_details').on('change', "select[name='city_id']", function () {
                var select = $("select[name='suburb_id']");
                state_options.detach();
                var displayed_suburb = suburb_options.filter("[data-city_id="+($(this).val() || 0)+"]");
                var nb = displayed_suburb.appendTo(select).show().size();
                select.parent().toggle(nb>=1);
            });
            $('.o_geographies_details').find("select[name='city_id']").change();
        }

        if ($('.o_geographies_search_panel').length) {
            $('.o_geographies_search_panel .search-submit').click(function () {
                var search = $.deparam(window.location.search.substring(1));
                search.search_in = $(".o_geographies_search_panel .dropdown-item.active").attr("href").replace("#","");
                search.search = $(".o_geographies_search_panel input[name='search']").val();
                window.location.search = $.param(search);
            });
    
            $('.o_geographies_search_panel .dropdown-menu').find('.dropdown-item').click(function (e) {
                e.preventDefault();
                $(this).parents('.dropdown-menu').find('.dropdown-item').removeClass('active');
                $(this).closest('.dropdown-item').addClass('active');
                var label = $(this).clone();
                label.find('span.nolabel').remove();
                $(".o_geographies_search_panel span#search_label").text(label.text());
            });
            // init search label
            $('.o_geographies_search_panel .dropdown-menu').find('.dropdown-item.active').trigger('click');
    
            $(".o_geographies_search_panel input[name='search']").on('keyup', function (e) {
                if (e.keyCode === 13) {
                   $('.o_geographies_search_panel .search-submit').trigger('click');
                }
            });
        }

    });
    