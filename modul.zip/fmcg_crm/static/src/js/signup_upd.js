odoo.define('auth_signup.signup', function (require) {
    'use strict';

    var base = require('web_editor.base');

    base.ready().then(function() {

    if (!$('.oe_signup_form').length) {
        alert("Signup Form does not contain '.oe_signup_form'")
        return $.Deferred().reject("Signup Form doesn't contain '.oe_signup_form'");
    };

    if ($('.oe_signup_form').length) {
//        console.log('Entered the IF block! (' + $('.oe_signup_form').length , ')');
//        alert('Entered the IF block!');
        var suburb_options = $("select[name='suburb_id']:enabled option:not(:first)");
//        console.log('suburb_options = ' + suburb_options.val());
        $('.oe_signup_form').on('change', function () {
//            console.log('current selected city_id = ' , $("select[name='city_id']"));
            var select = $("select[name='suburb_id']");
//            console.log('select = ' + select.val());
//            alert(suburb_options.val());
            suburb_options.detach();
//            console.log('suburb_options = ' + suburb_options.val() + ' $(this) = ' + $("select[name='city_id']").val());
            var displayed_suburb = suburb_options.filter("[data-city_id="+($("select[name='city_id']").val() || 0)+"]");
            var nb = displayed_suburb.appendTo(select).show().size();
//            console.log('nb = ' + nb);
            // select.parent().toggle(nb>=1);
        });
        $('.oe_signup_form').find("select[name='city_id']").change();
    };

    var base = require('web_editor.base');
    alert('Hey! Hey!! Hey!!! ...');

    base.ready().then(function() {

    if (!$('.oe_signup_form').length) {
        alert("Signup Form does not contain '.oe_signup_form'")
        return $.Deferred().reject("Signup Form doesn't contain '.oe_signup_form'");
    };

    if ($('.oe_signup_form').length) {
        console.log('Entered the IF block! (' + $('.oe_signup_form').length , ')');
        alert('Entered the IF block!');
        var area_options = $("select[name='area_id']:enabled option:not(:first)");
        console.log('area_options = ' + area_options.val());
        $('.oe_signup_form').on('change', "select[name='suburb_id']", function () {
            console.log('current selected suburb_id = ' , $("select[name='suburb_id']"));
            var select = $("select[name='area_id']");
            console.log('select = ' + select.val());
            alert(area_options.val());
            area_options.detach();
            console.log('AREA_options = ' + area_options.val() + ' $(this) = ' + $("select[name='suburb_id']").val());
            var displayed_area = area_options.filter("[data-suburb_id="+($(this).val() || 0)+"]");
            var nb = displayed_area.appendTo(select).show().size();
            console.log('nb = ' + nb);
            // select.parent().toggle(nb>=1);
        });
        $('.oe_signup_form').find("select[name='suburb_id']").change();
    };
});
});
});
