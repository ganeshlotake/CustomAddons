odoo.define('fmcg_crm.my_alert', function(require, msgstr) {"uses strict" ;
	alert(msgstr)
});
