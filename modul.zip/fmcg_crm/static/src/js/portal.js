odoo.define('fmcg_crm.portal', function (require) {
    'use strict';

        require('web.dom_ready');

        if (!$('.o_portal').length) {
//            alert("DOM does not contain '.o_portal'")
            return $.Deferred().reject("DOM doesn't contain '.o_portal'");
        }

        if ($('.o_portal_details').length) {
//            alert('Entered the IF block!');
            var suburb_options = $("select[name='suburb_id']:enabled option:not(:first)");
            $('.o_portal_details').on('change', "select[name='city_id']", function () {
                var select = $("select[name='suburb_id']");
//                alert(suburb_options.val());
                suburb_options.detach();
                var displayed_suburb = suburb_options.filter("[data-city_id="+($(this).val() || 0)+"]");
                var nb = displayed_suburb.appendTo(select).show().size();
                // select.parent().toggle(nb>=1);
            });
            $('.o_portal_details').find("select[name='city_id']").change();
        }

        if ($('.o_portal_details').length) {
            var area_options = $("select[name='area_id']:enabled option:not(:first)");
            $('.o_portal_details').on('change', "select[name='suburb_id']", function () {
                var select = $("select[name='area_id']");
                area_options.detach();
                var displayed_area = area_options.filter("[data-suburb_id="+($(this).val() || 0)+"]");
                var nb = displayed_area.appendTo(select).show().size();
                // select.parent().toggle(nb>=1);
            });
            $('.o_portal_details').find("select[name='suburb_id']").change();
        }

    });

