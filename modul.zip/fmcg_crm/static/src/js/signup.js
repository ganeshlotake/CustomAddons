odoo.define('auth_signup.signup', function (require) {
    'use strict';

var base = require('web_editor.base');

base.ready().then(function() {
    alert('Hey! I am actually here ...');
    $(".form-group > select.form-control").on('change', function(ev) {
        alert('Entered the document function thru ajax');
        var e = document.getElementsByName("city_id");
        var strUser = e.options[e.selectedIndex].text;
        var intUser = e.options[e.selectedIndex].value;
        var intIndex = e.selectedIndex - 1; // parseInt(strUser.substring(1,strUser.indexOf(')')))
        alert('Data = strUser intUser intIndex' + strUser + ' ' + intUser + ' ' + intIndex);
        if (intIndex >= 1) {
            var select = $("select[name='suburb_id']");
            alert(suburb_options.val());
            suburb_options.detach();
            var displayed_suburb = suburb_options.filter("[data-city_id="+($(this).val() || 0)+"]");
            var nb = displayed_suburb.appendTo(select).show().size();
            select.parent().toggle(nb>=1);
        };
        $('.oe_signup_form').find("select[name='city_id']").change();
    });
    // Disable 'Sign Up' button to prevent user form continuous clicking
    if ($('.oe_signup_form').length > 0) {
        alert('Hey! I am inside IF condition ...');
        $('.oe_signup_form').on('change', function (ev) {
            var $form = $(ev.currentTarget);
            var $btn = $form.find('.oe_login_buttons > button[type="submit"]');
            $btn.attr('disabled', 'disabled');
            $btn.prepend('<i class="fa fa-refresh fa-spin"/> ');
        });
};

});
});