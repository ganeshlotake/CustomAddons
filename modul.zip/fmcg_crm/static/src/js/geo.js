odoo.define('fmcg_crm.getlocation', function (require)
{
	"use strict";
	if (navigator.geolocation) 
	{
		navigator.geolocation.getCurrentPosition(success);
		var lat = position.coords.latitude;
		var lon = position.coords.longitude;
		var values = [lat, lon];
		return values;
	}
	else
	{
		alert("Geolocation is not supported by this browser.");
	}
}

function success(position)
{
	alert('GPS Coordinates Successfully Read!')
}


events: {
    "click .gps_click": "getlocation",
},
your_function: function () {
    console.log('Button Clicked')
},