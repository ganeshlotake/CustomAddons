# -*- coding: utf-8 -*-
from odoo import models,fields,api,_
from datetime import datetime, timedelta, date, time, timezone
from odoo.exceptions import UserError,ValidationError
from itertools import groupby


class PackingListWizard(models.TransientModel):
    _name = "unreturned.materials.wizard"

    unreturned_material_date_from = fields.Date(string='UnReturned Material From', required=True, default=lambda self: date.today())
    unreturned_material_date_to   = fields.Date(string='UnReturned Material To  ', required=True, default=lambda self: date.today())
    company_id                    = fields.Many2one(comodel_name='res.company', 
        string='Company', store=True, readonly=True, default=lambda self: self.env.user.company_id, required=True)
    groupby                       = fields.Selection(selection=[('customer', 'Customer'), ('delivered', 'Delivered By'), ('product', 'Products'), ('none', 'Simple List')], string='Group By', required=True)
    groupby_customer_ids          = fields.Many2many(comodel_name='res.partner', domain=[('customer', '=', True)], string='Choose Customers')
    groupby_delivery_ids          = fields.Many2many(comodel_name='res.users', domain=[('share', '=', False)], string='Choose Delivery Person')
    groupby_product_ids           = fields.Many2many(comodel_name="product.product", domain=[('product_category', '=', 'Packing Material')], string="Choose Products")
    output_to                     = fields.Selection(selection=[('screen', 'Screen'), ('pdf', 'PDF'), ('xls', 'Excel/CSV')], string='Output To', required=True)
    report_lines                  = fields.One2many(comodel_name='packing.list.wizard.tree.view', inverse_name='report_id', string='Report Lines')
    generate_report_button        = fields.Boolean('Generate Report')

    @api.onchange('generate_report_button')
    def generate_report_data(self):
        if not self.groupby:
            return

        self.env['packing.list.wizard.tree.view'].unlink()
        account_invoice_packing_items_obj = self.env['account.invoice.packing_items'].search(
            [('invoice_id.date_invoice', '>=', self.unreturned_material_date_from), 
             ('invoice_id.date_invoice', '<=', self.unreturned_material_date_to), 
             ('invoice_id.company_id', '=', self.company_id.id),
             ('is_return', '=', False)] 
        )
        if not account_invoice_packing_items_obj or len(account_invoice_packing_items_obj) == 0:
            raise ValidationError(_("No Records Found for your criteria!"))

        datas  = []

        for lead in account_invoice_packing_items_obj:
            sale_order_obj =  self.env['sale.order'].search([('name','=',lead.invoice_id.origin)])

            addrow = {
                'invoice_name'       : lead.invoice_id.number,
                'customer_name'      : lead.invoice_id.partner_id.name,
                'invoice_date'       : lead.invoice_id.date_invoice.strftime('%d-%m-%Y'),
                'order_name'         : lead.invoice_id.origin,
                'order_date'         : sale_order_obj.date_order.strftime('%d-%m-%Y') if sale_order_obj.date_order else False,
                'invoice_amount'     : lead.invoice_id.amount_total,
                'product_name'       : lead.product_id.product_tmpl_id.name,
                'used_qty'           : lead.qty_used,
                'returned_qty'       : lead.qty_return,
                'product_sale_price' : lead.product_id.lst_price,
                'remarks'            : lead.remarks,
                'date_of_return'     : lead.date_return,
                'delivery_person'    : lead.invoice_id.delivery_person_id.name,
            }
            newid = self.env['packing.list.wizard.tree.view'].create(addrow).id
            datas.append(newid)
            data = {
                'datas'         : datas,
                'customer_list' : [],
                'il'            : [],
                'comp'          : {'company_name' : self.company_id.name, 'company_logo' : self.company_id.logo},
            }

        self.report_lines = datas

    @api.multi
    def generate_report(self):

        if self.output_to == 'pdf':
            return self.env.ref('fmcg_crm.invoice_unreturned_materials_wizard_report_id').report_action(self,data={},config=False)
        elif self.output_to == 'excel':
            pass
        else:
            pass

class PackingListWizardTreeView(models.TransientModel):

    _name = 'packing.list.wizard.tree.view'
    _order = ['invoice_name, customer_name, invoice_date, delivery_person', 'product_name']

    report_id          = fields.Many2one(comodel_name='unreturned.materials.wizard', string='Report')
    invoice_name       = fields.Char('Invoice Name')
    customer_name      = fields.Char('Customer')
    invoice_date       = fields.Char('Invoice Date')
    order_name         = fields.Char('Order Name')
    order_date         = fields.Char('Order Date')
    invoice_amount     = fields.Char('Invoice Amount')
    product_name       = fields.Char('Product')
    used_qty           = fields.Char('Used Qty')
    returned_qty       = fields.Char('Returned Qty')
    product_sale_price = fields.Char('Product Sale Price')
    remarks            = fields.Char('Remarks')
    date_of_return     = fields.Char('Date of Return')
    delivery_person    = fields.Char('Delivery Person')
