# -*- coding: utf-8 -*-
from odoo import models,fields,api,_
from datetime import datetime, timedelta, date, time, timezone
from odoo.exceptions import UserError,ValidationError
from itertools import groupby


class PackingListWizard(models.TransientModel):
    _name = "packing.list.wizard"

    delivery_date = fields.Date(string='Packing Date', required=True,default=lambda self: date.today())
    type_of = fields.Selection(selection=[('allocated_qty', 'Allocated Qty'), ('product_uom_qty', 'Ordered Qty')], string='Type')
    packing_list_ids = fields.One2many('packing.list','packing_list_wizard_id')
    categ_ids = fields.Many2many('product.category', 'packing_list_wizard_category_rel', 'packing_list_wave_id', 'category_id', string='Category')
    company_id = fields.Many2one(
    'res.company',
    'Company',store=True,readonly=True,
    default=lambda self: self.env.user.company_id 
    ) 
    route_ids  = fields.Many2many('geographies.ps_routes', 'packing_list_wizard_routes_rel', 'packing_list_wave_id', 'route_id', string='Routes')
    suburb_id = fields.Many2one('geographies.suburbs', string="Suburb", store=True)
    area_id = fields.Many2one('geographies.areas', string="Area", store=True)
   
    @api.multi
    def view_report(self):
        # self.env['delivery.list'].search([]).unlink() 
        # if not self.delivery_date:
        #     raise UserError(_('Please enter delivery date to continue ...'))
        #     return
        self.env['packing.list'].search([]).unlink()
        # ttime = time(23,59,59)
        # start_time = datetime.combine(self.delivery_date, datetime.min.time())
        # end_time = datetime.combine(self.delivery_date, ttime)
        # if self.categ_ids:
        #     sale_order_line_obj = self.env['sale.order.line'].read_group([('order_state','=','sale'),('categ_id','in',[i.id for i in self.categ_ids])], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        if self.categ_ids and self.route_ids and self.suburb_id and self.area_id:
            sale_order_line_obj = self.env['sale.order.line'].read_group([('state','=','sale'),('categ_id','in',[i.id for i in self.categ_ids]),('order_id.routeid','in',[i.id for i in self.route_ids]),('order_id.cust_suburb','=',self.suburb_id.name),('order_id.cust_area','=',self.area_id.name)], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        elif self.route_ids:
            sale_order_line_obj = self.env['sale.order.line'].read_group([('state','=','sale'),('order_id.routeid','in',[i.id for i in self.route_ids])], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        elif self.suburb_id:
            sale_order_line_obj = self.env['sale.order.line'].read_group([('state','=','sale'),('order_id.cust_suburb','=',self.suburb_id.name)], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        elif self.area_id:
            sale_order_line_obj = self.env['sale.order.line'].read_group([('state','=','sale'),('order_id.cust_area','=',self.area_id.name)], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        else:
            sale_order_line_obj = self.env['sale.order.line'].read_group([('state','=','sale')], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        print("sale_order",sale_order_line_obj)
        # print('sale_order_line_obj',sale_order_line_obj.pop('__domain'))
        # mapping = {(lead['product_id'][0], lead['type']): lead['__count'] 
        il=[]
        comp=[]
        comp_detail={}
        comp_detail={
            'company_name':self.company_id.name,
            'company_logo':self.company_id.logo,
        }
        comp.append(comp_detail)
        # il.append(self.delivery_date.strftime('%d-%m-%Y'))
        il.append(self.type_of)
        il.append(self.suburb_id)
        il.append(self.area_id)
        if sale_order_line_obj:
            datas=[]
            li=[]
            
            add={}
            for lead in sale_order_line_obj:
                pid = lead['product_id'][0]                
                product_obj = self.env['product.product'].browse(pid)                              
                if product_obj.product_tmpl_id.categ_id.name not in li:
                    li.append(product_obj.product_tmpl_id.categ_id.complete_name)
                else:
                    pass
                if 'product_uom_qty' in lead :
                    add ={
                            'packing_list_wizard_id':self.id,
                            'product_id':product_obj.product_tmpl_id.name,
                            'product_category_id':product_obj.product_tmpl_id.categ_id.complete_name,
                            'packing_size':lead['product_uom_qty'] ,
                            'count_total': lead['__count'],
                            'product_uom':product_obj.product_tmpl_id.uom_id.name
                    }  
                else:
                    add ={
                            'packing_list_wizard_id':self.id,
                            'product_id':product_obj.product_tmpl_id.name,
                            'product_category_id':product_obj.product_tmpl_id.categ_id.complete_name,
                            'packing_size':lead['allocated_qty'] ,
                            'count_total': lead['__count'],
                            'product_uom':product_obj.product_tmpl_id.uom_id.name
                    }

                self.packing_list_ids.create(add)
            
            return {
                'name': _('Packing Material List'),
                'view_type': 'form',
                'view_mode': 'tree',
                'view_id': self.env.ref('fmcg_crm.packing_list_tree_view').id,
                'res_model': 'packing.list',                           
                'type': 'ir.actions.act_window',
                'context':{'packing_list_tree_vieww_search': 1, 'group_by': ['product_category_id']}, 
                'target': 'current',
            }
        else:
            raise ValidationError(_("Record Not Found"))

    @api.multi
    def generate_report(self):
        # self.env['delivery.list'].search([]).unlink() 
        # if not self.delivery_date:
        #     raise UserError(_('Please enter delivery date to continue ...'))
        #     return
        self.env['packing.list'].search([]).unlink()
        # ttime = time(23,59,59)
        # start_time = datetime.combine(self.delivery_date, datetime.min.time())
        # end_time = datetime.combine(self.delivery_date, ttime)
        if self.categ_ids and self.route_ids and self.suburb_id and self.area_id:
            sale_order_line_obj = self.env['sale.order.line'].read_group([('state','=','sale'),('categ_id','in',[i.id for i in self.categ_ids]),('order_id.route_id','in',[i.id for i in self.route_ids]),('order_id.cust_suburb','=',self.suburb_id.name),('order_id.cust_area','=',self.area_id.name)], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        elif self.categ_ids:
            sale_order_line_obj = self.env['sale.order.line'].read_group([('order_state','=','sale'),('categ_id','in',[i.id for i in self.categ_ids])], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        elif self.route_ids:
            sale_order_line_obj = self.env['sale.order.line'].read_group([('state','=','sale'),('order_id.route_id','in',[i.id for i in self.route_ids])], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        elif self.suburb_id:
            sale_order_line_obj = self.env['sale.order.line'].read_group([('state','=','sale'),('order_id.cust_suburb','=',self.suburb_id.name)], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        elif self.area_id:
            sale_order_line_obj = self.env['sale.order.line'].read_group([('state','=','sale'),('order_id.cust_area','=',self.area_id.name)], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        else:
            sale_order_line_obj = self.env['sale.order.line'].read_group([('state','=','sale')], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        print("sale_order",sale_order_line_obj)       
        il=[]
        comp=[]
        comp_detail={}
        comp_detail={
            'company_name':self.company_id.name,
            'company_logo':self.company_id.logo,
        }
        comp.append(comp_detail)
        # il.append(self.delivery_date.strftime('%d-%m-%Y'))
        il.append(self.type_of)
        il.append(self.suburb_id)
        il.append(self.area_id)
        if sale_order_line_obj:
            datas=[]
            li=[]
            
            add={}
            for lead in sale_order_line_obj:
                pid = lead['product_id'][0]                
                product_obj = self.env['product.product'].browse(pid)                              
                if product_obj.product_tmpl_id.categ_id.name not in li:
                    li.append(product_obj.product_tmpl_id.categ_id.complete_name)
                else:
                    pass
                if 'product_uom_qty' in lead :
                    add ={
                            'packing_list_wizard_id':self.id,
                            'product_id':product_obj.product_tmpl_id.name,
                            'product_category_id':product_obj.product_tmpl_id.categ_id.complete_name,
                            'packing_size':lead['product_uom_qty'] ,
                            'count_total': lead['__count'],
                            'product_uom':product_obj.product_tmpl_id.uom_id.name
                    }  
                else:
                    add ={
                            'packing_list_wizard_id':self.id,
                            'product_id':product_obj.product_tmpl_id.name,
                            'product_category_id':product_obj.product_tmpl_id.categ_id.complete_name,
                            'packing_size':lead['allocated_qty'] ,
                            'count_total': lead['__count'],
                            'product_uom':product_obj.product_tmpl_id.uom_id.name
                    }

                self.packing_list_ids.create(add)
                datas.append(add)
                data = {
                    'datas': datas,
                    'li':li,
                    'il':il,
                    'comp':comp_detail
                    }
            return self.env.ref('fmcg_crm.packing_list_wizard_report_id').report_action(self,data=data,config=False)
           
        else:
            raise ValidationError(_("Record Not Found")) 

 
    #@api.multi
    #def generate_report(self):
        # self.env['delivery.list'].search([]).unlink() 
       # if not self.delivery_date:
            #raise UserError(_('Please enter delivery date to continue ...'))
            #return
        #self.env['packing.list'].search([]).unlink()
        #ttime = time(23,59,59)
        #start_time = datetime.combine(self.delivery_date, datetime.min.time())
        #end_time = datetime.combine(self.delivery_date, ttime)
        #if self.categ_ids:
            #sale_order_line_obj = self.env['sale.order.line'].read_group([('requested_date','>=',str(start_time)),('requested_date','<=',str(end_time)),('order_state','=','sale'),('categ_id','in',[i.id for i in self.categ_ids])], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        #elif self.categ_ids and self.route_ids:
            #sale_order_line_obj = self.env['sale.order.line'].read_group([('requested_date','>=',str(start_time)),('requested_date','<=',str(end_time)),('order_state','=','sale'),('categ_id','in',[i.id for i in self.categ_ids]),('route_id','in',[i.id for i in self.route_ids])], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        #elif self.route_ids:
            #sale_order_line_obj = self.env['sale.order.line'].read_group([('requested_date','>=',str(start_time)),('requested_date','<=',str(end_time)),('order_state','=','sale'),('route_id','in',[i.id for i in self.route_ids])], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)
        #else:
            #sale_order_line_obj = self.env['sale.order.line'].read_group([('requested_date','>=',str(start_time)),('requested_date','<=',str(end_time)),('order_state','=','sale')], fields=['product_id',self.type_of], groupby=['product_id',self.type_of],lazy=False)

        # print('sale_order_line_obj',sale_order_line_obj.pop('__domain'))
        # mapping = {(lead['product_id'][0], lead['type']): lead['__count'] 
        #il=[]
        #comp=[]
        #comp_detail={}
        #comp_detail={
            #'company_name':self.company_id.name,
            #'company_logo':self.company_id.logo,
        #}
        #comp.append(comp_detail)
        #il.append(self.delivery_date.strftime('%d-%m-%Y'))
        #il.append(self.type_of)
        #if sale_order_line_obj:
        #    datas=[]
        #    li=[]
            
        #    add={}
        #    for lead in sale_order_line_obj:
        #        product_obj = self.env['product.product'].search([('id','=',lead['product_id'][0])])
        #        if product_obj.product_tmpl_id.categ_id.name not in li:
        #            li.append(product_obj.product_tmpl_id.categ_id.name)
        #        else:
        #            pass
        #        if 'product_uom_qty' in lead :
        #            add ={
        #                    'packing_list_wizard_id':self.id,
        #                    'product_id':product_obj.product_tmpl_id.name,
        #                    'product_category_id':product_obj.product_tmpl_id.categ_id.name,
        #                    'packing_size':lead['product_uom_qty'] ,
        #                    'count_total': lead['__count'],
        #                   'product_uom':product_obj.product_tmpl_id.uom_id.name
        #             }  
        #         else:
        #             add ={
        #                     'packing_list_wizard_id':self.id,
        #                     'product_id':product_obj.product_tmpl_id.name,
        #                     'product_category_id':product_obj.product_tmpl_id.categ_id.name,
        #                     'packing_size':lead['allocated_qty'] ,
        #                     'count_total': lead['__count'],
        #                     'product_uom':product_obj.product_tmpl_id.uom_id.name
        #             }

        #         self.packing_list_ids.create(add)
        #         datas.append(add)
        #         data = {
        #             'datas': datas,
        #             'li':li,
        #             'il':il,
        #             'comp':comp_detail
        #             }
        #     return self.env.ref('fmcg_crm.packing_list_wizard_report_id').report_action(self,data=data,config=False)
    #     # return self.env["report"].get_action(self, 'fmcg_crm.delivery_list_wizard_report_id')
        # else:
        #     raise ValidationError(_("Record Not Found"))

class PackingList(models.TransientModel):
    _name = 'packing.list'
    
    packing_list_wizard_id = fields.Many2one('packing.list.wizard')
    product_category_id = fields.Char('product.category')
    product_id = fields.Char('product.product')
    packing_size = fields.Float("Quantity")
    count_total = fields.Float("Count")






































































































    # @api.multi
    # def print_report_excel_data(self):
    #     self.ensure_one()
    #     sum1 = 0.0
    #     stock_picking_wave_obj = self.env['stock.picking.wave'].search([('create_date','>=',self.date_from),('create_date','<=',self.date_to)])
    #     workbook = xlwt.Workbook()
    #     sheet1 = workbook.add_sheet('Total Number of Pickings')
    #     sheet2 = workbook.add_sheet('Total Number of Product')
    #     sheet3 = workbook.add_sheet('Total Number of Quantity')
    #     #Sheet 1
    #     sheet1.col(0).width = 256 * 35
    #     sheet1.col(1).width = 256 * 20
    #     sheet1.col(2).width = 256 * 20
    #     sheet1.col(3).width = 256 * 20
    #     #Sheet 2
    #     sheet2.col(0).width = 256 * 35
    #     sheet2.col(1).width = 256 * 20
    #     sheet2.col(2).width = 256 * 20
    #     sheet2.col(3).width = 256 * 20
    #     #Sheet 3
    #     sheet3.col(0).width = 256 * 35
    #     sheet3.col(1).width = 256 * 20
    #     sheet3.col(2).width = 256 * 20
    #     sheet3.col(3).width = 256 * 20
    #     font = xlwt.Font()
    #     style = xlwt.XFStyle()
    #     style.font = font
    #     heading = xlwt.easyxf('font: bold on, height 300; align: horiz center;')
    #     bold = xlwt.easyxf('font: bold on')
    #     cell = xlwt.easyxf('font: bold on, height 200; align: horiz center;')
    #     total = xlwt.easyxf('font: bold on, height 220; align: horiz right;')
    #     center = xlwt.easyxf('align: horiz center;')
    #     #Sheet 1
    #     sheet1.write(0, 0, "Name", cell)
    #     sheet1.write(0, 1, "Pack (Responsible)", cell)
    #     sheet1.write(0, 2, "Book (Owner)",cell)
    #     sheet1.write(0, 3, "Pick (Picking Person)",cell)
    #     #Sheet 2
    #     sheet2.write(0, 0, "Name", cell)
    #     sheet2.write(0, 1, "Pack (Responsible)", cell)
    #     sheet2.write(0, 2, "Book (Owner)",cell)
    #     sheet2.write(0, 3, "Pick (Picking Person)",cell)
    #     #Sheet 3
    #     sheet3.write(0, 0, "Name", cell)
    #     sheet3.write(0, 1, "Pack (Responsible)", cell)
    #     sheet3.write(0, 2, "Book (Owner)",cell)
    #     sheet3.write(0, 3, "Pick (Picking Person)",cell)
    #     row = 1
    #     li=[]
    #     il=[]
    #     # unique_sku = []
    #     dic={}
    #     for order in stock_picking_wave_obj:
    #         if order.user_id.name and order.picking_person.name and order.employee_id.name not in li:
    #             li.append(order.user_id.name)
    #             li.append(order.employee_id.name)
    #             li.append(order.picking_person.name)
    #         else :
    #             pass
    #     # unique_sku = list(dict.fromkeys(li))
    #     # li.sort()
    #     picking_object = self.env['stock.picking']
    #     stock_move_obj = self.env['stock.move']
    #     # picking_count =0.0
    #     # move_product_count = 0.0
    #     # move_product_qty = 0.0
    #     li.sort()
    #     for j in li:
    #         responsible_person = stock_picking_wave_obj.search([('user_id.name','=',j)])
    #         if responsible_person:
    #             picking_count = 0.0
    #             move_product_count = 0.0
    #             move_product_qty = 0.0
    #             for i in responsible_person:
    #                 picking_obj = picking_object.search([('wave_id.id','=',i.id)])
    #                 if picking_obj:
    #                     picking_count += 1
    #                     for picking in picking_obj:
    #                         for lines  in picking.move_lines:
    #                             move_product_count += 1
    #                             move_product_qty += lines.product_uom_qty
    #             sheet1.write(row, 0,i.user_id.name or '')
    #             sheet1.write(row, 1, picking_count or '')
    #             sheet2.write(row, 0,i.user_id.name or '')
    #             sheet2.write(row, 1,move_product_count or '')
    #             sheet3.write(row, 0,i.user_id.name or '')
    #             sheet3.write(row, 1,move_product_qty or '')
    #             row +=1
    #             # for pick in picking_obj:
    #             #     picking_count +=
    #                 # print "stock picking",pick.origin
    #         picking_person = stock_picking_wave_obj.search([('picking_person.name','=',j)])
    #         if picking_person:
    #             picking_count = 0.0
    #             move_product_count = 0.0
    #             move_product_qty = 0.0
    #             picking_count = 0.0
    #             for h in picking_person:
    #                 picking_obj = picking_object.search([('wave_id.id','=',h.id)])
    #                 if picking_obj:
    #                     picking_count =+ 1
    #                     for picking in picking_obj:
    #                         for lines  in picking.move_lines:
    #                             move_product_count += 1
    #                             move_product_qty += lines.product_uom_qty
    #             sheet1.write(row, 0,h.picking_person.name or '')
    #             sheet1.write(row, 2, picking_count or '')
    #             sheet2.write(row, 0,h.picking_person.name or '')
    #             sheet2.write(row, 2, move_product_count or '')
    #             sheet3.write(row, 0,h.picking_person.name or '')
    #             sheet3.write(row, 2,move_product_qty or '')
    #             row +=1
    #         owner_person = stock_picking_wave_obj.search([('employee_id.name','=',j)])
    #         if owner_person:
    #             picking_count = 0.0
    #             move_product_count = 0.0
    #             move_product_qty = 0.0
    #             for k in owner_person:
    #                 picking_obj = picking_object.search([('wave_id.id','=',k.id)])
    #                 if picking_obj:
    #                     picking_count =+ 1
    #                     for picking in picking_obj:
    #                         for lines  in picking.move_lines:
    #                             move_product_count += 1
    #                             move_product_qty += lines.product_uom_qty
    #             sheet1.write(row, 0,k.employee_id.name or '')
    #             sheet1.write(row, 3, picking_count or '')
    #             sheet2.write(row, 0,k.employee_id.name or '')
    #             sheet2.write(row, 3,move_product_count or '')
    #             sheet3.write(row, 0,k.employee_id.name or '')
    #             sheet3.write(row, 3,move_product_qty or '')
    #             row +=1
    #     #     sum1 = 0.0
    #     #     count =0
    #     #     avg = 0
    #     #     for i in realtime_inv_mng:
    #     #         if j == i.internal_ref:
    #     #             sum1 +=i.forecasted_qty
    #     #             count +=1
    #     #             if i.product_name not in il:
    #     #                 il.append(i.product_name)
    #     #             else :
    #     #                 pass
    #     #     if count == 0:
    #     #         pass
    #     #     else:
    #     #         avg = sum1/count
    #     #     # product_obj = self.env['product.product'].search([('default_code','=',str(j))])
    #     #     # unique_prod_name = product_obj.product_tmpl_id.name
    #     #     dic.update({j:float(avg)})
    #     #     sheet.write(row, 0, str(dic.keys()).strip('[').strip(']').strip('u').strip("'").strip("'") or '')
    #     #     sheet.write(row, 1, str(il).strip('[').strip(']').strip('u').strip("'").strip("'") or '')
    #     #     sheet.write(row, 2,str(dic.values()).strip('[').strip(']'))
    #     #     row += 1
    #     #     del dic[j]
    #     #     del il[:]
    #     #     # sheet.merge_range(row:1,)
    #     #Sheet 1
    #     sheet1.col(0).width = 256 * 25
    #     sheet1.col(1).width = 256 * 25
    #     sheet1.col(2).width = 256 * 25
    #     sheet1.col(3).width = 256 * 25
    #     #Sheet 2
    #     sheet2.col(0).width = 256 * 25
    #     sheet2.col(1).width = 256 * 25
    #     sheet2.col(2).width = 256 * 25
    #     sheet2.col(3).width = 256 * 25
    #     #Sheet 3
    #     sheet3.col(0).width = 256 * 25
    #     sheet3.col(1).width = 256 * 25
    #     sheet3.col(2).width = 256 * 25
    #     sheet3.col(3).width = 256 * 25    

    #     fp = StringIO()
    #     workbook.save(fp)
    #     fp.seek(0)
    #     data = fp.read()
    #     fp.close()
    #     return base64.b64encode(data)


    # @api.multi
    # def export_report(self):
    #     res = self.print_report_excel_data()
    #     data = res or ''
    #     filename = 'Stock Picking Wave Report'
    #     self.write({'datas':data})
    #     return {
    #             'type' : 'ir.actions.act_url',
    #             'url':   '/web/content/?download=1&model=stock.picking.wave.report&field=datas&id=%s&filename=Stock_Picking_Wave_Report.xls'%(self.id),
    #             'target': 'self',
    #             }
