
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
import json
import logging

_logger = logging.getLogger(__name__)

class NetworkAssignment(models.Model):

    _inherit = 'res.partner'

#     nodes_id = fields.Many2one('network.nodes', string='Network Node', stored=True)
    channel_id = fields.Many2one('crm.team', string='Sales Channel', stored=True)
#    city_id = fields.Many2one('res.city', string='City')
#    city = fields.Char("City", compute="_get_city_name", stored=True)
#    food_licence = fields.Char('Food Licence')
#     district_id = fields.Many2one('geographies.districts', string="District", stored=True, compute='_get_district')
#     region_id = fields.Many2one('geographies.regions', string="Region", stored=True, compute='_get_region')
#    state_id = fields.Many2one('res.country.state', string="State", stored=True)  # , compute='_get_state', domain=None
#    country_id = fields.Many2one('res.country', string="Country", stored=True)    # , compute='_get_country'
    suburb_id = fields.Many2one('geographies.suburbs', string="Suburb", stored=True)
    area_id = fields.Many2one('geographies.areas', string="Area", stored=True)
    route_id = fields.Many2many('geographies.routes', string="Route", stored=True)
    society = fields.Char('Society Name')
    building = fields.Char('Building Name')
    flat_no = fields.Char('Flat No.')
    birthday = fields.Date('Date of Birth')

#     div_id = fields.Many2many('product.division', string="Product Division", stored=True)
#     supplier_id = fields.Many2many(relation='retailer_distributor_rel', comodel_name='res.partner', column1='id', column2='supplier_id', string='Supply Point', stored=True)
#     salesman_ids = fields.Many2many('hr.employee', string="Sales Person(s)", stored=True)
#    credit_limit = fields.Float(string='Credit Limit')
#    payment_delay_block = fields.Boolean(string='Block Sales for Delay?')
#    limit_crossed_block = fields.Boolean(string='Block Sales past Limit?')

    @api.onchange('city_id')
    def _get_city_name(self):
        if self.city_id:
            self.city = self.env['res.city'].browse(self.city_id.id).name
            self.state_id = self.env['res.city'].browse(self.city_id.id).state_id.id
            self.country_id = self.env['res.city'].browse(self.city_id.id).country_id.id

    def get_suburb_domain(self, city_id):
        match = []
        suburbs = self.env['geographies.suburbs'].search([('city_id', '=', city_id)])
        return {'domain':{'suburb_id':[('id','in',suburbs)]}}
    def get_area_domain(self, suburb_id):
        match = []
        areas = self.env['geographies.areas'].search([('suburb_id', '=', suburb_id)])
        return {'domain':{'area_id':[('id','in',areas)]}}

#     @api.one
#     @api.depends('city_id')
#     def _get_district(self):
#
#         if self.city_id:
#             self.district_id = self.env['res.city'].browse(self.city_id.id).district_id.id
#         else:
#             self.district_id = 0
#
#     @api.one
#     @api.depends('city_id')
#     def _get_region(self):
#
#         if self.city_id:
#             self.region_id = self.env['res.city'].browse(self.city_id.id).region_id
#         else:
#             self.region_id = 0

#     @api.one
#     @api.depends('city_id')
#     def _get_state(self):
#
#         if self.city_id:
#             self.state_id = self.env['res.city'].browse(self.city_id.id).state_id.id
#         else:
#             self.state_id = 0
#
#     @api.one
#     @api.depends('city_id', 'state_id')
#     def _get_country(self):
#
#         if self.state_id:
#             self.country_id = self.env['res.city'].browse(self.city_id.id).country_id.id
#         else:
#             self.country_id = 0


#     @api.model
#     def retailer_write(self, retailer_info=False):
#
#         if not retailer_info or retailer_info == False:
#             retval = {'success': False, 'message': 'Invalid Input Parameters - No data!', 'retailer_id': 0}
#             return retval
#
#         retailer = json.dumps(retailer_info)
#         retailer = json.loads(retailer)
#
#         # _logger.info("retailer_info = %s \n\n\nretailer = %s\n\n\n" % (retailer_info, retailer))
#         cityname = retailer['city']
#
#         city_rec    = self.env['res.city'].search([('name', '=', cityname)])
#         if not city_rec or city_rec == False:
#             retval = {'success': False, 'message': 'Invalid Input Parameters - City not found!', 'retailer_id': 0}
#             return retval
#
#         suburb_rec  = self.env['geographies.suburbs'].search([('id', '=', retailer['suburb_id'])])
#         area_rec    = self.env['geographies.areas'].search([('id', '=', retailer['area_id'])])
#         # _logger.info('\n\n\nsuburb_rec = %s\n\n\narea_rec = %s\n\n\n' % (suburb_rec, area_rec))
#
#         if not suburb_rec or suburb_rec == False:
#             retval = {'success': False, 'message': 'Invalid Input Parameters - Suburb not found!', 'retailer_id': 0}
#             return retval
#         elif len(suburb_rec) == 0:
#             retval = {'success': False, 'message': 'Invalid Input Parameters - Suburb not found!', 'retailer_id': 0}
#             return retval
#
#         if not area_rec or area_rec == False:
#             retval = {'success': False, 'message': 'Invalid Input Parameters - Area not found!', 'retailer_id': 0}
#             return retval
#         elif len(area_rec) == 0:
#             retval = {'success': False, 'message': 'Invalid Input Parameters - Area not found!', 'retailer_id': 0}
#             return retval
#
#         city_id     = city_rec.id
#         district_id = city_rec.district_id
#         region_id   = city_rec.region_id
#         state_id    = city_rec.state_id
#
#         outlet_name = retailer['outlet_name']
#         owner_name  = retailer['owner_name']
#         mobile      = retailer['mobile']
#         email       = retailer['email']
#         gstin       = retailer['gstin']
#         street      = retailer['address']
#         street2     = ''
#         city        = retailer['city']
#         suburb_id   = retailer['suburb_id']
#         area_id     = retailer['area_id']
#         store_pic   = retailer['store_pic']
#         lat         = retailer['lat']
#         lon         = retailer['lon']
#
#         if type(store_pic) == 'bytes':
#             store_pic = "".join(chr, store_pic)
#
#         add_row = {'name': outlet_name,
#             'ref': owner_name,
#             'mobile': mobile,
#             'email': email,
#             'vat': gstin,
#             'street': street,
#             'street2': street2,
#             'city_id': city_id,
#             'suburb_id': suburb_id,
#             'area_id': area_id,
#             'partner_latitude': lat,
#             'partner_longitude': lon,
#             'image': store_pic
#             }
#         retailer_id = self.env['res.partner'].create(add_row).id
#
#         retval = {'success': True, 'message': 'Success!', 'retailer_id': retailer_id}
#         return retval
