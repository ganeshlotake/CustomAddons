# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import date,datetime,time,timedelta
from lxml import etree
import pytz
import logging
import calendar

_logger = logging.getLogger(__name__)

ORDER_STATES = [('draft', 'Quotation'), ('sent', 'Quotation Sent'), ('sale', 'Sales Order'), ('done', 'Locked'), ('cancel', 'Cancelled')]

class OnlineSaleOrders(models.Model):

    _inherit = 'sale.order'

    cust_city = fields.Char(related='partner_shipping_id.city_id.name', string='City', stored=True)
    cust_suburb = fields.Char(related='partner_shipping_id.suburb_id.name', string="Suburb", stored=True)
    cust_area = fields.Char(related='partner_shipping_id.area_id.name', string="Area", stored=True)

    customer_comment    = fields.Text('Customer Order Comment', default="No comment")
    slot_id             = fields.Many2one(comodel_name='geographies.delivery_slot', string='Delivery Slot')
    route_id            = fields.Many2one(comodel_name='geographies.routes', string='Delivery Route', related='slot_id.route_id', readonly=True)
    delivery_session    = fields.Selection(related='slot_id.session', string='Session', readonly=True)
    delivery_start_time = fields.Selection(related='slot_id.time_start', string='Start Time', readonly=True)
    delivery_end_time   = fields.Selection(related='slot_id.time_finish', string='End Time', readonly=True)
    requested_date      = fields.Datetime(string='Requested Date')
    commitment_date     = fields.Datetime(string='Commitment Date')
    actual_delivery_date= fields.Datetime(string='Actual Delivery Date')
    


    @api.model
    def fields_view_get(self, view_id=None, view_type=False, toolbar=False, submenu=False):
        res = super(OnlineSaleOrders,self).fields_view_get(view_id=view_id, view_type=view_type, toolbar=toolbar, submenu=False)
        if res:
            doc = etree.XML(res['arch'])
            if view_type == 'form':
                is_customer_comment_features = False
                search_websites = self.env['website'].search([('id', '!=', False)])

                for setting in search_websites:
                    if setting.is_customer_comment_features:
                        is_customer_comment_features = True

                res['arch'] = etree.tostring(doc)
        return res

    # @api.multi
    # def action_confirm(self):

    #     for line in self.order_line:
    #         product_id = line.product_id
    #         if product_id.convert_unit == True:
    #             line.order_qty = line.product_uom_qty
    #             line.product_uom_qty = line.product_uom_qty * line.product_id.conversion_factor
    #             line.order_rate = line.price_unit
    #             line.price_unit = 1 / line.product_id.conversion_factor * line.price_unit
    #             line.conversion_unit = line.product_id.conversion_unit
    #         else:
    #             line.order_qty = line.product_uom_qty
    #             line.conversion_unit = line.product_id.uom_id
    #             line.order_rate = line.price_unit

    #     record = super(OnlineSaleOrders, self).action_confirm()
    #     return record

    @api.multi
    def delivery_slots(self, partner_id=None, order_date=None):
        if not partner_id:
            return None

        user_tz = pytz.timezone(self.env.context.get('tz') or self.env.user.tz)

        if not order_date:
            order_date = datetime.now()
            order_date = pytz.utc.localize(order_date).astimezone(user_tz)

        if not partner_id.suburb_id or not partner_id.area_id:
            return None

        maximum_slot_days = int(self.env['ir.config_parameter'].sudo().get_param('fmcg_crm.maximum_slot_days'))
        order_day = order_date.weekday()
        delivery_date_start = order_date
        delivery_date_end   = order_date + timedelta(days=maximum_slot_days)
        delivery_days = []
        routes = self.env['geographies.routes'].search(['&', ('suburb_ids.id', '=', partner_id.suburb_id.id), ('area_ids.id', '=', partner_id.area_id.id)])

        data = []
        route_no = 0
        for ddate in (order_date + timedelta(n) for n in range(min(maximum_slot_days,7))):
            dslots = self.env['geographies.delivery_slot'].search([
                ('route_id', 'in', routes.ids), 
                ('delivery_day', '=', ddate.weekday())])
            for slot in dslots:
                cutoff_date = ddate.date() - timedelta(days=slot.days_cutoff)
                cutoff_date = datetime(
                    year=cutoff_date.year,
                    month=cutoff_date.month,
                    day=cutoff_date.day,
                    hour=int(slot.time_cutoff[:2]),
                    minute=int(slot.time_cutoff[3:])
                )
                cutoff_date = pytz.utc.localize(cutoff_date).astimezone(user_tz)
                if cutoff_date < order_date:
                    continue
                week_day = calendar.day_name[ddate.date().weekday()].ljust(10)
                vals = {
                    'dslot_id': slot.id,
                    'route_id': slot.route_id.id,
                    'route_no': route_no,
                    'route_name': slot.route_id.name,
                    'session': slot.session,
                    'start_time': slot.time_start,
                    'end_time': slot.time_finish,
                    'delivery_date': ddate.date(),
                    'weekday': week_day,
                    'dispstr': week_day[:3] + ' ' + datetime.strftime(ddate, '%d-%b') + ' ' + slot.time_start + '-' + slot.time_finish,
                }
                data.append(vals)
                route_no += 1

        if len(data) == 0:
            data = None

        return data

    @api.multi
    def packing_items(self):
        packing_material = self.env['product.product'].search([('product_category', '=', 'Packing Material')])
        pm_list = []
        for pm_item in packing_material:
            pm_json = {
                'name': pm_item.name,
                'qty': 0,
            }
            pm_list.append(pm_json)
        return pm_list


class OnlineSaleOrderLines(models.Model):

    _inherit = 'sale.order.line'

    @api.one
    @api.depends('product_id')
    def get_conversion_unit(self):
        self.conversion_unit = self.product_id.conversion_unit
#         for item in self:
#             item.conversion_unit = self.env['product.product'].browse(item.product_id).conversion_unit


    order_qty = fields.Float(string='Web Ord.Qty.')
    allocated_qty = fields.Float('Allocated Qty.')
    order_rate = fields.Float(string='Order Rate')
    conversion_unit = fields.Many2one(comodel_name='product.uom', default=get_conversion_unit, string="New UoM")
    requested_date = fields.Datetime(related='order_id.requested_date', string='Requested Date', readonly=True)
    partner_id = fields.Many2one(related='order_id.partner_id', comodel_name='res.partner', string='Customer')
    order_no = fields.Char(related='order_id.name', string='Order No', store=True)
    date_order = fields.Datetime(related='order_id.date_order', string='Order Date', store=True)
    cust_city = fields.Char(related='order_id.partner_shipping_id.city_id.name', string='City')
    cust_suburb = fields.Char(related='order_id.partner_shipping_id.suburb_id.name', string="Suburb")
    cust_area = fields.Char(related='order_id.partner_shipping_id.area_id.name', string="Area")
    order_state = fields.Selection(related='order_id.state', selection=ORDER_STATES, string='Status')


class StockPicking(models.Model):

    _inherit = 'stock.picking'
    allocation_done = fields.Boolean("Allocated ?")

class AllocateSaleQty(models.Model):

    _inherit = 'stock.move'

    allocated_qty = fields.Float('Alloc.Qty.')


class AccountInvoiceExtended(models.Model):

    _inherit = 'account.invoice'

    packing_ids    = fields.One2many(comodel_name='account.invoice.packing_items', inverse_name='invoice_id', string='Packing Items')
    order_id       = fields.Many2one(comodel_name='sale.order', string='Sale Order', stored=True)
    requested_date = fields.Datetime(related='order_id.requested_date', string='Delivery Date', stored=True, readonly=True)
    slot_id        = fields.Many2one(related='order_id.slot_id', string='Delvery Slot', stored=True, readonly=True)
    cust_city      = fields.Char(related='partner_shipping_id.city_id.name', string='City', stored=True)
    cust_suburb    = fields.Char(related='partner_shipping_id.suburb_id.name', string="Suburb", stored=True)
    cust_area      = fields.Char(related='partner_shipping_id.area_id.name', string="Area", stored=True)
   




class AccountInvoicePackingItems(models.Model):

    _name = 'account.invoice.packing_items'
    _description = 'List of Packing Items in Invoices'

    invoice_id = fields.Many2one(comodel_name='account.invoice', string='Invoice')
    product_id = fields.Many2one(comodel_name='product.product', string='Packing Item',domain=[('product_category', '=', 'Packing Material')], required=True)
    qty_used   = fields.Integer(string='Quantity', required=True)
    remarks    = fields.Char(string='Remarks')
    is_return  = fields.Boolean(string='Returned ?')
    date_return = fields.Date(string='Date of Return')
    qty_return = fields.Integer(string='Returned Qty.')


    def compute_bal(self, qty_used=0, qty_return=0):
        return (qty_used - qty_return)

