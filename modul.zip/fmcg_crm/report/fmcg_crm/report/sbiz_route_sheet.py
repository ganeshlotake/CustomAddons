# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------------------------------#
#   Module Name:    SBiz eCom Suite                                                                 #
#   Description:    Collective Single Module for e-Commerce Business Requirements                   #
#   File Name:      sbiz_ecom_delivery.py (/models)                                                 #
#   Purpose:        The model / classes to sets up the Delivery Mechanism for a typical ecommerce   #
#                   business where deliveries are last mile deliveries and are handled by the       #
#                   e-commerce operator itself.                                                     #
#   Author:         Jayant Bulbule                                                                  #
#   Date Created:   28-Oct-2019                                                                     #
#   Last Modified:  --/--/----                                                                      #
#   Last Mod. By:                                                                                   #
#---------------------------------------------------------------------------------------------------#

#---------------------------------------------------------------------------------------------------#
#                                   Modification History                                            #
#---------------------------------------------------------------------------------------------------#
#  Date        Modified By          Purpose                                           Change Mark   #
#  ----------  -------------------  -----------------------------------------------   ------------- #
#                                                                                                   #
#                                                                                                   #
#                                                                                                   #
#---------------------------------------------------------------------------------------------------#

from datetime import datetime, timedelta, date, time, timezone
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

class RouteSheetWizard(models.TransientModel):

    _name = 'sale.route_sheet.wizard'
    _description = 'Wizard Model for generating a Route Sheet'

    employee_ids = fields.Many2many(comodel_name='res.users', string='Delivery Person(s)', required=True,
        help='Select names of delivery persons planned for the deliveries. If you leave this field blank all allocated delivery persons will be selected.')
    delivery_date = fields.Date(string='Delivery Date', default=lambda self: date.today(), required=True)
    delivery_slot = fields.Many2many(comodel_name='geographies.delivery_slot', string='Delivery Slots', required=True, help='Choose delivery slot(s). Leave blank for ALL applicable slots for delivery date.')

    @api.multi
    def get_route_sheet(self):
        if not self.employee_ids or not self.delivery_slot or not self.delivery_date:
            raise UserError(_('You must enter all the above fields to continue ...'))
            return

        ttime = time(23,59,59)
        date1 = datetime.combine(self.delivery_date, datetime.min.time())
        date2 = datetime.combine(self.delivery_date, ttime)

        delivery_slot = self.delivery_slot
        recset = self.env['account.invoice'].search([
            ('slot_id', 'in', self.delivery_slot.ids),
            ('delivery_person_id', 'in', self.employee_ids.ids),
            ('requested_date', '>=', date1),
            ('requested_date', '<=', date2)
         ])
#       recset = self.env['account.invoice'].search([])
        self.env['sale.route_sheet'].search([]).unlink()
        datas = []
        for rec in recset:
            addrow = {
                'invoice_number'  : rec.number,
                'order_number'    : rec.origin,
                'requested_date'  : rec.requested_date,
                'customer_name'   : rec.partner_id.name,
                'customer_phone'  : rec.partner_id.phone,
                'customer_mobile' : rec.partner_id.mobile,
                'address_street'  : rec.partner_id.street,
                'address_street2' : rec.partner_id.street2,
                'address_city'    : rec.partner_id.city_id.name,
                'address_society' : rec.partner_id.society,
                'address_building': rec.partner_id.building,
                'address_flat'    : rec.partner_id.flat_no,
                'address_suburb'  : rec.partner_id.suburb_id.name,
                'address_area'    : rec.partner_id.area_id.name,
                'invoice_amount'  : rec.amount_total,
#                'payment_method'  : rec.transaction_ids.acquirer_id[0].name,
                'delivery_slot'   : rec.slot_id.name,
                'delivery_route'  : rec.slot_id.route_id.name,
                'delivery_start'  : rec.slot_id.time_start,
                'delivery_end'    : rec.slot_id.time_finish,
                'delivery_session': rec.slot_id.session,
                'delivery_pereson': rec.delivery_person_id.name,
            }
            self.env['sale.route_sheet'].create(addrow)
            datas.append(addrow)

        res = {
               'route': datas,
               'delivery_date': self.delivery_date,
               'employee_ids': self.employee_ids,
               'delivery_slot': self.delivery_slot
              }
        print("recset", recset)
        print("recset", datas)
        data = {
           'form': res,
           'recset': recset,
           'datas': datas
        }
        return self.env.ref('fmcg_crm.route_sheet_report').report_action(self, data=data,config=False)

        # return {
        #      'data': data,
        #      'type': 'ir.actions.report',
        #      'report_name': 'Route Sheet',
        #      'report_type': 'jasper',
        # }


# self.env.ref('__export__.ir_act_report_xml_821_ce892057').report_action([],data=data)

    @api.multi
    def __get_route_sheet(self):

        data = self._get_route_sheet_data()
#        raise UserError('Data = %s' % data)
        action =  self.env.ref('fmcg_crm.report_routesheet').report_action([],data=data,config=False)
        return action


class RouteSheet(models.TransientModel):

    _name = 'sale.route_sheet'
    _description = 'Transient Model for holding Route Sheet Data'
    _order = ''

    invoice_number   = fields.Char(string='Invoice No.')
    order_number     = fields.Char(string='Order No.')
    requested_date   = fields.Datetime(string='Delivery Date')
    customer_name    = fields.Char(string='Customer')
    customer_phone   = fields.Char(string='Phone No.')
    customer_mobile  = fields.Char(string='Mobile')
    address_street   = fields.Char(string='Street')
    address_street2  = fields.Char(string='Street-2')
    address_city     = fields.Char(string='City')
    address_society  = fields.Char(string='Society')
    address_building = fields.Char(string='Building')
    address_flat     = fields.Char(string='Flat')
    address_suburb   = fields.Char(string='Suburb')
    address_area     = fields.Char(string='Area')
    invoice_amount   = fields.Float(string='Amount')
    payment_method   = fields.Char(string='Payment Method')
    delivery_slot    = fields.Char(string="Delivery Slot")
    delivery_start   = fields.Char(string="Start Time")
    delivery_end     = fields.Char(string="End Time")
    delivery_session = fields.Char(string="Session")
    delivery_route   = fields.Char(string="Route")
    delivery_person  = fields.Char(string="SalesPerson Name")

class AccountInvoiceExtend(models.Model):

    _inherit = 'account.invoice'

    order_id             = fields.Many2one(comodel_name='sale.order', string='Order IDs')
    order_date           = fields.Datetime(related='order_id.date_order', string='Order Date', stored=True)
    actual_delivery_date = fields.Datetime(related='order_id.actual_delivery_date', string="Actual Delivery Date", stored=True)
    delivery_person_id   = fields.Many2one(related='order_id.delivery_person_id', comodel_name='res.users', string='Delivered By')
    packing_person_id    = fields.Many2one(related='order_id.packing_person_id', comodel_name='res.users', string='Packed By')
    picking_person_id    = fields.Many2one(related='order_id.picking_person_id', comodel_name='res.users', string='Picked By')
    quality_checker_id   = fields.Many2one(related='order_id.quality_checker_id', comodel_name='res.users', string='Q.C. By')
    slot_id              = fields.Many2one(related='order_id.slot_id', comodel_name='geographies.delivery_slot', string='Delivery Slot')


class SaleOrderExtend(models.Model):

    _inherit = 'sale.order'

    delivery_person_id = fields.Many2one(comodel_name='res.users', string='Delivered By')
    packing_person_id  = fields.Many2one(comodel_name='res.users', string='Packed By')
    picking_person_id  = fields.Many2one(comodel_name='res.users', string='Picked By')
    quality_checker_id = fields.Many2one(comodel_name='res.users', string='Q.C. By')
