from odoo import models, fields, api
from datetime import date,datetime,time,timedelta,timezone
from odoo.exceptions import UserError

class RouteSheetWizard(models.TransientModel):
    _name = 'sale.route_sheet.wizard'

    date = fields.Date(string="Date Of Delivery", required=True)
    delivery_slot = fields.Many2many("geographies.delivery_slot", string="Delivery Slots")

    @api.model
    def get_route_sheet(self):
        ttime = time(23,59,59)
        date1 = datetime.combine(self.date, datetime.min.time())
        date2 = datetime.combine(self.date, ttime)

        delivery_slot = self.delivery_slot
        recset = self.env['account.invoice'].search([
            ('slot_id', 'in', delivery_slot.ids), 
            ('requested_date', '>=', date1)
            ('requested_date', '<=', date2)
        ])
        self.env['sale.route_sheet'].search([]).unlink()
        raise UserError(rec.transaction_ids)
        for rec in recset:
            raise UserError(rec.transaction_ids)
            addrow = {
                'invoice_number': rec.name,
                'order_number': rec.origin,
                'requested_date': rec.requested_date,
                'customer_name': rec.partner_id.name,
                'customer_phone': rec.partner_id.phone,
                'address_street': rec.partner_id.street,
                'address_street2': rec.partner_id.street2,
                'address_city': rec.partner_id.city_id.name,
                'address_society': rec.partner_id.society,
                'address_building': rec.partner_id.building,
                'address_flat': rec.partner_id.flat,
                'address_suburb': rec.suburb_id.name,
                'address_area': rec.area_id.name,
                'invoice_amount': rec.amount_total,
                'payment_method': rec.transaction_ids.acquirer_id[0].name,
                'delivery_slot': rec.slot_id.name,
                'delivery_route': rec.route_id.name,
                'delivery_start': rec.delivery_start_time,
                'delivery_end': rec.deliveery_end_time,
                'delivery_session': rec.delivery_session,
            }
            self.env['sale.route_sheet'].create(addrow)



class RouteSheet(models.TransientModel):

    _name = 'sale.route_sheet'
    _description = 'Transient Model for holding Route Sheet Data'
    _order = ''

    invoice_number = fields.Char(string='Invoice No.')
    order_number   = fields.Char(string='Order No.')
    requested_date = fields.Datetime(string='Delivery Date')
    customer_name  = fields.Char(string='Customer')
    customer_phone = fields.Char(string='Phone No.')
    address_street = fields.Char(string='Street')
    address_street2= fields.Char(string='Street-2')
    address_city   = fields.Char(string='City')
    address_society = fields.Char(string='Society')
    address_building = fields.Char(string='Building')
    address_flat     = fields.Char(string='Flat')
    address_suburb   = fields.Char(string='Suburb')
    address_area     = fields.Char(string='Area')
    invoice_amount   = fields.Float(string='Amount')
    payment_method   = fields.Char(string='Payment Method')
    delivery_slot    = fields.Char(string="Delivery Slot")
    delivery_start   = fields.Char(string="Start Time")
    delivery_end     = fields.Char(string="End Time")
    delivery_session = fields.Char(string="Session")
    delivery_route   = fields.Char(string="Route")
