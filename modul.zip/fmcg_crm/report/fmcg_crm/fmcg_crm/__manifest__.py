# -*- coding: utf-8 -*-
{
    'name': "FMCG CRM",

    'summary': """
       fmcg crm """,

    'description': """
        fmcg crm
    """,

    'author': "Jayant Bulbule, SynerBize, Inc.",
    'website': "http://www.synerbize.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base', 'base_address_city', 'crm', 'sale', 'sale_order_dates', 
        'base_geolocalize', 'auth_signup'],

    # always loaded
    'data': [
        'views/geographies.xml',
        'views/fmcg_sale.xml',
        'views/product_extended.xml',
        'views/sbiz_ecom_delivery_views.xml',
        'views/fmcg_partner_view.xml',
        'views/auth_signup_extend_views.xml',
        'views/templates.xml',
    	'views/product_pack.xml',
        'views/fmcg_sale_allocate.xml',
        'views/sbiz_ecom_config.xml',
        'views/sbiz_ecom_user_account.xml',
        'report/template_demo.xml',
        'report/invoice_pos_main_report.xml',
        'report/invoice_pos_report.xml',
        'report/route_allocation_wizard_view.xml',
   ],

    # loading javascript file
    # 'js': ['static/src/js/geo.js'],

    
    # only loaded in demonstration mode
    # 'demo': [
    #     'demo/demo.xml',
    # ],
    'application': True,
}
