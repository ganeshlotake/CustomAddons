# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import date,datetime,time

ORDER_STATES = [('draft', 'Quotation'), ('sent', 'Quotation Sent'), ('sale', 'Sales Order'), ('done', 'Locked'), ('cancel', 'Cancelled')]

class OnlineSaleOrders(models.Model):
    
    _inherit = 'sale.order'
    
    cust_city = fields.Char(related='partner_shipping_id.city_id.name', string='City', stored=True)
    cust_suburb = fields.Char(related='partner_shipping_id.suburb_id.name', string="Suburb", stored=True)
    cust_area = fields.Char(related='partner_shipping_id.area_id.name', string="Area", stored=True)
    
    # @api.multi
    # def action_confirm(self):
        
    #     for line in self.order_line:
    #         product_id = line.product_id
    #         if product_id.convert_unit == True:
    #             line.order_qty = line.product_uom_qty
    #             line.product_uom_qty = line.product_uom_qty * line.product_id.conversion_factor
    #             line.order_rate = line.price_unit
    #             line.price_unit = 1 / line.product_id.conversion_factor * line.price_unit
    #             line.conversion_unit = line.product_id.conversion_unit
    #         else:
    #             line.order_qty = line.product_uom_qty
    #             line.conversion_unit = line.product_id.uom_id.id
    #             line.order_rate = line.price_unit
        
    #     record = super(OnlineSaleOrders, self).action_confirm()
    #     return record


class OnlineSaleOrderLines(models.Model):
      
    _inherit = 'sale.order.line'
      
    @api.one
    @api.depends('product_id')
    def get_conversion_unit(self):
        self.conversion_unit = self.product_id.conversion_unit
#         for item in self:
#             item.conversion_unit = self.env['product.product'].browse(item.product_id).conversion_unit
    

    # order_qty = fields.Float(string='Web Ord.Qty.')
    allocated_qty = fields.Float('Allocated Qty.')
    # order_rate = fields.Float(string='Order Rate')
    # conversion_unit = fields.Many2one(comodel_name='product.uom', default=get_conversion_unit, string="New UoM")
    requested_date = fields.Datetime(related='order_id.requested_date', string='Requested Date', readonly=True)
    partner_id = fields.Many2one(related='order_id.partner_id', comodel_name='res.partner', string='Customer')
    order_no = fields.Char(related='order_id.name', string='Order No', store=True)
    date_order = fields.Datetime(related='order_id.date_order', string='Order Date', store=True)
    cust_city = fields.Char(related='order_id.partner_shipping_id.city_id.name', string='City')
    cust_suburb = fields.Char(related='order_id.partner_shipping_id.suburb_id.name', string="Suburb")
    cust_area = fields.Char(related='order_id.partner_shipping_id.area_id.name', string="Area")
    order_state = fields.Selection(related='order_id.state', selection=ORDER_STATES, string='Status')


# class StockPicking(models.Model):
    
#     _inherit = 'stock.picking'
#     allocation_done = fields.Boolean("Allocated ?")

# class AllocateSaleQty(models.Model):
    
#     _inherit = 'stock.move'
    
#     allocated_qty = fields.Float('Alloc.Qty.')


class AccountInvoiceExtended(models.Model):

    _inherit = 'account.invoice'

    packing_ids = fields.One2many(comodel_name='account.invoice.packing_items', inverse_name='invoice_id', string='Packing Items')



class AccountInvoicePackingItems(models.Model):

    _name = 'account.invoice.packing_items'
    _description = 'List of Packing Items in Invoices'

    invoice_id = fields.Many2one(comodel_name='account.invoice', string='Invoice')
    partner_id = fields.Many2one(related='invoice_id.partner_id', string='Customer')
    product_id = fields.Many2one(comodel_name='product.product', string='Packing Item', 
        domain=[('product_category', '=', 'Packing Material')], required=True)
    qty_used   = fields.Integer(string='Quantity', required=True)
    remarks    = fields.Char(string='Remarks')
    is_return  = fields.Boolean(string='Returned ?')
    date_return = fields.Date(string='Date of Return')
    qty_return = fields.Integer(string='Returned Qty.')

    def compute_bal(self, qty_used=0, qty_return=0):
        return (qty_used - qty_return)

    @api.onchange('qty_return')
    def set_retun_flag(self):
        if self.qty_used <= self.qty_return:
            self.is_return = True

