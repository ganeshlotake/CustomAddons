# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import date, datetime, timedelta, time, timezone

class SaleOrdersProductSum(models.TransientModel):

    _name = 'sale.order.productsum'
    _description = 'Sales Orders Product Summary'

    product_id  = fields.Many2one(comodel_name='product.product', string='Product')
    category_id = fields.Many2one(comodel_name='product.category', string='Category')
    sum_qty     = fields.Float(string='Sum Qty.')
    qty_on_hand = fields.Float(string='On Hand')
    order_count = fields.Integer(string="# Orders")

    @api.multi
    def allocate_order(self):
        cr = self._cr
        uid = self._uid
        ids = self._ids
        context = self._context
        d_date = context['delivery_date']
        d_date = datetime.strptime(d_date, '%Y-%m-%d')
        rec = self.browse(ids[0])

        datex  = d_date
        date1  = datetime(year=datex.year, month=datex.month, day=datex.day)
        date2  = datetime(year=datex.year, month=datex.month, day=datex.day, hour=23, minute=59, second=59)

#        raise UserError('Product ID = %s - %s, Date1 = %s, Date2 = %s' % (rec.product_id.id, rec.product_id.name, date1, date2))
        order_list = self.env['sale.order.line'].search([('product_id', '=', rec.product_id.id), ('requested_date', '>=', str(date1)), ('requested_date', '<=', str(date2)), ('order_state', '=', 'sale')])
        order_ids  = order_list.ids

#        raise UserError('Order Ids = %s' % order_ids)
        action = self.env.ref('fmcg_crm.action_order_allocation_list_tree_view').read()[0]
        action['domain_force'] = [('id', 'in', order_ids)]
        action['context'] = {'order_ids': order_ids}
        return action


class SaleAllocation(models.TransientModel):
    
    _name = 'sale.order.allocation'
    _description = 'Allocation of Sales Orders'

    delivery_date = fields.Date(string="Delivery Date", default=lambda self: date.today())

    @api.multi
    def product_list(self):

        context = dict(
            self._context,
            delivery_date = self.delivery_date
            )

        datex = self.delivery_date
#        raise UserError('datex = %s' % datex)
        date1 = datetime(year=datex.year, month=datex.month, day=datex.day)
        date2 = datetime(year=datex.year, month=datex.month, day=datex.day, hour=23, minute=59, second=59)
#        raise UserError('Date1 = %s and Date2 = %s' % (date1, date2))
        prodlist = self.env.cr.execute("""SELECT product_id, sum(product_uom_qty) as sum_qty,
            count(*) as order_count 
            FROM sale_order_line so_line 
            INNER JOIN sale_order so_main ON so_line.order_id = so_main.id 
            INNER JOIN product_product product ON so_line.product_id = product.id 
            WHERE so_main.requested_date >= '%s' and so_main.requested_date <= '%s' 
                and so_main.state = 'sale' 
            GROUP BY so_line.product_id""" % (date1, date2))

#        raise UserError('Date1 = %s, Date2 = %s, ProdList = %s' % (date1,date2,prodlist))
        product_list = self.env.cr.dictfetchall()
#        raise UserError('List as Fetched: \n%s' % product_list)
        self.env['sale.order.productsum'].search([]).unlink()

        for product in product_list:

            this_product = self.env['product.product'].browse(product['product_id'])

            addrow = {'product_id': product['product_id'], 
                    'category_id': this_product.categ_id.id, 
                    'sum_qty': product['sum_qty'], 
                    'order_count': product['order_count'], 
                    'qty_on_hand': this_product.qty_available
                }

            newid = self.env['sale.order.productsum'].create(addrow)

        action = self.env.ref('fmcg_crm.action_order_allocation_tree_view').read()[0]
        action['context'] = context
        return action
