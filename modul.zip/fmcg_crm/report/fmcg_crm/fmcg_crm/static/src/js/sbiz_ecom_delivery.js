 odoo.define('fmcg_crm.delivery', function(require) {
    "use strict";

    var ajax = require('web.ajax');

    $(document).ready(function() {
        'use strict';
        $(".form-group > select.form-control").change(function(ev) {
            var e = document.getElementById("slot_id");
            var strUser = e.options[e.selectedIndex].text;
            var intUser = e.options[e.selectedIndex].value;
            var intIndex = e.selectedIndex - 1; // parseInt(strUser.substring(1,strUser.indexOf(')')))
            alert('Delivery Slot Index = ' + intIndex)
            if ($(intIndex) < 0) {
                alert("You must select the Delivery Slot!");
            };
            var routes = document.getElementsByName("routes")
//            alert(strUser);
            var slot_id = $('#slot_id').val();
            // alert(routes.values().val());
            // var $input = $(this);
        });
    });
    $(document).ready(function() {
        'use strict';
        $("button#o_payment_form_pay").bind("click", function(ev) {
            var slot_id = $('#slot_id').val();
            var e = document.getElementById("slot_id");
            var strUser = e.options[e.selectedIndex].text;
            var intUser = e.options[e.selectedIndex].value;
            var intIndex = e.selectedIndex - 1; // parseInt(strUser.substring(1,strUser.indexOf(')')))
            alert('Delivery Slot Index = ' + intIndex)
            var routes = document.getElementsByName("routes");
//            alert('slot_id = ' + slot_id + '\nstrUser = ' + strUser + ' (' + intIndex + ')\nroutes = ' + routes.length);
            ajax.jsonRpc('/shop/delivery_slot/', 'call', {
                'routes': routes,
                'index': intIndex
            });
        });
    });
});
