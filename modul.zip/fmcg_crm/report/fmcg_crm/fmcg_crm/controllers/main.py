# -*- coding: utf-8 -*-

import logging
import werkzeug
from odoo import http, _
from odoo.addons.auth_signup.controllers.main import AuthSignupHome
from odoo.addons.auth_signup.models.res_users import SignupError
from odoo.addons.website_sale.controllers.main import WebsiteSale
from odoo.exceptions import UserError
from odoo.http import request
import calendar
from datetime import datetime, date, timedelta, timezone, time

_logger = logging.getLogger(__name__)


class AuthSignupHome(AuthSignupHome):

    def do_signup(self, qcontext):
        """ Shared helper that creates a res.partner out of a token """
        values = {key: qcontext.get(key) for key in (
            'login', 'name', 'password', 'phone', 'street', 'street2',
            'zip', 'city', 'state_id', 'country_id', 'birthday', 'society', 'building', 
            'flat_no', 'suburb_id', 'area_id')}
        if not values:
            raise UserError(_("The form was not properly filled in."))
        if values.get('password') != qcontext.get('confirm_password'):
            raise UserError(_("Passwords do not match; please retype them."))
        supported_langs = [lang['code'] for lang in request.env[
            'res.lang'].sudo().search_read([], ['code'])]
        if request.lang in supported_langs:
            values['lang'] = request.lang
        self._signup_with_values(qcontext.get('token'), values)
        request.env.cr.commit()

    @http.route('/web/signup', type='http', auth='public', website=True,
                sitemap=False)
    def web_auth_signup(self, *args, **kw):
        qcontext = self.get_auth_signup_qcontext()
        qcontext['states']  = request.env['res.country.state'].sudo().search([])
        qcontext['cities']  = request.env['res.city'].sudo().search([])
        qcontext['suburbs'] = request.env['geographies.suburbs'].sudo().search([])
        qcontext['areas']   = request.env['geographies.areas'].sudo().search([])
        qcontext['countries'] = request.env['res.country'].sudo().search([])

        if not qcontext.get('token') and not qcontext.get('signup_enabled'):
            raise werkzeug.exceptions.NotFound()

        if 'error' not in qcontext and request.httprequest.method == 'POST':
            try:
                self.do_signup(qcontext)
                # Send an account creation confirmation email
                if qcontext.get('token'):
                    user_sudo = request.env['res.users'].sudo().search(
                        [('login', '=', qcontext.get('login'))])
                    template = request.env.ref(
                        'auth_signup.mail_template_user_signup_account_created',
                        raise_if_not_found=False)
                    if user_sudo and template:
                        template.sudo().with_context(
                            lang=user_sudo.lang,
                            auth_login=werkzeug.url_encode({
                                'auth_login': user_sudo.email
                            }),
                        ).send_mail(user_sudo.id, force_send=True)
                return super(AuthSignupHome, self).web_login(*args, **kw)
            except UserError as e:
                qcontext['error'] = e.name or e.value
            except (SignupError, AssertionError) as e:
                if request.env["res.users"].sudo().search(
                        [("login", "=", qcontext.get("login"))]):
                    qcontext["error"] = _(
                        "Another user is already registered using this email address.")
                else:
                    _logger.error("%s", e)
                    qcontext['error'] = _("Could not create a new account.")

        response = request.render('auth_signup.signup', qcontext)
        response.headers['X-Frame-Options'] = 'DENY'
        return response



class sbizEcomCheckout(WebsiteSale):

    @http.route(['/shop/checkout'], type='http', auth="public", website=True)
    def checkout(self, **post):
        res = super(sbizEcomCheckout, self).checkout(**post)
        order = request.website.sale_get_order()    # force_create=1
        min_ord_amt = float(request.env['ir.config_parameter'].sudo().get_param('fmcg_crm.minimum_cart_value'))
        values = {}
        if order.amount_untaxed <= min_ord_amt:
            values = {
                'error_code': order.amount_untaxed,
                'error_message': ' Cart Amount needs to be more than Rs.250/- to checkout.'
            }
            return request.redirect("/shop/cart")
#            return request.render("fmcg_crm.sbiz_website_sale_cart_errors", values)
        if post.get('order_comments'):
            order.write({'order_comments': post.get('order_comments')})

        return res


class WebsiteSale(WebsiteSale):

    """Add Customer comment functions to the website_sale controller."""
    @http.route(['/shop/customer_comment'], type='json', auth="public", methods=['POST'], website=True)
    def customer_comment(self, **post):
        """ Json method that used to add a
        comment when the user clicks on 'pay now' button.
        """

        if post.get('comment'):
            order = request.website.sale_get_order()
            redirection = self.checkout_redirection(order)
            if redirection:
                return redirection

            if order and order.id:
                order.write({'customer_comment': post.get('comment')})

        return True



class sbizEcomDelivery(WebsiteSale):

    """Add Delivery Slot functionality to the website_sale controller."""
    @http.route(['/shop/delivery_slot'], type='json', auth="public", methods=['POST'], website=True)
    def delivery_slot(self, **post):
        """ Json method that used to add a
        delivery slot details when the user clicks on 'pay now' button.
        """
        # data = request.httprequest.data
        if post.get('index'):
            order  = request.website.sale_get_order()
            routes = request.env['sale.order'].delivery_slots(order.partner_id)
            index  = post.get('index')
            _logger.info('\n\n\nData as received = %s\n%s\n' % (routes,index))
            _logger.info('Route Data = %s\n\n\n' % routes[index]['route_name'])
            redirection = self.checkout_redirection(order)
            if index < 0:
                return request.redirect('/shop/payment/')
            if redirection:
                return redirection

            if order and order.id:
                delivery_time = datetime.min.time()
                delivery_date = datetime.combine(routes[index]['delivery_date'], delivery_time)
                delivery_date = delivery_date + timedelta(hours=int((routes[index]['end_time'])[:2]), 
                              minutes=int((routes[index]['end_time'])[3:]))
                delivery_date = delivery_date - timedelta(hours=5, minutes=30)
                write_rec = {
                    'slot_id': routes[index]['dslot_id'],
                    'requested_date': delivery_date,
                    'commitment_date': delivery_date
                }
                order.write(write_rec)

        return True
