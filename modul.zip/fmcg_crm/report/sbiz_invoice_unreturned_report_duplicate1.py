# -*- coding: utf-8 -*-
from odoo import models,fields,api,_
from datetime import datetime, timedelta, date, time, timezone
from odoo.exceptions import UserError,ValidationError
from itertools import groupby


class PackingListWizard(models.TransientModel):
    _name = "unreturned.materials.wizard"

    unreturned_material_date = fields.Date(string='UnReturned Material Date', required=True,default=lambda self: date.today())
    company_id = fields.Many2one(
    'res.company',
    'Company',store=True,readonly=True,
    default=lambda self: self.env.user.company_id 
    ) 
    
    
    @api.multi
    def generate_report(self):
        # self.env['delivery.list'].search([]).unlink() 
        if not self.unreturned_material_date:
            raise UserError(_('Please enter Returned  date to continue ...'))
            return
        il=[]
        comp=[]
        comp_detail={}
        comp_detail={
            'company_name':self.company_id.name,
            'company_logo':self.company_id.logo,
        }
        il.append(self.unreturned_material_date.strftime('%d-%m-%Y'))
        account_invoice_packing_items_obj = self.env['account.invoice.packing_items'].read_group([('date_return','<=',self.unreturned_material_date),('is_return','=',False)] ,fields=['product_id','invoice_id','qty_used','remarks','date_return','qty_return'], groupby=['product_id','invoice_id','qty_used','remarks','date_return','qty_return'],lazy=False)
        if account_invoice_packing_items_obj:
            datas=[]
            customer_list=[]
            add={}
            for lead in account_invoice_packing_items_obj:
                product_obj = self.env['product.product'].search([('id','=',lead['product_id'][0])])
                print('product_obj',product_obj)
                account_invoice_obj = self.env['account.invoice'].search([('id','=',lead['invoice_id'][0])])
                sale_order_obj =  self.env['sale.order'].search([('name','=',account_invoice_obj.origin)])
                if account_invoice_obj.partner_id.name not in customer_list:
                    customer_list.append(account_invoice_obj.partner_id.name)
                else:
                    pass
                add={
                    'invoice_name':account_invoice_obj.number,
                    'customer_name':account_invoice_obj.partner_id.name,
                    'invoice_date':account_invoice_obj.date_invoice.strftime('%d-%m-%Y'),
                    'order_name':account_invoice_obj.origin,
                    'order_date':sale_order_obj.date_order.strftime('%d-%m-%Y') if sale_order_obj.date_order else False,
                    'invoice_amount':account_invoice_obj.amount_total,
                    'product_name':product_obj.product_tmpl_id.name,
                    'used_qty':lead['qty_used'],
                    'returned_qty':lead['qty_return'],
                    'product_sale_price':product_obj.lst_price,
                    'remarks':lead['remarks'],
                    'date_of_return':lead['date_return'],
                }
                print('add',add)
                datas.append(add)
                print("datas",datas)
                data = {
                    'datas':datas,
                    'customer_list':customer_list,
                    'il':il,
                    'comp':comp_detail,
                }
            #     li.append(add)
            #     data={
            #         'datas':li,
            #         'il':il,
            #         'comp':comp_detail
            #     }             
            return self.env.ref('fmcg_crm.invoice_unreturned_materials_wizard_report_id').report_action(self,data=data,config=False)
        else:
            raise ValidationError(_("Record Not Found"))
        # print('sale_order_line_obj',sale_order_line_obj.pop('__domain'))
        # mapping = {(lead['product_id'][0], lead['type']): lead['__count'] 
        # il=[]
        # comp=[]
        # comp_detail={}
        # comp_detail={ 
        #     'company_name':self.company_id.name,
        #     'company_logo':self.company_id.logo,
        # }
        # comp.append(comp_detail)
        # print('comp',comp)
        # il.append(self.delivery_date.strftime('%d-%m-%Y'))
        # il.append(self.type_of)
        # if sale_order_line_obj:
        #     datas=[]
        #     li=[]
            
        #     add={}
        #     for lead in sale_order_line_obj:
        #         product_obj = self.env['product.product'].search([('id','=',lead['product_id'][0])])
        #         print("product_obj",product_obj.product_tmpl_id.name)
        #         if product_obj.product_tmpl_id.categ_id.name not in li:
        #             li.append(product_obj.product_tmpl_id.categ_id.name)
        #         else:
        #             pass
        #         # li.sort()
        #         print("li---",li)
        #         add ={
        #                 'packing_list_wizard_id':self.id,
        #                 'product_id':product_obj.product_tmpl_id.name,
        #                 'product_category_id':product_obj.product_tmpl_id.categ_id.name,
        #                 'packing_size':lead['product_uom_qty'],
        #                 'count_total': lead['__count'],
        #                 'product_uom':product_obj.product_tmpl_id.uom_id.name
                        
        #         }
        #         print("add",add)
               
        #         self.packing_list_ids.create(add)
        #         datas.append(add)
        #         print("datas",datas)
        #         data = {
        #             'datas': datas,
        #             'li':li,
        #             'il':il,
        #             'comp':comp_detail
                    
        #             }
        #     return self.env.ref('fmcg_crm.packing_list_wizard_report_id').report_action(self,data=data,config=False)
    #     # return self.env["report"].get_action(self, 'fmcg_crm.delivery_list_wizard_report_id')
   