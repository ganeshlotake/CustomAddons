from odoo import models, fields, api
from datetime import date,datetime,time,timedelta,timezone
from odoo.exceptions import UserError

class RouteSheetWizard(models.TransientModel):
    _name = 'sale.wizards.route_sheet'

    date = fields.Date(string="Date Of Delivery", required=True)
    delivery_slot = fields.Many2many("geographies.delivery_slot", string="Delivery Slots")

