# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import date,datetime,time,timedelta
from lxml import etree
import pytz
import logging
import calendar
import pymysql
import urllib.request
import urllib.parse
from odoo.tools.safe_eval import safe_eval
from odoo.addons import decimal_precision as dp
from odoo.osv import expression

_logger = logging.getLogger(__name__)

ORDER_STATES = [('draft', 'Quotation'), ('sent', 'Quotation Sent'), ('sale', 'Sales Order'), ('done', 'Locked'), ('cancel', 'Cancelled')]

class OnlineSaleOrders(models.Model):

    _inherit = 'sale.order'
    _order = 'date_order desc, id desc,cust_suburb,cust_area'

    cust_city = fields.Char(related='partner_shipping_id.city_id.name', string='City', store=True)
    cust_suburb = fields.Char(related='partner_shipping_id.suburb_id.name', string="Suburb", store=True)
    cust_area = fields.Char(related='partner_shipping_id.area_id.name', string="Area", store=True)

    customer_comment    = fields.Text('Customer Order Comment', default="No comment")
    slot_id             = fields.Many2one(comodel_name='geographies.delivery_slot', string='Delivery Slot')
    route_id            = fields.Many2one(comodel_name='geographies.routes', string='Delivery Route', related='slot_id.route_id', readonly=True)
    delivery_session    = fields.Selection(related='slot_id.session', string='Session', readonly=True)
    #delivery_start_time = fields.Selection(related='slot_id.time_start', string='Start Time', readonly=True)
    #delivery_end_time   = fields.Selection(related='slot_id.time_finish', string='End Time', readonly=True)
    slotid             = fields.Many2one(comodel_name='geographies.ps_enroutes', string='Delivery Slot')
    routeid            = fields.Many2one(comodel_name='geographies.ps_routes', string='Delivery Route', related='slotid.route_id', readonly=True,store=True)
    delivery_start_time = fields.Selection(related='routeid.start_time', string='Start Time', readonly=True)
    delivery_end_time   = fields.Selection(related='routeid.end_time', string='End Time', readonly=True)
    requested_date      = fields.Datetime(string='Requested Date',states={'draft': [('readonly', False)], 'sent': [('readonly', False)], 'sale': [('readonly', False)]})
    commitment_date     = fields.Datetime(string='Commitment Date')
    actual_delivery_date= fields.Datetime(string='Actual Delivery Date')
    ps_payment          = fields.Char(string="Presta Payment")
    ps_payment_module   = fields.Char(string="Presta Payment Module")
   # state               = fields.Selection([('draft', 'Quotation'),('sent', 'Quotation Sent'),('sale', 'Sales Order'),('done', 'Locked'),
   #     ('cancel', 'Cancelled'), ('delivery', 'Shipped')], string='Status', readonly=True, copy=False, index=True, track_visibility='onchange', track_sequence=3, default='draft')


    @api.model
    def fields_view_get(self, view_id=None, view_type=False, toolbar=False, submenu=False):
        res = super(OnlineSaleOrders,self).fields_view_get(view_id=view_id, view_type=view_type, toolbar=toolbar, submenu=False)
        if res:
            doc = etree.XML(res['arch'])
            if view_type == 'form':
                is_customer_comment_features = False
                search_websites = self.env['website'].search([('id', '!=', False)])

                for setting in search_websites:
                    if setting.is_customer_comment_features:
                        is_customer_comment_features = True

                res['arch'] = etree.tostring(doc)

        return res

	#    @api.multi
	#    def action_confirm(self):
	#        if self.origin and self.ecommerce_channel and self.ecommerce_channel == 'prestashop':
            # ....
        # for line in self.order_line:
        #     product_id = line.product_id
        #     if product_id.convert_unit == True:
        #         line.order_qty = line.product_uom_qty
        #         line.product_uom_qty = line.product_uom_qty * line.product_id.conversion_factor
        #         line.order_rate = line.price_unit
        #         line.price_unit = 1 / line.product_id.conversion_factor * line.price_unit
        #        line.conversion_unit = line.product_id.conversion_unit
        #     else:
        #         line.order_qty = line.product_uom_qty
        #         line.conversion_unit = line.product_id.uom_id
        #        line.order_rate = line.price_unit

        # record = super(OnlineSaleOrders, self).action_confirm()
        # return record

    @api.multi
    def delivery_slots(self, partner_id=None, order_date=None):
        if not partner_id:
            return None

        user_tz = pytz.timezone(self.env.context.get('tz') or self.env.user.tz)

        if not order_date:
            order_date = datetime.now()
            order_date = pytz.utc.localize(order_date).astimezone(user_tz)

        if not partner_id.suburb_id or not partner_id.area_id:
            return None

        maximum_slot_days = int(self.env['ir.config_parameter'].sudo().get_param('fmcg_crm.maximum_slot_days'))
        order_day = order_date.weekday()
        delivery_date_start = order_date
        delivery_date_end   = order_date + timedelta(days=maximum_slot_days)
        delivery_days = []
        routes = self.env['geographies.routes'].search(['&', ('suburb_ids.id', '=', partner_id.suburb_id.id), ('area_ids.id', '=', partner_id.area_id.id)])

        data = []
        route_no = 0
        for ddate in (order_date + timedelta(n) for n in range(min(maximum_slot_days,7))):
            dslots = self.env['geographies.delivery_slot'].search([
                ('route_id', 'in', routes.ids), 
                ('delivery_day', '=', ddate.weekday())])
            for slot in dslots:
                cutoff_date = ddate.date() - timedelta(days=slot.days_cutoff)
                cutoff_date = datetime(
                    year=cutoff_date.year,
                    month=cutoff_date.month,
                    day=cutoff_date.day,
                    hour=int(slot.time_cutoff[:2]),
                    minute=int(slot.time_cutoff[3:])
                )
                cutoff_date = pytz.utc.localize(cutoff_date).astimezone(user_tz)
                if cutoff_date < order_date:
                    continue
                week_day = calendar.day_name[ddate.date().weekday()].ljust(10)
                vals = {
                    'dslot_id': slot.id,
                    'route_id': slot.route_id.id,
                    'route_no': route_no,
                    'route_name': slot.route_id.name,
                    'session': slot.session,
                    'start_time': slot.time_start,
                    'end_time': slot.time_finish,
                    'delivery_date': ddate.date(),
                    'weekday': week_day,
                    'dispstr': week_day[:3] + ' ' + datetime.strftime(ddate, '%d-%b') + ' ' + slot.time_start + '-' + slot.time_finish,
                }
                data.append(vals)
                route_no += 1

        if len(data) == 0:
            data = None

        return data

    @api.multi
    def packing_items(self):
        packing_material = self.env['product.product'].search([('product_category', '=', 'Packing Material')])
        pm_list = []
        for pm_item in packing_material:
            pm_json = {
                'name': pm_item.name,
                'qty': 0,
            }
            pm_list.append(pm_json)
        return pm_list

    @api.model
    def _send_sms(self, numbers, message):
        #UvRmlgwXj5M-Sj4sP9uTYnZL88Ejw5UaMn45jAu5W  MFARMR
        #hExnYm6LVIU-YFeADTUvbRXVjXJdOzkxIC4nqDWMb4 SBIZ
        data =  urllib.parse.urlencode({'apikey': 'UvRmlgwXj5M-Sj4sP9uTYnZL88Ejw5UaMin45jAu5W', 'numbers': numbers,'message' : message, 'sender': 'MFARMR'})
        data = data.encode('utf-8')
        request = urllib.request.Request("https://api.textlocal.in/send/?")
        f = urllib.request.urlopen(request, data)
        fr = f.read()
        print(fr)
        return(fr)

#    @api.multi
#    def action_confirm(self):
#        res = super(OnlineSaleOrders, self).action_confirm()
#        ps_host = self.env['prestashop.configure'].search([('active', '=', True)], limit=1).ps_dbhost
#        ps_user = self.env['prestashop.configure'].search([('active', '=', True)], limit=1).ps_dbuser
#        ps_pass = self.env['prestashop.configure'].search([('active', '=', True)], limit=1).ps_dbpass
#        ps_dbnm = self.env['prestashop.configure'].search([('active', '=', True)], limit=1).ps_dbname
#        ps_pfix = self.env['prestashop.configure'].search([('active', '=', True)], limit=1).ps_prefix
#
#        try:
#            connection = pymysql.connect(host=ps_host, user=ps_user, password=ps_pass, db=ps_dbnm)
#            cursor = connection.cursor()
#        except:
#            raise UserError('No Database Connected! \nHost: %s\nDatabase: %s\nUser: %s\nPassword: %s' % (ps_host, ps_dbnm, ps_user, ps_pass))
#
#        if self.origin:
#            saleorderobj = self.env['sale.order'].search([('origin', '=', self.origin), ('id', '=', self.id)])
#            if saleorderobj:
#                query1 = "SELECT message as msg FROM %smessage WHERE id_order IN (SELECT id_order FROM %sorders WHERE reference='%s')" % (ps_pfix, ps_pfix, self.origin.replace('Prestashop-', ''))
##                query1 = "SELECT m.message as msg FROM %sorders as o inner join %smessage as m on o.id_order=m.id_order where o.reference=%s" % (ps_pfix, ps_pfix, self.origin.replace('Prestashop-', ''))
#                cursor.execute(query1)
#                result=', ,'.join([str(i[0]) for i in cursor.fetchall()])
#                if  cursor.rowcount > 0:
#                    saleorderobj.customer_comment = result
#                connection.commit()


class OnlineSaleOrderLines(models.Model):

    _inherit = 'sale.order.line'

    @api.one
    @api.depends('product_id')
    def get_conversion_unit(self):
        self.conversion_unit = self.product_id.conversion_unit
	#         for item in self:
	#             item.conversion_unit = self.env['product.product'].browse(item.product_id).conversion_unit


    order_qty = fields.Float(string='Web Ord.Qty.')
    allocated_qty = fields.Float('Allocated Qty.',digits=dp.get_precision('Product Unit of Measure'))
    order_rate = fields.Float(string='Order Rate')
    conversion_unit = fields.Many2one(comodel_name='product.uom', default=get_conversion_unit, string="New UoM")
    requested_date = fields.Datetime(related='order_id.requested_date', string='Requested Date', readonly=True)
    partner_id = fields.Many2one(related='order_id.partner_id', comodel_name='res.partner', string='Customer', store=True)
    order_no = fields.Char(related='order_id.name', string='Order No', store=True)
    date_order = fields.Datetime(related='order_id.date_order', string='Order Date', store=True)
    cust_city = fields.Char(related='order_id.partner_shipping_id.city_id.name', string='City', store=True)
    cust_suburb = fields.Char(related='order_id.partner_shipping_id.suburb_id.name', string="Suburb", store=True)
    cust_area = fields.Char(related='order_id.partner_shipping_id.area_id.name', string="Area", store=True)
    order_state = fields.Selection(related='order_id.state', selection=ORDER_STATES, string='Status')
    #added by ajinkya joshi on 09-03-2020
    categ_id = fields.Many2one(related='product_id.categ_id',string='Product Category',store=True)

class StockPicking(models.Model):

    _inherit = 'stock.picking'
    allocation_done = fields.Boolean("Allocated ?")

    @api.multi
    def button_validate(self):
        result = super(StockPicking, self).button_validate()
        if self.group_id.sale_id:
#            self.group_id.sale_id.state = 'delivery'
            if self.group_id.sale_id.origin:
                if self.group_id.sale_id.ps_payment:
                    if '(COD)' in self.group_id.sale_id.ps_payment or 'Check' in self.group_id.sale_id.ps_payment:
                        msg = 'Order ref: '+ self.group_id.sale_id.origin +' is being shipped. Invoice Amount: Rs. '+ str(self.group_id.sale_id.amount_total) +', Payment Mode: cash, Payment Status: DUE- Keep <cash/cheque> ready'
                    elif 'Bank' in self.group_id.sale_id.ps_payment:
                        msg = 'Order ref: '+ self.group_id.sale_id.origin +' is being shipped. Invoice Amount: Rs. '+ str(self.group_id.sale_id.amount_total) +' Payment Mode: BANK Payment Status: Please SMS/W-App UTR to '+str(self.company_id.phone)+''                
                    else:
                        msg = 'Order ref: '+ self.group_id.sale_id.origin +' is being shipped. Invoice Amount: Rs. '+ str(self.group_id.sale_id.amount_total) +', Payment Mode: cash/cheque, Payment Status: DUE- Keep <cash/cheque> ready'

                    self.group_id.sale_id._send_sms(self.partner_id.phone,msg)
        return result

class AllocateSaleQty(models.Model):

    _inherit = 'stock.move'

    allocated_qty = fields.Float('Alloc.Qty.')





class AccountInvoiceExtended(models.Model):

    _inherit = 'account.invoice'

    packing_ids    = fields.One2many(comodel_name='account.invoice.packing_items', inverse_name='invoice_id', string='Packing Items')
    order_id       = fields.Many2one(comodel_name='sale.order', string='Sale Order', store=True)
    requested_date = fields.Datetime(related='order_id.requested_date', string='Delivery Date', store=True, readonly=True)
    slot_id        = fields.Many2one(related='order_id.slot_id', string='Delvery Slot', store=True, readonly=True)
    slotid         = fields.Many2one(comodel_name='geographies.ps_enroutes', related='order_id.slotid', string='Delvery Slot', store=True)
    cust_city      = fields.Char(related='partner_shipping_id.city_id.name', string='City', store=True)
    cust_suburb    = fields.Char(related='partner_shipping_id.suburb_id.name', string="Suburb", store=True)
    cust_area      = fields.Char(related='partner_shipping_id.area_id.name', string="Area", store=True)





class AccountInvoicePackingItems(models.Model):

    _name = 'account.invoice.packing_items'
    _description = 'List of Packing Items in Invoices'

    invoice_id = fields.Many2one(comodel_name='account.invoice', string='Invoice')
    product_id = fields.Many2one(comodel_name='product.product', string='Packing Item',domain=[('product_category', '=', 'Packing Material')], required=True)
    qty_used   = fields.Integer(string='Quantity', required=True)
    remarks    = fields.Char(string='Remarks')
    is_return  = fields.Boolean(string='Returned To Inventory')
    date_return = fields.Date(string='Date of Return',default=lambda self:date.today())
    qty_return = fields.Integer(string='Returned Qty.')


    def compute_bal(self, qty_used=0, qty_return=0):
        return (qty_used - qty_return)

   #added by ajinkya joshi on 21-03-2020
    # as qty_return get values then is_return fields gets True
    @api.onchange('qty_return')
    def onchange_qty_return(self):
        for order in self:
            if order.qty_return:
                order.is_return = True


class sbizPOBextended(models.Model):

    _inherit = 'prestashop.configure'

    ps_dbname = fields.Char(string='Prestashop DB Name', required=True)
    ps_dbhost = fields.Char(string='Prestashop DB Host', required=True)
    ps_dbuser = fields.Char(string='Prestashop DB User', required=True)
    ps_dbpass = fields.Char(string='Prestashop DB Pass', required=True)
    ps_prefix = fields.Char(string='Prestashop Table Prefix', required=True)


class AccountInvoiceRefund(models.TransientModel):

    """Credit Notes"""
    _inherit = "account.invoice.refund"
    _description = "Credit Note"

    description = fields.Many2one('reason.master',string='Reason', required=True)

    @api.multi
    def compute_refund(self, mode='refund'):
        inv_obj = self.env['account.invoice']
        inv_tax_obj = self.env['account.invoice.tax']
        inv_line_obj = self.env['account.invoice.line']
        context = dict(self._context or {})
        xml_id = False
        for form in self:
            created_inv = []
            date = False
            description = False
            for inv in inv_obj.browse(context.get('active_ids')):
                if inv.state in ['draft', 'cancel']:
                    raise UserError(_('Cannot create credit note for the draft/cancelled invoice.'))
                if inv.reconciled and mode in ('cancel', 'modify'):
                    raise UserError(_('Cannot create a credit note for the invoice which is already reconciled, invoice should be unreconciled first, then only you can add credit note for this invoice.'))

                date = form.date or False
                description = form.description.reason or inv.name
                refund = inv.refund(form.date_invoice, date, description, inv.journal_id.id)
                created_inv.append(refund.id)
                if mode in ('cancel', 'modify'):
                    movelines = inv.move_id.line_ids
                    to_reconcile_ids = {}
                    to_reconcile_lines = self.env['account.move.line']
                    for line in movelines:
                        if line.account_id.id == inv.account_id.id:
                            to_reconcile_lines += line
                            to_reconcile_ids.setdefault(line.account_id.id, []).append(line.id)
                        if line.reconciled:
                            line.remove_move_reconcile()
                    refund.action_invoice_open()
                    for tmpline in refund.move_id.line_ids:
                        if tmpline.account_id.id == inv.account_id.id:
                            to_reconcile_lines += tmpline
                    to_reconcile_lines.filtered(lambda l: l.reconciled == False).reconcile()
                    if mode == 'modify':
                        invoice = inv.read(inv_obj._get_refund_modify_read_fields())
                        invoice = invoice[0]
                        del invoice['id']
                        invoice_lines = inv_line_obj.browse(invoice['invoice_line_ids'])
                        invoice_lines = inv_obj.with_context(mode='modify')._refund_cleanup_lines(invoice_lines)
                        tax_lines = inv_tax_obj.browse(invoice['tax_line_ids'])
                        tax_lines = inv_obj._refund_cleanup_lines(tax_lines)
                        invoice.update({
                            'type': inv.type,
                            'date_invoice': form.date_invoice,
                            'state': 'draft',
                            'number': False,
                            'invoice_line_ids': invoice_lines,
                            'tax_line_ids': tax_lines,
                            'date': date,
                            'origin': inv.origin,
                            'fiscal_position_id': inv.fiscal_position_id.id,
                        })
                        for field in inv_obj._get_refund_common_fields():
                            if inv_obj._fields[field].type == 'many2one':
                                invoice[field] = invoice[field] and invoice[field][0]
                            else:
                                invoice[field] = invoice[field] or False
                        inv_refund = inv_obj.create(invoice)
                        body = _('Correction of <a href=# data-oe-model=account.invoice data-oe-id=%d>%s</a><br>Reason: %s') % (inv.id, inv.number, description)
                        inv_refund.message_post(body=body)
                        if inv_refund.payment_term_id.id:
                            inv_refund._onchange_payment_term_date_invoice()
                        created_inv.append(inv_refund.id)
                xml_id = inv.type == 'out_invoice' and 'action_invoice_out_refund' or \
                         inv.type == 'out_refund' and 'action_invoice_tree1' or \
                         inv.type == 'in_invoice' and 'action_invoice_in_refund' or \
                         inv.type == 'in_refund' and 'action_invoice_tree2'
        if xml_id:
            result = self.env.ref('account.%s' % (xml_id)).read()[0]
            if mode == 'modify':
                # When refund method is `modify` then it will directly open the new draft bill/invoice in form view
                if inv_refund.type == 'in_invoice':
                    view_ref = self.env.ref('account.invoice_supplier_form')
                else:
                    view_ref = self.env.ref('account.invoice_form')
                result['views'] = [(view_ref.id, 'form')]
                result['res_id'] = inv_refund.id
            else:
                invoice_domain = safe_eval(result['domain'])
                invoice_domain.append(('id', 'in', created_inv))
                result['domain'] = invoice_domain
            return result
        return True





class ReasonMaster(models.Model):
    _name = 'reason.master'
    _rec_name = 'reason'
    _description = "Reason Master"

    reason = fields.Char(string='Reason', required=True)
