# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

PS_COUNTRY_ID   = 110     # India = 110 in Prestashop
PS_STATE_ID     = 339     # Maharashtra = 339 in Prestashop
ODOO_COUNTRY_ID = 104     # India = 104 in Odoo
ODOO_STATE_ID   = 597     # Maharashtra = 597 in Odoo

class GeoCitiesExt(models.Model):

    _inherit = 'res.city'

    ps_id_city = fields.Integer(string='Prestashop City ID')


class GeoCitiesWizard(models.TransientModel):

    _name = 'res.city.transient'

    sync_direction = fields.Selection(selection=[('odoo2ps', 'Odoo To Prestashop'), ('ps2odoo', 'Prestashop To Odoo')], string='Synchronize Direction', default='odoo2ps')

	@api.multi
	def sync_city_prestashop(self):
        
		ps_host = self.env['prestashop.configure'].search([('active', '=', True)], limit=1).ps_dbhost
        ps_user = self.env['prestashop.configure'].search([('active', '=', True)], limit=1).ps_dbuser
        ps_pass = self.env['prestashop.configure'].search([('active', '=', True)], limit=1).ps_dbpass
        ps_dbnm = self.env['prestashop.configure'].search([('active', '=', True)], limit=1).ps_dbname
        ps_pfix = self.env['prestashop.configure'].search([('active', '=', True)], limit=1).ps_prefix

        connection = pymysql.connect(host=ps_host, user=ps_user, password=ps_pass, db=ps_dbnm)
        if not connection:
            raise UserError('No Database Connected! \nHost: %s\nDatabase: %s\nUser: %s\nPassword: %s' % (ps_host, ps_dbnm, ps_user, ps_pass))

        cursor = connection.cursor()
        
        if self.sync_direction == 'odoo2ps':
            odoo_cities = self.env['res.city'].search([])
            for city in odoo_cities:
                if city.ps_id_city and city.ps_id_city != 0:
                    qr1 = "SELECT id_city FROM %scity WHERE id_city = %s" % (city.ps_id_city)
                    cursor.execute(qr1)
                    rs1 = cursor.fetchall()
                    if rs1:
                        qry = """UPDATE %scity 
                            SET id_country = %s id_state = %s city_name = '%s' erp_city_id = %s active = %s 
                            WHERE id_city = %s""" % (ps_pfix, PS_COUNTRY_ID, PS_STATE_ID, city.name, city.id, city.active, city.ps_id_city)
                    else:
                        qry = """INSERT INTO %city
                            (id_country, id_state, city_name, active, erp_city_id) 
                            VALUES (%s, %s, %s, %s, %s, %s)""" % (ps_pfix, PS_COUNTRY_ID, PS_STATE_ID, city.name, city.active, city.id)
                else:
                    rs1 = None
                    qry = """INSERT INTO %city
                        (id_country, id_state, city_name, active, erp_city_id) 
                        VALUES (%s, %s, %s, %s, %s, %s)""" % (ps_pfix, PS_COUNTRY_ID, PS_STATE_ID, city.name, city.active, city.id)
                
                cursor.execute(qry)
                connection.commit()
                if not rs1:
                    qr1 = "SELECT id_city FROM %scity WHERE city_name = %d ORDER BY id_city LIMIT 1" % (ps_pfix, city.name)
                    cursor.execute(qr1)
                    rs1 = cursor.fetchall()
                    ps_id_city = rs1[0][0]
                    city.ps_id_city = ps_id_city
        else:
            ps_qry = "SELECT id_city, id_country, id_state, city_name, active, erp_city_id FROM %scity" & (ps_pfix)
            cursor.execute(ps_qry)
            ps_cities = cursor.fetchall()
            for city in ps_cities:
                id_city     = city[0]
                id_country  = ODOO_COUNTRY_ID
                id_state    = ODOO_STATE_ID
                city_name   = city[3]
                active      = city[4]
                erp_city_id = city[5]
                if erp_city_id and erp_city_id != 0:
                    rs1 = self.env['res.city'].browse(erp_city_id)
                    if rs1:
                        rs1.name, rs1.active, rs1.ps_id_city, rs1.id_country, rs1.id_state = city_name, active, id_city, id_country, id_state
                    else:
                        newid = self.env['res.city'].create({
                            'name'       : city_name,
                            'ps_id_city' : id_city,
                            'id_country' : id_country,
                            'id_state'   : id_state,
                            'active'     : active,
                        })
                        cursor.execute("UPDATE %scity SET erp_city_id = %s WHERE id_city = %s" % (ps_pfix, newid, id_city))
                        connection.commit()

