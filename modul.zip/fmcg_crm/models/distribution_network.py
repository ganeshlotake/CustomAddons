# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

class NetworkNodes(models.Model):

	_name = "network.nodes"
	_description = "Distribution Network Nodes"
	
	name = fields.Char(string="Network Node", stored=True, required=True, 
			help="Enter a Distribution Network Node here. This could be, for example, C&F Agent, Super Distributor, Distributor, Retailer, etc.")
	channel_id = fields.Many2one('crm.team', string='Sales Channel', stored=True)
	parent_id = fields.Many2one('network.nodes', string='Parent Node', stored=True)
	child_ids = fields.One2many('network.nodes', 'parent_id', 'Child Nodes')
