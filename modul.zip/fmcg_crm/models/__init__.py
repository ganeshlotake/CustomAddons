# -*- coding: utf-8 -*-

from . import geographies
#from . import geographies_ezxtend
from . import fmcg_partner
from . import fmcg_sale
from . import product_extended
from . import fmcg_sale_allocate
from . import sbiz_ecom_delivery
from . import sbiz_ecom_config
#from . import fmcg_sale_order_extended
from . import account_invoice_inherit
from . import stock_picking_inhe
#from . import fmcg_sale_pob_extend
from . import fmcg_purchase
from . import geographies_ps_enroute
from . import geographies_ps_routes
