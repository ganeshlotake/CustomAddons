from datetime import datetime
from dateutil.relativedelta import relativedelta

from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.osv import expression
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.tools.float_utils import float_compare
from odoo.exceptions import UserError, AccessError
from odoo.tools.misc import formatLang
from odoo.addons import decimal_precision as dp


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"    
    _description = "Purchase Order"
    _order = 'date_order desc, id desc'

    last_sale_date = fields.Date('Last Week Sale Date',  index=True, copy=False, help="Set Last week Sale Date")

    @api.onchange('last_sale_date')
    def get_last_weekSum_and_onHand_qty(self):
        if self.order_line:
            for line in self.order_line:
                self.env.cr.execute("""select sum(sl.product_uom_qty),sq.quantity 
                                from sale_order_line sl 
                                inner join sale_order so on sl.order_id = so.id
                                inner join stock_quant sq on sl.product_id=sq.product_id and sq.location_id=12
                                where sl.product_id  = %s and TO_CHAR(so.date_order :: DATE, 'yyyy-mm-dd')='%s'	
                                group by sq.quantity""" % (line.product_id.id, self.last_sale_date))

                sale_data = self._cr.fetchone()
                if sale_data:
                    line.last_week_sale_qty = sale_data[0]
                line.qty_on_hand = line.product_id.qty_available

class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'
    _description = 'Purchase Order Line'
    _order = 'order_id, sequence, id'


    last_week_sale_qty = fields.Float(string='Last Sale Qty.', digits=dp.get_precision('Product Unit of Measure'))
    qty_on_hand = fields.Float(string='Qty. on Hand', digits=dp.get_precision('Product Unit of Measure'))

    @api.onchange('product_id')
    def get_last_weekSum_and_onHand_qty(self):        
        if self.product_id:                
            self.env.cr.execute("""select sum(sl.product_uom_qty),sq.quantity 
                                from sale_order_line sl 
                                inner join sale_order so on sl.order_id = so.id
                                inner join stock_quant sq on sl.product_id=sq.product_id and sq.location_id=12
                                where sl.product_id  = %s and TO_CHAR(so.date_order :: DATE, 'yyyy-mm-dd')='%s'	
                                group by sq.quantity""" % (self.product_id.id, self.order_id.last_sale_date))
            
            sale_data = self._cr.fetchone()
            if sale_data:        
                self.last_week_sale_qty = sale_data[0]
                self.qty_on_hand = sale_data[1]

    




