from odoo import fields,api,_,models


class StockPicking(models.Model):
    _inherit= "stock.picking"
    
    
    packed_by =fields.Many2one(related="sale_id.packing_person_id",store=True)
    picked_by =fields.Many2one(related="sale_id.picking_person_id",store=True)
    
   # current_user = fields.Many2one('res.users',default=lambda self: self.env.user.id)
