# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from dateutil.relativedelta import relativedelta
from datetime import date, datetime, time, timedelta, timezone
from odoo import api, fields, models, _
import logging
import json
import sys

_logger = logging.getLogger(__name__)

class ValidateSalesman(models.Model):
    
    _inherit = 'res.users'
    
    @api.model
    def validate_login(self, logged_user_id):
        
        uid = json.dumps(logged_user_id)
        uid = json.loads(uid)
        usr = uid['logged_user_id']
        
        self.env.cr.execute("""SELECT id, name, x_salesforce FROM hr_employee WHERE resource_id IN 
                                         (SELECT id FROM resource_resource WHERE user_id = %s) ORDER BY id""" % (usr))
        
        rec = self.env.cr.dictfetchall()
        
        # rec = self.env['hr.employee'].search([('user_id', '=', logged_user_id)])
        if not rec or len(rec) == 0:
            retval = {'authentication': False, 'message': 'Unauthorised Employee!', 'employee_id': 0, 'employee_name': 'Invalid Name'}
            return retval
        
        record = rec[0]
        empid = record['id']
        slfrc = record['x_salesforce']
        ename = record['name']
        
        if slfrc == True:
            retval = {'authentication': True, 'message': 'Success!', 'employee_id': empid, 'employee_name': ename}
        else:
            retval = {'authentication': False, 'message': 'Unauthorised Employee!', 'employee_id': 0, 'employee_name': 'Invalid Name'}
        
        return retval



class StartDay(models.Model):
    
    _name = 'fmcg.salesman_session'
    _description = 'FMCG Salesman Session'

    employee_id = fields.Many2one('hr.employee', string="Employee", required=True, ondelete='cascade', index=True)
    date = fields.Date("Date", default=lambda self: date.today())
    check_in = fields.Datetime('Check In')
    check_out = fields.Datetime('Check Out')
    chkin_lat = fields.Char(string='Check In Latitude')
    chkin_lon = fields.Char(string='Check In Longitude')
    chkout_lat = fields.Char(string='Check Out Latitude')
    chkout_lon = fields.Char(string='Check Out Longitude')
    partner_id = fields.Many2one('res.partner', string='Distributor')
    route_ids = fields.Many2many('geographies.routes', string='Routes', stored=True)
    outlet_count = fields.Integer('No. of Outlets')
    outlet_visit = fields.Integer('Outlets Visited')
    calls_prod = fields.Integer('Productive Calls')
    calls_nprod = fields.Integer('Non Productive Calls')
    session_state = fields.Boolean('Day end done?')
    retailer_ids = fields.One2many(comodel_name='fmcg.salesman_session.retailers', inverse_name='session_id', string='Retailers')
    
    @api.model
    def startday_distributors(self, employeeid=False):
        
        emp = json.dumps(employeeid)
        emp = json.loads(emp)
        usr = emp['employeeid']
        empname = self.env['hr.employee'].browse(usr).name
       
        retval = {'employeeid': usr, 
                   'success': False,
                   'message': '',
                   'distributors': [],
                 }

        dist_rec = self.env['fmcg.salesforce']
        ids_needed = dist_rec.search([('employee_id', '=', usr)]).distributor_ids.ids

        if not ids_needed or len(ids_needed) == 0:
            retval['message'] = 'No Distributors Assigned to %s' % (empname)
            retval['success'] = False
            retval['distributors'] = []
            return retval
        
        dist_list = self.env['res.partner'].browse(ids_needed)
        distributors = []

        for dist in dist_list:
            distributors.append({
                'distributor_id': dist.id, 
                'distributor_name': dist.name, 
                'distributor_routes': dist.route_id.ids,
                })
        
        retval['success'] = True
        retval['distributors'] = distributors
        retval['message'] = 'Success!'
        return retval


    @api.model
    def startday_routes(self, employeeid=False):
        
        emp = json.dumps(employeeid)
        emp = json.loads(emp)
        usr = emp['employeeid']
        empname = self.env['hr.employee'].browse(usr).name
        
        retval = {'employeeid': usr, 
                   'success': False,
                   'message': '',
                   'routes': [],
                 }
        
        dist_list = self.startday_distributors(employeeid)
        
        if not dist_list['success']:
            retval['message'] = 'No Distributors assigned to %s' % empname
            return retval
        
        route_ids = []
        for dist_route in dist_list['distributors']:
            for c in range(len(dist_route['distributor_routes'])):
                route_ids.append(dist_route['distributor_routes'][c])
        
        route_ids = list(set(route_ids))
        route_recs = self.env['geographies.routes'].browse(route_ids)
        
        if not route_recs or len(route_recs) == 0 or route_recs == False:
            retval['message'] = 'No routes for selected distributors'
            return retval
        
        route_list = []
        for n in range(len(route_recs)):
            
            suburb_recs = self.env['geographies.suburbs'].browse(route_recs[n].suburb_ids.ids)
            suburb_list = []
            for sl in suburb_recs:
                suburb_list.append({'suburb_id': sl.id, 'suburb_name': sl.name})

            area_recs = self.env['geographies.areas'].browse(route_recs[n].area_ids.ids)
            area_list = []
            for al in area_recs:
                area_list.append({'area_id': al.id, 'area_name': al.name})

            route_list.append({
                'route_id': route_recs[n].id,
                'route_name': route_recs[n].name,
                'route_suburb': suburb_list,     # route_recs[n].suburb_ids.ids,
                'route_area': area_list,         # route_recs[n].area_ids.ids,
                })
        
        retval['routes'] = route_list
        retval['success'] = True
        retval['message'] = 'Success!'
        
        return retval
    
    
    @api.model
    def startday_retailers(self, employeeid=False):
        
        emp = json.dumps(employeeid)
        emp = json.loads(emp)
        usr = emp['employeeid']
        empname = self.env['hr.employee'].browse(usr).name
        
        retval = {'employeeid': usr, 
                   'success': False,
                   'message': '',
                   'retailers': [],
                 }

        dist_list = self.startday_distributors(employeeid)
        if not dist_list['success']:
            retval['message'] = 'No Distributors assigned to %s' % empname
            return retval
        
        route_list = self.startday_routes(employeeid)
        if not route_list['routes'] or route_list['routes'] == False or len(route_list['routes']) == 0:
            retval['success'] = False
            retval['message'] = 'No Routes Found for selected Distributors'
            return retval
        
        areas = []
        suburbs = []
        for rt in route_list['routes']:
            
            for c in range(len(rt['route_suburb'])):
                sbb = json.dumps(rt['route_suburb'][c])
                sbb = json.loads(sbb)
                sid = sbb['suburb_id']
                suburbs.append(sid)
            
            for d in range(len(rt['route_area'])):
                arx = json.dumps(rt['route_area'][d])
                arx = json.loads(arx)
                aid = arx['area_id']
                areas.append(aid)
        
        areas = list(set(areas))
        suburbs = list(set(suburbs))
        ret_list = self.env['res.partner'].search([('suburb_id.id', 'in', suburbs), ('area_id.id', 'in', areas), ('nodes_id.name', '=', 'Retailer')])
        retailers = []
        date_end = date.today()
        date_end = date_end - timedelta(days=(date_end.weekday()+1))
        date_start = date_end - timedelta(days=70)
        dt_today = date.today()
        if dt_today.month <= 3:
            date_ytd = date(dt_today.year - 1, 4, 1)
        else:
            date_ytd = date(dt_today.year, 1, 4)
        date_mtd = date(dt_today.year, dt_today.month, 1)

        for n in range(len(ret_list)):

            retailerid = ret_list[n].id
            retailersum = self.env.cr.execute("""SELECT count(*) as numbers, sum(gross_total) as gross, 
                sum(disamt_total) as discount, sum(taxamt_total) as taxamt, sum(amount_total) as amount 
                FROM sale_retailorder WHERE customer_id = %s AND date >= '%s' AND date <= '%s'""" % 
                    (retailerid, date_start, date_end))
            retailersum = self.env.cr.dictfetchall()
            
            retailerytd = self.env.cr.execute("""SELECT count(*) as numbers, sum(gross_total) as gross, 
                sum(disamt_total) as discount, sum(taxamt_total) as taxamt, sum(amount_total) as amount 
                FROM sale_retailorder WHERE customer_id = %s AND date >= '%s' AND date <= '%s'""" % 
                    (retailerid, date_ytd, dt_today))
            retailerytd = self.env.cr.dictfetchall()

            retailermtd = self.env.cr.execute("""SELECT count(*) as numbers, sum(gross_total) as gross, 
                sum(disamt_total) as discount, sum(taxamt_total) as taxamt, sum(amount_total) as amount 
                FROM sale_retailorder WHERE customer_id = %s AND date >= '%s' AND date <= '%s'""" % 
                    (retailerid, date_mtd, dt_today))
            retailermtd = self.env.cr.dictfetchall()

            retailersum = retailersum[0]
            if retailersum['numbers'] == 0:
                retailersum['gross'] = 0.00
                retailersum['discount'] = 0.00
                retailersum['taxamt'] = 0.00
                retailersum['amount'] = 0.00

            retailerytd = retailerytd[0]
            if retailerytd['numbers'] == 0:
                retailerytd['gross'] = 0.00
                retailerytd['discount'] = 0.00
                retailerytd['taxamt'] = 0.00
                retailerytd['amount'] = 0.00

            retailermtd = retailermtd[0]
            if retailermtd['numbers'] == 0:
                retailermtd['gross'] = 0.00
                retailermtd['discount'] = 0.00
                retailermtd['taxamt'] = 0.00
                retailermtd['amount'] = 0.00

            ret_addr = ", ".join([ret_list[n].area_id.name, ret_list[n].suburb_id.name, ret_list[n].city])

            retailers.append({
                'retailer_id': ret_list[n].id, 
                'retailer_name': ret_list[n].name, 
                'retailer_address': ret_addr, 
                'suburb_id': ret_list[n].suburb_id.id, 
                'area_id': ret_list[n].area_id.id,
                'mobile': ret_list[n].mobile,
                'num_orders': retailersum['numbers'], 
                'gross': retailersum['gross'], 
                'discount': retailersum['discount'], 
                'tax_amount': retailersum['taxamt'], 
                'amount': retailersum['amount'],
                'num_orders_ytd': retailerytd['numbers'], 
                'gross_ytd': retailerytd['gross'], 
                'discount_ytd': retailerytd['discount'], 
                'tax_amount_ytd': retailerytd['taxamt'], 
                'amount_ytd': retailerytd['amount'],
                'num_orders_mtd': retailermtd['numbers'], 
                'gross_mtd': retailermtd['gross'], 
                'discount_mtd': retailermtd['discount'], 
                'tax_amount_mtd': retailermtd['taxamt'], 
                'amount_mtd': retailermtd['amount'],
                })
        
        retval['success'] = True
        retval['retailers'] = retailers
        retval['message'] = 'Success!'
        
        return retval
    
    
    @api.model
    def startday_write(self, startday=False):
        
        if startday == False:
            return {
                'employee_id': empid,
                'success': False, 
                'message': 'Missing Required Parameters', 
                }

        empid = startday['employee_id']
        empname = self.env['hr.employee'].browse(empid).name
#        rcd_json = json.dumps(startday)
#        rcd_json = json.loads(rcd_json)
        date  = datetime.strptime(startday['date'], '%Y-%m-%d').date()
        chkin = datetime.strptime(startday['check_in'], '%Y-%m-%d %H:%M:%S')
        chkinlat = startday['chkin_lat']
        chkinlon = startday['chkin_lon']
        dist_id = startday['distributor_id']
        route_ids = startday['route_ids']
        
        previous_started = self.env['fmcg.salesman_session'].search([('employee_id', '=', empid), ('date', '<', date), ('session_state', '=', False)], limit=1)
        if previous_started:
            open_date = previous_started.date
            return {
                'employee_id': empid,
                'success': False, 
                'message': 'Day End for %s NOT performed! Contact your Administrator!!' % open_date, 
                }

        repeat_login = False
        already_started = self.env['fmcg.salesman_session'].search([('employee_id', '=', empid), ('date', '=', date)]).id
        if already_started or already_started != 0:
            repeat_login = True
            # return {
            #     'employee_id': empid,
            #     'success': False, 
            #     'message': 'Day for %s has already been started!' % empname, 
            #     }
        
        
        # Parse JSON
        empid = startday['employee_id']
        date  = datetime.strptime(startday['date'], '%Y-%m-%d').date()
        chkin = datetime.strptime(startday['check_in'], '%Y-%m-%d %H:%M:%S')
        chkinlat = startday['chkin_lat']
        chkinlon = startday['chkin_lon']
        dist_id = startday['distributor_id']
        route_ids = startday['route_ids']
        
        startday_id = {
            'employee_id': empid, 
            'date': date, 
            'check_in': chkin, 
            'chkin_lat': chkinlat, 
            'chkin_lon': chkinlon, 
            'partner_id': dist_id, 
            'route_ids': route_ids, 
            } 
        
        emprec = self.env['hr.employee'].browse(empid)
        plan_chkin = self.env['attendance.process'].get_plan_checkin(empid, date)
        plan_chkout = self.env['attendance.process'].get_plan_checkout(empid, date)
        plan_hours = self.env['attendance.process'].time_difference(plan_chkin, plan_chkout)
        actl_chkin = '{:%Y-%m-%d %H:%M:%S}'.format(chkin - timedelta(hours=5,minutes=30))
        if self.env['attendance.process'].time_difference(actl_chkin, plan_chkin) > (timedelta(minutes=10).total_seconds() / 3600):
            latein_hrs = self.env['attendance.process'].time_difference(actl_chkin, plan_chkin)
            latein = True
        else:
            latein_hrs = 0.00
            latein = False

        if self.env['attendance.process'].time_difference(plan_chkin, actl_chkin) > (timedelta(minutes=10).total_seconds() / 3600):
            earlyin_hrs = self.env['attendance.process'].time_difference(plan_chkin, actl_chkin)
            earlyin = True
        else:
            earlyin_hrs = 0.00
            earlyin = False

        daytype = 'Normal Day'
        otrec = self.env['hr.company.holidays'].search([('date', '=', date)], limit=1)
        if otrec and len(otrec) > 0:
            daytype = 'Company Holiday'
            ot_allow = True
        else:
            if date.weekday() == 6:    # Sunday
                daytype = 'Weekend'
                ot_allow = True
            else:
                ot_allow = False
        
        att_type = 'Remote - Mobile'

        attendance_id = {
            'employee_id': empid, 
            'department_id': emprec.department_id.id, 
            'company_id': emprec.company_id.id, 
            'check_in': actl_chkin, 
            'x_planned_checkin': plan_chkin, 
            'x_planned_checkout': plan_chkout,
            'x_planned_hours': plan_hours,
            'x_is_late_in': latein, 
            'x_late_in': latein_hrs, 
            'x_is_early_in': earlyin, 
            'x_early_in': earlyin_hrs, 
            }
        
        startday_id = {
            'employee_id': empid, 
            'date': date, 
            'check_in': chkin, 
            'chkin_lat': chkinlat, 
            'chkin_lon': chkinlon, 
            'partner_id': dist_id, 
            'route_ids': route_ids, 
            } 

        if repeat_login == False:
            att_id = self.env['hr.attendance'].create(attendance_id)
            std_id = self.env['fmcg.salesman_session'].create(startday_id)

        return {
            'employee_id': empid,
            'success': True, 
            'message': 'Success!' % previous_started,
            }

    @api.model
    def joint_call(self, employeeid=False):

        if not employeeid or employeeid == False:
            retval = {'success': False, 'message': 'Invalid Input Parameters: employeeid', 'joint_list': []}
            return retval

        empid  = employeeid['employeeid']
        emprec = self.env['hr.employee'].browse(empid)
        parentid = emprec.parent_id.id
        emplst = []
        if not parentid or parentid == False or parentid == None:
            retval = {'success': False, 'message': 'Employee has no Manager!', 'joint_list': []}
            return retval
        else:
            emplst.append({'employee_id': parentid, 'employee_name': emprec.parent_id.name})
            emprec = self.env['hr.employee'].browse(parentid)
            emplst.append({'employee_id': emprec.parent_id.id, 'employee_name': emprec.parent_id.name})
            retval = {'success': True, 'message': 'Success!', 'joint_list': emplst}
            return retval


    @api.model
    def endday_request(self, employeeid=False):
        
        if not employeeid or employeeid == False:
            return {
                'employee_id': empid,
                'success': False, 
                'message': 'Missing Required Parameters - employee id',
                'retailers': [],
                'summary': [],
                }

        empid = employeeid['employee_id']
        emprec = self.env['hr.employee'].browse(empid)
        this_date = date.today()
        d1 = datetime.strftime(this_date, '%Y-%m-%d %H:%M:%S')
        d2 = datetime.strftime(this_date, '%Y-%m-%d 23:59:59')
        sales_rec = self.env['sale.retailorder'].search([('date','>=', d1), ('date', '<=', d2), ('salesman_id', '=', empid)])
        sale_list = []
        covered = productive = nonprod = 0

        for sales in sales_rec:
            sale_list.append({'retailer_id': sales.customer_id.id, 
                'retailer_name': sales.customer_id.name, 
                'distributor_id': sales.distributor_id.id, 
                'distributor_name': sales.distributor_id.name, 
                'joint_id': sales.joint_id.id, 
                'joint_name': sales.joint_id.name, 
                'order_no': sales.order_no, 
                'gross': sales.gross_total, 
                'discount': sales.disamt_total, 
                'tax_amount': sales.taxamt_total, 
                'amount_total': sales.amount_total, 
                'weight_total': sales.weight_total, 
                'items_count': len(sales.line_ids), 
                'order_state': sales.order_state, 
                'order_type': sales.order_type
                })
            covered += 1
            if sales.order_state == True:
                productive += 1
            else:
                nonprod += 1

            retailers = self.startday_retailers({'employeeid': empid})
            outlet_list = len(retailers['retailers'])

        summ_list = {'outlets': outlet_list, 'covered': covered, 'productive': productive, 'non_productive': nonprod}

        retval = {'employee_id': empid,
                'success': True, 
                'message': 'Success!',
                'retailers': sale_list,
                'summary': summ_list}
        return retval

    @api.model
    def endday_write(self, employeeid=False):

        if not employeeid or employeeid == False:
            return {'employee_id': empid,
                'success': False, 
                'message': 'Missing Required Parameters - employee id'}

        employeeid = employeeid['employeeid']
        empid = employeeid['employee_id']
        empdt = employeeid['check_out']
        lat = employeeid['lat']
        lon = employeeid['lon']

        _logger.info('Input Parameters: employee id = %s    check_out = %s    lat = %s     lon = %s' % (empid, empdt, lat, lon))
        _logger.info('Type of date variable = %s' % type(empdt))
        
#        if type(empdt) == 'str':
        empdt = datetime.strptime(empdt, '%Y-%m-%d %H:%M:%S')

        cdate = empdt.date()
        date1 = datetime.strftime(cdate, '%Y-%m-%d %H:%M:%S')
        date2 = datetime.strftime(cdate, '%Y-%m-%d 23:59:59')

        if not (empid and empdt and lat and lon):
            return {'employee_id': empid,
                'success': False, 
                'message': 'Missing Required Parameters'}
        
        empname = self.env['hr.employee'].browse(empid).name
        session_rec = self.env['fmcg.salesman_session'].search([('employee_id', '=', empid), ('date', '=', cdate)])
        attends_rec = self.env['hr.attendance'].search([('employee_id', '=', empid), ('check_in', '>', date1), ('check_in', '<', date2)])

        _logger.info('session_rec id = %s     attends_rec id = %s', (session_rec.id, attends_rec.id))

        if not session_rec or session_rec == False or len(session_rec) != 1:
            return {'employee_id': empid,
            'success': False, 
            'message': 'Day for %s has not been started!' % empname}

        if not attends_rec or attends_rec == False or len(attends_rec) != 1:
            return {'employee_id': empid,
            'success': False, 
            'message': 'Attendance Check In for %s has not been marked!' % empname}

        repeat_dayend = False
        if session_rec.session_state == True:
            repeat_dayend = True
            # return {'employee_id': empid, 
            # 'success': False, 
            # 'message': 'Day End for %s is already done!' % empname}

        write_rec = {'check_out': empdt, 'chkout_lat': lat, 'chkout_lon': lon, 'session_state': True}
        _logger.info('write_rec = %s\nattends_rec = %s\nwrite statement values = %s %s %s %s' % (write_rec, attends_rec.id, session_rec.id, empdt, lat, lon))
        tmp1 = self.env['fmcg.salesman_session'].browse(session_rec.id)
        tmp1.write({'check_out': empdt, 'chkout_lat': lat, 'chkout_lon': lon, 'session_state': True})
#        self.env['fmcg.salesman_session'].write((1, session_rec.id, {'check_out': empdt, 'chkout_lat': lat, 'chkout_lon': lon, 'session_state': True}))
        tmp2 = self.env['hr.attendance'].browse(attends_rec.id)
        empdt2 = '{:%Y-%m-%d %H:%M:%S}'.format(empdt - timedelta(hours=5,minutes=30))
        tmp2.write({'check_out': empdt2})
#        self.env['hr.attendance'].write((1, attends_rec.id, {'check_out': empdt}))

        return {'employee_id': empid, 'success': True, 'message': 'Successful!'}

    @api.model
    def dashboard_request(self, dash_input=False):

        if not dash_input or dash_input == False:
            retval = {'success': False, 'message': 'Invalid Input Parameters: dash_input', 'dash_result': []}
            return retval

        empid  = dash_input['employee_id']
        dash_empid = dash_input['dash_employee_id']
        dash_start = dash_input['dash_start_date']
        dash_end   = dash_input['dash_end_date']

        
        # Get Employee List ...
        emprec = self.env['hr.employee'].search([('parent_id', '=', empid)])
        if not emprec or emprec == False or emprec == None:
            emprec = self.env['hr.employee'].browse(empid)
            
        parentid = emprec.parent_id.id
        emplst = []
        if not parentid or parentid == False or parentid == None:
            retval = {'success': False, 'message': 'Employee has no Manager!', 'joint_list': []}
            return retval
        else:
            emplst.append({'employee_id': parentid, 'employee_name': emprec.parent_id.name})
            emprec = self.env['hr.employee'].browse(parentid)
            emplst.append({'employee_id': emprec.parent_id.id, 'employee_name': emprec.parent_id.name})
            retval = {'success': True, 'message': 'Success!', 'joint_list': emplst}
            return retval




class StartDayLines(models.Model):
    
    _name = 'fmcg.salesman_session.retailers'
    _description = 'FMCG Salesman Session - Retailer Details'
    
    session_id = fields.Many2one('fmcg.salesman_session', string='Session Id')
    partner_id = fields.Many2one('res.partner', string='Retailer', stored=True)
    call_type = fields.Selection(selection=[('visit', 'Visit'), ('phone', 'Telephonic')], string='Call Type')
    call_result = fields.Selection(selection=[('prod', 'Productive'), ('nonprod', 'Non Productive')], string='Call Result')
    order_no = fields.Many2one('fmcg.secondarysale.order', string='Order No.')
    lost_reason_id = fields.Many2one('crm.lost.reason', string='Non Productive Reason')
    