from odoo import models,fields,api,_


class AccountInvoice(models.Model):
    _inherit="account.invoice"
    
    suburb_id   = fields.Many2one('geographies.suburbs', string="Suburb", store=True)
    area_id     = fields.Many2one('geographies.areas', string="Area", store=True)
    x_order_tag = fields.Integer(related='order_id.x_order_tag',store=True)
    
