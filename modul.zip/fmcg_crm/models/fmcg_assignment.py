# -*- coding: utf-8 -*-
from odoo.exceptions import UserError, AccessError, ValidationError
from odoo import models, fields, api, _
from datetime import datetime, date, time, timedelta, timezone

class SalesforceAssignment(models.Model):
    
    _name = 'fmcg.salesforce'
    _description = 'FMCG Salesforce Assignments'
    
    employee_id = fields.Many2one('hr.employee', string='Sales Person')
    manager_id = fields.Many2one('hr.employee', string='Manager', readonly=True, compute='_manager_desig')
    job_id = fields.Many2one('hr.job', string='Designation', readonly=True, compute='_manager_desig')
    div_ids = fields.Many2many('product.division', string='Divisions')
    region_ids = fields.Many2many('geographies.regions', string='Region(s)')
    district_ids = fields.Many2many('geographies.districts', string='District(s)')
    city_ids = fields.Many2many('res.city', string='City/Cities')
    suburb_ids = fields.Many2many('geographies.suburbs', string='Suburb(s)')
    area_ids = fields.Many2many('geographies.areas', string='Area(s)')
    distributor_ids = fields.Many2many('res.partner', string='Distributors(s)')
    retailer_ids = fields.Many2many('res.partner', string='Regailer(s)')
    route_ids = fields.Many2many('geographies.routes', string="Salesman's Route(s)")
    
    @api.one
    @api.depends('employee_id')
    def _manager_desig(self):
        if self.employee_id:
            self.manager_id = self.employee_id.parent_id
            self.job_id = self.employee_id.job_id
    

class DistributorAssignment(models.Model):
    
    _name = 'fmcg.network'
    _description = 'FMCG Distribution Network Assignments'
    
    partner_id = fields.Many2one('res.partner', string='Distributor')
    supplier_id = fields.Many2one('res.partner', string='Supply Point')
    node_id = fields.Many2one('network.nodes', string='Network Node', stored=False, readonly=True)
    channel_id = fields.Many2one('crm.team', string='Sales Channel', stored=False, readonly=True)
    retailer_ids = fields.Many2many('res.partner', string='Retailers')
    div_ids = fields.Many2many('product.division', string='Divisions')
    region_id = fields.Many2many('geographies.regions', string='Region(s)')
    district_ids = fields.Many2many('geographies.districts', string='District(s)')
    city_ids = fields.Many2many('res.city', string='City/Cities')
    suburb_ids = fields.Many2many('geographies.suburbs', string='Suburb(s)')
    area_ids = fields.Many2many('geographies.areas', string='Area(s)')
    route_ids = fields.Many2many('geographies.routes', string='Routes Assignment')