from odoo import models, fields, api
from datetime import date,datetime,time,timedelta,timezone
from odoo.exceptions import UserError

class PackingList(models.TransientModel):
    _name = 'packing.list'

    packing_list_ids = fields.One2many('packing.list.line','packing_list_id')
    
    
class PackingListLine(models.TransientModel):
    _name = 'packing.list.line'

    packing_list_id = fields.Many2one('packing.list')
    sale_order_id = fields.Many2one('sale.order')
    packing_person = fields.Many2one(related="sale_order_id.packing_person_id",store = True,string="Packing Person")
    picking_person = fields.Many2one(related="sale_order_id.picking_person_id",store = True,string="Picking Person")
    partner_id = fields.Many2one(related='sale_order_id.partner_id',string="Customer", store=True)
    product_id = fields.Many2one(related='sale_order_id.order_line.product_id',string="Product", store=True)
    product_qty = fields.Float(related='sale_order_id.order_line.product_uom_qty',string="Quantity", store=True)
    product_uom_id = fields.Many2one(related='sale_order_id.order_line.product_uom',string="UOM", store=True)
    categ_id = fields.Many2one(related='product_id.categ_id',string='Product Category',store=True)
    date_order = fields.Datetime(related='sale_order_id.date_order',string="Date Order", store=True)

