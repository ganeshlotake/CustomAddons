
# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from datetime import datetime, date, time, timedelta, timezone
import requests
import json

class GeoAttendance(models.Model):
    _inherit = 'hr.attendance.geolocation'

    def _default_employee(self):
        return self.env['hr.employee'].search([('user_id', '=', self.env.uid)], limit=1).id

    employee_id = fields.Many2one('hr.employee', string="Employee", default=_default_employee, required=True, ondelete='cascade', index=True)
    date = fields.Date("Attendance Date", default=lambda self: date.today(), readonly=True)
    check_in = fields.Datetime('Check In', readonly=True)
    check_out = fields.Datetime('Check Out', default=lambda self: datetime.now(), readonly=True)
    latitude = fields.Char(string='Geo Latitude', readonly=True)
    longitude = fields.Char(string='Geo Longitude', readonly=True)
    zipcode = fields.Char(string='Postal Code', readonly=True)
    location = fields.Char(string='Location', readonly=True)
    
    @api.multi
    def get_location(self):
        
        loc = requests.get('https://api.ipdata.co?api-key=test').json()
        self.latitude = loc['latitude']
        self.longitude = loc['longitude']
    
    