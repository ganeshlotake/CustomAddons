# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

PS_COUNTRY_ID = 110
PS_STATE_ID   = 339

class GeoCities(models.Model):

	_inherit = "res.city"
#	_inherit = 'mail.thread'

	state_id = fields.Many2one("res.country.state", string="State", stored=True, domain=None)
	country_id = fields.Many2one("res.country", string="Country", stored=True, compute='_get_state_country')
	active = fields.Boolean(string="Active")

	@api.one
	@api.depends('state_id')
	def _get_state_country(self):

		if self.state_id:
			self.country_id = self.env['res.country.state'].browse(self.state_id.id).country_id.id
		else:
			self.country_id = 0



class GeoSuburbs(models.Model):

	_name = "geographies.suburbs"

	name = fields.Char(string="Suburb/Town", required=True, help="Enter name of the Suburb or Town here. This can also be a major area name in the smaller cities which may not have suburbs in some countries.")
	city_id = fields.Many2one("res.city", string="City", stored=True, required=True)
	state_id = fields.Many2one("res.country.state", string="State", stored=True, compute='_get_city_state')
	active = fields.Boolean(string="Active")

	@api.one
	@api.depends('city_id')
	def _get_city_state(self):

		if self.city_id:
			self.state_id = self.env['res.city'].browse(self.city_id.id).state_id
		else:
			self.state_id = 0


class GeoAreas(models.Model):

	_name = "geographies.areas"

	name = fields.Char(string="Area Name", required=True, help="Enter name of the area here.")
	description = fields.Text(string="Description")
	city_id = fields.Many2one("res.city", string="City", stored=True, required=True)
	suburb_id = fields.Many2one("geographies.suburbs", required=True, stored=True, string="Suburb")
	state_id = fields.Many2one("res.country.state", string="State", stored=True, compute='_get_city_state')
	active = fields.Boolean(string="Active")

	@api.one
	@api.depends('city_id')
	def _get_city_state(self):

		if self.city_id:
			self.state_id = self.env['res.city'].browse(self.city_id.id).state_id
		else:
			self.state_id = 0



class GeoRoutes(models.Model):

	_name = "geographies.routes"

	name = fields.Char(string="Route Name", required=True, stored=True, help="Enter name of Route here.")
	description = fields.Text(string="Route Description")
	city_id = fields.Many2one("res.city", string="City", stored=True, required=True)
	suburb_ids = fields.Many2many("geographies.suburbs", string="Select Suburbs", stored=True)
	area_ids = fields.Many2many("geographies.areas", string="Select Areas from chosen Suburbs", stored=True)
	suburb_id = fields.Many2many("geographies.suburbs", required=True, stored=True, string="Suburb")
	active = fields.Boolean(string="Active")



class NetworkNodes(models.Model):

	_name = "network.nodes"

	name = fields.Char(string="Network Node", stored=True, required=True, 
			help="Enter a Distribution Network Node here. This could be, for example, C&F Agent, Super Distributor, Distributor, Retailer, etc.")
	parent_id = fields.Many2one('network.nodes', 'Parent Node')
	child_ids = fields.One2many('network.nodes', 'parent_id', 'Child Nodes')

