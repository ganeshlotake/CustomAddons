# -*- coding: utf-8 -*-

from odoo import models, fields, api

class vstore(models.Model):
    _name = 'vstore.vstore'

    Customer = fields.Many2one('hr.employee', string="customer")
    Route = fields.Many2one(comodel_name='network.route', string='Route', stored=True)
    # route = fields.Many2one('route', 'Route', select=True)
    image = fields.Binary('Image', required=True)
    datetime = fields.Datetime('DateTime', default=lambda self: fields.Datetime.now(),readonly=True) 
    description = fields.Text()

    # @api.depends('value')
    # def _value_pc(self):
    #     self.value2 = float(self.value) / 100