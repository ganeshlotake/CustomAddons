# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.addons import decimal_precision as dp
from odoo.exceptions import UserError, ValidationError
import logging

_logger = logging.getLogger(__name__)

class ProductExtended(models.Model):
    
    _inherit = "product.product"
    
    @api.one
    def _get_weight(self):
        self.conversion_factor = self.weight
    
    convert_unit      = fields.Boolean(string='Convert Unit ?')
    conversion_factor = fields.Float(string='Conversion Factor', default=_get_weight)
    conversion_unit   = fields.Many2one(comodel_name='uom.uom', string='New UoM')
    product_category  = fields.Char(related='categ_id.name', string='Category')
    qty_option        = fields.Boolean(string='Has Qty. Options', help='Check this field if the current product needs to have multiple quantity options.')
    qty_lines         = fields.One2many(comodel_name='product.product.qtylines', inverse_name='product_id',
        string='Qty. Options', stored=True, ondelete='cascade')


    # @api.model
    # def create(self, values):

    #     res = super(ProductExtended, self).create(values)
    #     ecom_installed = self.env['ir.module.module'].search([('name', '=', 'website_sale')])


class ProductTemplateExt(models.Model):

    _inherit = 'product.template'

    qty_option = fields.Boolean(string='Has Qty. Options', help='Check this field if the current product needs to have multiple quantity options.')
    qty_lines  = fields.One2many(comodel_name='product.template.qtylines', inverse_name='product_tmpl_id',
        string='Qty. Options', stored=True, ondelete='cascade')
    bool_btn   = fields.Boolean('Re-Compute')

    @api.onchange('bool_btn')
    def recompute_figures(self):
        for line in self.qty_lines:
            line.price = round(line.qty * line.product_tmpl_id.list_price * line.formula_qty, 2)
            line.price_per_kg = round(line.product_tmpl_id.list_price * line.formula_qty, 2)

    
    # @api.model
    # def create(self, values):
    #     res = super(ProductTemplateExt, self).create(values)
    
    #     if self.qty_option == True:
    #         for line in self.qty_lines:
                
    #             _logger.info("Product Template Id = %s\nPricelist Id = %s\nMin. Quantity = %s\nFixed Price = %s" % (self.id,line.pricelist_id.id,line.qty,line.price_per_kg))

    #             add_tmpl_row = {
    #                 'product_tmpl_id': self.id,  # line.product_tmpl_id.id,
    #                 'pricelist_id': line.pricelist_id.id,
    #                 'applied_on': '1_product',
    #                 'base': 'list_price',
    #                 'compute_price': 'fixed',
    #                 'min_quantity': line.qty,
    #                 'fixed_price': line.price_per_kg,
    #             }
    #             newid = self.env['product.pricelist.item'].create(add_tmpl_row)
    #             line.write({'pricelist_item_id': newid})
    
    #         self.env.cr.commit()
    
    #     return res
    
    # @api.model
    # def unlink(self, values):
    #     res = super(ProductTemplateExt, self).unlink()
    #     for line in self.qty_lines:
    #         pricelist_item_id = line.pricelist_item_id
    #         pricelist_item_rec = self.env['product.pricelist_item'].browse(pricelist_item_id)
    #         pricelist_item_rec.unlink()
    
    #     self.env.cr.commit()
    #     return res
    
    
    # @api.model
    # def write(self, values):
    
    #     res = super(ProductTemplateExt, self).write(values)
    #     if self.qty_option == True:
    #         for line in self.qty_lines:
    #             _logger.info("Product Template Id = %s\nPricelist Id = %s\nMin. Quantity = %s\nFixed Price = %s" % (self.id,line.pricelist_id.id,line.qty,line.price_per_kg))
    #             add_tmpl_row = {
    #                 'product_tmpl_id': line.product_tmpl_id.id,
    #                 'pricelist_id': line.pricelist_id.id,
    #                 'applied_on': '1_product',
    #                 'base': 'list_price',
    #                 'compute_price': 'fixed',
    #                 'min_quantity': line.qty,
    #                 'fixed_price': line.price_per_kg,
    #             }
    #             newid = self.env['product.pricelist.item'].create(add_tmpl_row)
    #             line.write({'pricelist_item_id': newid})
    
    #         self.env.cr.commit()
    
    #     return res


class ProductTemplateQtyLines(models.Model):

    _name = 'product.template.qtylines'
    _description = 'Product Template Lines for Quantity Options'

    product_tmpl_id = fields.Many2one(comodel_name='product.template', 
        string='Product Template Id', stored=True)
    pricelist_id    = fields.Many2one(comodel_name='product.pricelist', string='Price-list', stored=True)
    pricelist_item_id = fields.Integer(string='Pricelist Item Id')
    qty             = fields.Float(string='Qty.', digits=dp.get_precision('Stock Weight'), required=True)
    price           = fields.Float(string='Price/Qty', required=True, placeholder='Enter Qty.')
    price_per_kg    = fields.Float(string='Price/Kg')
    formula_qty     = fields.Float(string='Price Ratio', required=True, default=1)
    isdefault       = fields.Boolean(string="Default", default=False)
    website_published = fields.Boolean(string="Published", default=True)
    sale_ok         = fields.Boolean(string="Can be Sold", default=True)

    
    @api.model
    def unlink(self, values):
        res = super(ProductTemplateQtyLines, self).unlink()
        for rec in self:
            pricelistid = rec.pricelist_item_id
            pricerec = rec.env['product.pricelist.item'].browse(pricelistid)
            pricerec.unlink()
            _logger.info('\n\n\nDeleted Record - %s\n' % newid)

        return res
    
    @api.model
    def write(self, values):
        res = super(ProductTemplateQtyLines, self).write(values)
        for rec in self:
            pricelistid = rec.pricelist_item_id
            pricerec = rec.env['product.pricelist.item'].browse(pricelistid)
            pricerec.write({
                'product_tmpl_id': rec.product_tmpl_id.id,
                'pricelist_id': rec.pricelist_id.id,
                'applied_on': '1_product',
                'base': 'list_price',
                'compute_price': 'fixed',
                'min_quantity': rec.qty,
                'fixed_price': rec.price_per_kg
            })
            _logger.info('\n\n\nEdited Record - \nProduct Tmpl Id = %s (%s)\n \
                Pricelist Id = %s (%s)\n \
                Min. Quantity = %s\n \
                Fixed Price = %s\n \
                Product Pricelist Item Id = %s\n' % (rec.product_tmpl_id.id, 
                rec.product_tmpl_id.name, rec.pricelist_id.id, rec.pricelist_id.name, rec.qty, 
                rec.price_per_kg, pricerec.id))
        return res

    @api.onchange('qty')
    def validate_qty(self):

        if self._origin.qty != self.qty:
            if self.qty == 0:
                raise ValidationError(_('Quantity cannot be ZERO ...'))
        
        self.price = round(self.qty * self.product_tmpl_id.list_price * self.formula_qty, 2)
        self.price_per_kg = round(self.product_tmpl_id.list_price * self.formula_qty, 2)

    @api.onchange('price')
    def validate_price(self):

        if self._origin.price != self.price:
            if self.price == 0:
                raise ValidationError(_('Price cannot be ZERO ...'))

        self.price = round(self.qty * self.product_tmpl_id.list_price * self.formula_qty, 2)
        self.price_per_kg = round(self.product_tmpl_id.list_price * self.formula_qty, 2)

    @api.onchange('formula_qty')
    def validate_formulaqty(self):

        if self._origin.formula_qty != self.formula_qty:
            if self.formula_qty == 0:
                raise ValidationError(_('Price Ration cannot be ZERO ...'))

        self.price = round(self.qty * self.product_tmpl_id.list_price * self.formula_qty, 2)
        self.price_per_kg = round(self.product_tmpl_id.list_price * self.formula_qty, 2)


class ProductTemplateQtyLines2(models.Model):
    _inherit = 'product.template.qtylines'

    @api.model
    def create(self, values):
        _logger.info('\n\n\n... I AM HERE IN OVERRIDDEN CREATE ...\n\n\nVALUES : %s\n' % values)
        newid = self.env['product.pricelist.item'].create({
            'product_tmpl_id': values['product_tmpl_id'],
            'pricelist_id': values['pricelist_id'],
            'applied_on': '1_product',
            'base': 'list_price',
            'compute_price': 'fixed',
            'min_quantity': values['qty'],
            'fixed_price': values['price_per_kg']
        })
        values.update({'pricelist_item_id': newid.id})
        _logger.info('VALUES(2) : %s\n' % values)
        res = super(ProductTemplateQtyLines2, self).create(values)

        return res


class ProductQtyLines(models.Model):

    _name = 'product.product.qtylines'
    _description = 'Product Lines for Quantity Options'

    product_id = fields.Many2one(comodel_name='product.product', 
        string='Product Id', stored=True)
    pricelist_id    = fields.Many2one(comodel_name='product.pricelist', string='Price-list', stored=True)
    pricelist_item_id = fields.Integer(string='Pricelist Item Id')
    qty             = fields.Float(string='Qty.', digits=dp.get_precision('Stock Weight'))
    price           = fields.Float(string='Price/Qty', required=True)
    price_per_kg    = fields.Float(string="Price/Kg")
    formula_qty     = fields.Float(string='Price Ratio')
    isdefault       = fields.Boolean(string="Default")

    @api.onchange('qty')
    def validate_qty(self):

        if self._origin.qty != self.qty:
            if self.qty == 0:
                raise ValidationError(_('Quantity cannot be ZERO ...'))
        
        self.price = round(self.qty * self.product_id.list_price * self.formula_qty, 2)
        self.price_per_kg = round(self.product_tmpl_id.list_price * self.formula_qty, 2)

    @api.onchange('price')
    def validate_price(self):

        if self._origin.price != self.price:
            if self.price == 0:
                raise ValidationError(_('Price cannot be ZERO ...'))

        self.price = round(self.qty * self.product_id.list_price * self.formula_qty, 2)
        self.price_per_kg = round(self.product_tmpl_id.list_price * self.formula_qty, 2)

    @api.onchange('formula_qty')
    def validate_formulaqty(self):

        if self._origin.formula_qty != self.formula_qty:
            if self.formula_qty == 0:
                raise ValidationError(_('Price Ration cannot be ZERO ...'))

        self.price = round(self.qty * self.product_id.list_price * self.formula_qty, 2)
        self.price_per_kg = round(self.product_tmpl_id.list_price * self.formula_qty, 2)



class ProductPricelistExtended(models.Model):
    _inherit = 'product.pricelist.item'

    min_quantity = fields.Float('Min. Qty.')

