# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------------------------------#
#   Module Name:    SBiz eCom Suite                                                                 #
#   Description:    Collective Single Module for e-Commerce Business Requirements                   #
#   File Name:      sbiz_ecom_delivery.py (/models)                                                 #
#   Purpose:        The model / classes to sets up the Delivery Mechanism for a typical ecommerce   #
#                   business where deliveries are last mile deliveries and are handled by the       #
#                   e-commerce operator itself.                                                     #
#   Author:         Jayant Bulbule                                                                  #
#   Date Created:   28-Oct-2019                                                                     #
#   Last Modified:  --/--/----                                                                      #
#   Last Mod. By:                                                                                   #
#---------------------------------------------------------------------------------------------------#

#---------------------------------------------------------------------------------------------------#
#                                   Modification History                                            #
#---------------------------------------------------------------------------------------------------#
#  Date        Modified By          Purpose                                           Change Mark   #
#  ----------  -------------------  -----------------------------------------------   ------------- #
#                                                                                                   #
#                                                                                                   #
#                                                                                                   #
#---------------------------------------------------------------------------------------------------#

from datetime import datetime, timedelta
from odoo import models, fields,api, _
from odoo.exceptions import UserError, ValidationError

DELIVERY_DAYS = [
        (0, 'Monday'),
        (1, 'Tuesday'),
        (2, 'Wednesday'),
        (3, 'Thursday'),
        (4, 'Friday'),
        (5, 'Saturday'),
        (6, 'Sunday')
    ]

DELIVERY_SESSIONS = [
        ('morning', 'Morning'),
        ('noon', 'Noon'),
        ('afternoon', 'Afternoon'),
        ('evening', 'Evening'),
        ('night', 'Night')
    ]

DELIVERY_TIMESLOTS = [
        ('00:00', '00:00'),
        ('00:30', '00:30'),
        ('01:00', '01:00'),
        ('01:00', '01:30'),
        ('02:00', '02:00'),
        ('02:30', '02:30'),
        ('03:00', '03:00'),
        ('03:30', '03:30'),
        ('04:00', '04:00'),
        ('04:30', '04:30'),
        ('05:00', '05:00'),
        ('05:30', '05:30'),
        ('06:00', '06:00'),
        ('06:30', '06:30'),
        ('07:00', '07:00'),
        ('07:30', '07:30'),
        ('08:00', '08:00'),
        ('08:00', '08:00'),
        ('09:00', '09:00'),
        ('09:30', '09:30'),
        ('10:00', '10:00'),
        ('10:30', '10:30'),
        ('11:00', '11:00'),
        ('11:30', '11:30'),
        ('12:00', '12:00'),
        ('12:30', '12:30'),
        ('13:00', '13:00'),
        ('13:30', '13:30'),
        ('14:00', '14:00'),
        ('14:30', '14:30'),
        ('15:00', '15:00'),
        ('15:30', '15:30'),
        ('16:00', '16:00'),
        ('16:30', '16:30'),
        ('17:00', '17:00'),
        ('17:30', '17:30'),
        ('18:00', '18:00'),
        ('18:30', '18:30'),
        ('19:00', '19:00'),
        ('19:30', '19:30'),
        ('20:00', '20:00'),
        ('20:30', '20:30'),
        ('21:00', '21:00'),
        ('21:30', '21:30'),
        ('22:00', '22:00'),
        ('22:30', '22:30'),
        ('23:00', '23:00'),
        ('23:30', '23:30')
    ]

class sbizEcomDelivery(models.Model):

    _name = 'geographies.delivery_slot'
    _description = 'e-Commerce Delivery Slots for SBiz e-Commerce Suite'
    _inherit = 'mail.thread'

    name         = fields.Char(string='Delivery Slot', required=True, track_visibility='onchange')
    delivery_day = fields.Selection(selection=DELIVERY_DAYS, string='Delivery Day', required=True, track_visibility='onchange')
    city_id      = fields.Many2one('res.city', string='City', required=True, track_visibility='onchange')
    route_id     = fields.Many2one('geographies.routes', string='Route', required=True, track_visibility='onchange')
    session      = fields.Selection(selection=DELIVERY_SESSIONS, string='Session', required=True, track_visibility='onchange')
    time_start   = fields.Selection(selection=DELIVERY_TIMESLOTS, string='Start Time', required=True, track_visibility='onchange')
    time_finish  = fields.Selection(selection=DELIVERY_TIMESLOTS, string='End Time', required=True, track_visibility='onchange')
    time_cutoff  = fields.Selection(selection=DELIVERY_TIMESLOTS, string='Cut-off Time', required=True, track_visibility='onchange')
    days_cutoff  = fields.Integer(string='Cut-off Days', help='No. of days prior to delivery day. Enter ZERO for same day.', track_visibility='onchange')

    @api.onchange('delivery_day', 'session', 'city_id', 'route_id')
    def get_slot_name(self):
        self.name = ''
        if self.city_id:
            self.name = self.city_id.name + ' '
        if self.route_id:
            self.name += self.route_id.name + ' '
        if self.delivery_day:
            value = dict(DELIVERY_DAYS)[self.delivery_day]
            self.name += value + ' '
        if self.session:
            self.name += self.session + ' '

    @api.onchange('time_finish')
    def validate_finish_time(self):
        if self.time_finish:
            if self.time_finish <= self.time_start:
                raise UserError(_('Finish Time of delivery slot cannot be same as before the Start Time'))

    @api.onchange('time_cutoff')
    def validate_cutoff(self):
        if self.time_cutoff:
            if self.time_cutoff >= self.time_start:
                if not self.days_cutoff:
                    self.days_cutoff = 1
                elif self.days_cutoff == 0:
                    raise UserError(_('Your cutoff time is after the delivery slot start time. Please enter cut off days appropriately.'))


# class WebsiteSaleOrder(models.Model):

#     _inherit = 'sale.order'

#     order_comments = fields.Text(string='Order Comments')

