from odoo import models,fields, api,_


class InvoiceOrdeExtended(models.Model):


    _inherit = 'account.invoice'


    pack_name = fields.Many2one("res.users",string="Packer/QC Name")
    deliver_name =  fields.Many2one("res.users",string="Delivery Name")

class SaleOrderExtendedBy(models.Model):


    _inherit ='sale.order.productsum'
