# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------------------------------#
#   Module Name:    SBiz eCom Suite                                                                 #
#   Description:    Collective Single Module for e-Commerce Business Requirements                   #
#   File Name:      sbiz_ecom_delivery.py (/models)                                                 #
#   Purpose:        The model / classes to sets up the Delivery Mechanism for a typical ecommerce   #
#                   business where deliveries are last mile deliveries and are handled by the       #
#                   e-commerce operator itself.                                                     #
#   Author:         Jayant Bulbule                                                                  #
#   Date Created:   28-Oct-2019                                                                     #
#   Last Modified:  --/--/----                                                                      #
#   Last Mod. By:                                                                                   #
#---------------------------------------------------------------------------------------------------#

#---------------------------------------------------------------------------------------------------#
#                                   Modification History                                            #
#---------------------------------------------------------------------------------------------------#
#  Date        Modified By          Purpose                                           Change Mark   #
#  ----------  -------------------  -----------------------------------------------   ------------- #
#                                                                                                   #
#                                                                                                   #
#                                                                                                   #
#---------------------------------------------------------------------------------------------------#

from datetime import datetime, timedelta
from odoo import models, fields,api, _
from odoo.exceptions import UserError, ValidationError

