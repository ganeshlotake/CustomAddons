# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------------------------------#
#   Module Name:    SBiz_eCom                                                                       #
#   Description:    Collective Single Module for eCommerce related functionality                    #
#   File Name:      sbiz_ecom_config.py (/models)                                                   #
#   Purpose:        The model / classes to extend the Settings / Configurations for the eCom system #
#                   to accommodate addtional setting values that are needed for SBiz_ecom module    #
#   Author:         Jayant Bulbule                                                                  #
#   Date Created:   21-Nov-2019                                                                     #
#   Last Modified:  --/--/----                                                                      #
#   Last Mod. By:                                                                                   #
#---------------------------------------------------------------------------------------------------#

#---------------------------------------------------------------------------------------------------#
#                                   Modification History                                            #
#---------------------------------------------------------------------------------------------------#
#  Date        Modified By          Purpose                                           Change Mark   #
#  ----------  -------------------  -----------------------------------------------   ------------- #
#                                                                                                   #
#                                                                                                   #
#                                                                                                   #
#---------------------------------------------------------------------------------------------------#

from odoo import models, fields,api, _
import logging
_logger = logging.getLogger(__name__)

class ResConfigSettings(models.TransientModel):

    _inherit = 'res.config.settings'

    minimum_cart_value = fields.Float(
        string='Minimum Cart Value', 
        config_parameter='fmcg_crm.minimum_cart_value',
        help='Enter the Minimum Cart Amount below which Online Orders should not be accepted.',
        default=0.0,
        required=True)
    minimum_cart_setup = fields.Boolean(
        string='Set Minimum Cart Amount',
        config_parameter='fmcg_crm.minimum_cart_setup',
        help='Choose this box if you wish to set the Minimum Cart Amount.',
        default=True,
        required=True)
    maximum_slot_days  = fields.Integer(
        string='No. of Days for Delivery Slots',
        config_parameter='fmcg_crm.maximum_slot_days',
        help='Enter number of days for which delivery slots to be shown.',
        default=3,
        required=True)
    is_customer_comment_features = fields.Boolean(
        related='website_id.is_customer_comment_features',
        string="Do you want to disable customer order comment feature", readonly=False)

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res.update(
            minimum_cart_value = float(self.env['ir.config_parameter'].sudo().get_param('fmcg_crm.minimum_cart_value')),
            maximum_slot_days  =   int(self.env['ir.config_parameter'].sudo().get_param('fmcg_crm.maximum_slot_days'))
        )
        return res
    
    def set_values(self):
        super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param('fmcg_crm.minimum_cart_value', self.minimum_cart_value)
        self.env['ir.config_parameter'].sudo().set_param('fmcg_crm.minimum_cart_setup', self.minimum_cart_setup)
        self.env['ir.config_parameter'].sudo().set_param('fmcg_crm.minimum_cart_setup', self.maximum_slot_days)


class website(models.Model):

    """Adds the fields for options of the Customer Order Comment."""

    _inherit = 'website'

    is_customer_comment_features = fields.Boolean(
        string='Do you want to disable customer order comment feature',
        default=False, readonly=False)
