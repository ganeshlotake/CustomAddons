# -*- coding: utf-8 -*-
from odoo.exceptions import UserError, AccessError, ValidationError
from odoo import models, fields, api
from odoo import fields, models
from odoo.exceptions import ValidationError

class sales_target(models.Model):
    _name = 'fmcg.sales__target'

    category = fields.Many2one('product.category', string='Category' , required=False, change_default=True, index=True, track_visibility='always')
    product = fields.Many2many('product.product', string='Product')
    date = fields.Date(string='Date')
    # manager = fields.Many2one(string='Manager')
    company = fields.Many2one(comodel_name="res.company", string="Company", required=False, )
    target =  fields.Selection([('quantity', 'Quantity'), ('value', 'value')], required=False, default='quantity')
    totalamount = fields.Integer(string='Total Amount')
    minincl1quantity = fields.Integer(string='Quantity')
    minincl1fixed = fields.Float(string='Fixed Quantity')
    minincl1percent = fields.Float(string='Percent Amount')
    incl1quantity = fields.Integer(string='Quantity')
    incl1fixed = fields.Float(string='Fixed Quantity')
    incl1percent = fields.Float(string='Percent Amount')
    incl2quantity = fields.Integer(string='Quantity')
    incl2fixed = fields.Float(string='Fixed Quantity')
    incl2percent = fields.Float(string='Percent Amount')
    incl3quantity = fields.Integer(string='Quantity')
    incl3fixed = fields.Float(string='Fixed Quantity')
    incl3percent = fields.Float(string='Percent Amount')
    region1 = fields.One2many(comodel_name="region.fmcg",inverse_name = "state", string="Regional id", required=False,store=True )
    area1 = fields.Many2one(comodel_name="res.country.state", string="State", required=False, )
    district = fields.One2many(comodel_name="fmcc_geographies.districts",inverse_name = "district" ,string="District")
    regionselid = fields.Integer(string="Region Value",compute="_get_region")


    @api.one
    @api.depends('region1','region1.region')
    def _get_region(self):
        # x = 0
        # for value in self.region1:
        #     x = x + value.region.id
        self.regionselid = self.region1.region.id


class region_target(models.Model):
    _name = 'region.fmcg'
    state = fields.Many2one(comodel_name="res.country.state", string="State", required=False,)
    region = fields.Many2one(comodel_name="geographies.regions", string="Region", required=False,)
    amount = fields.Integer(string="Amount", required=False, )
    fixedamount = fields.Integer(string="Fixed Amount", required=False, )
    target = fields.Selection(string="Target", selection=[('1', 'Minimum Target'), ('2', 'Level 1'),('3', 'Level 2'), ('4', 'Level 3') ], required=False,default="1", )
    peramount = fields.Integer(string="Percent Amount", required=False, )

class region_target(models.Model):
    _name = 'fmcc_geographies.districts'

    regionselid = fields.Integer(string="Region Value")
    # state = fields.Many2one(comodel_name="res.country.state", string="State", required=False, )
    # region = fields.Many2one(comodel_name="geographies.regions", string="Region", required=False, )
    district = fields.Many2one(comodel_name="geographies.districts", string="District", required=False, )
    amount = fields.Integer(string="Amount", required=False, )
    fixedamount = fields.Integer(string="Fixed Amount", required=False, )
    peramount = fields.Integer(string="Percent Amount", required=False, )
    target = fields.Selection(string="Target",selection=[('1', 'Minimum Target'), ('2', 'Level 1'), ('3', 'Level 2'), ('4', 'Level 3')],required=False, default="1", )

class region_rout(models.Model):
    _name = 'fmcc_rout.master'

    rout = fields.Many2one(comodel_name="geographies.routes", string="Route", required=False, )
    amount = fields.Integer(string="Amount", required=False, )
    fixedamount = fields.Integer(string="Fixed Amount", required=False, )
    peramount = fields.Integer(string="Percent Amount", required=False, )
    target = fields.Selection(string="Target",selection=[('1', 'Minimum Target'), ('2', 'Level 1'), ('3', 'Level 2'), ('4', 'Level 3')],required=False, default="1", )















