# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from dateutil.relativedelta import relativedelta
from datetime import date, datetime, time, timedelta, timezone
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

SCHEME_GEOGRAPHY = [('global', 'Global'), ('region', 'By Region'), ('district', 'By District'), ('city', 'By City')]

class FmcgSchemes(models.Model):
    
    _name = 'fmcg.schemes'
    _description = 'FMCG Schemes Definition'
    
    name = fields.Char('Scheme Name', stored=True, required=True)
    start_date = fields.Date('Start Date')
    end_date = fields.Date('End Date')
    is_multi = fields.Boolean('Multi-Transaction?')
    scheme_geography = fields.Selection(selection=SCHEME_GEOGRAPHY, string="Scheme Geography")
    region_ids = fields.Many2many('geographies.regions', string='Regions')
    district_ids = fields.Many2many('geographies.districts', string='Districts')
    city_ids = fields.Many2many('res.city', string='Cities')
    channel_id = fields.Many2one('crm.team', string='Sales Channel')
    category_id = fields.Many2one('product.category', string='Product Category')
    brand_id = fields.Many2one('product.brand', string='Product Brand')
    quality_id = fields.Many2one('product.quality', string='Product Quality Type')
    scheme_type = fields.Selection(selection=[('transaction', 'On Transaction'), ('product', 'By Products')])
    scheme_amount = fields.Float('On Purchase of')
    scheme_disper = fields.Float('Scheme %')
    scheme_disamt = fields.Float('Offer Amount')
    gift_id = fields.Many2one('product.product', string='Gift/Free Item')
    gift_qty = fields.Integer('Gift Qty.')
    product_ids = fields.One2many(comodel_name='fmcg.schemes.line', inverse_name='scheme_id', string='Scheme Products')
    
    @api.constrains('is_multi', 'start_date', 'end_date')
    def _dates_multi(self):
        
        for rec in self:
            if rec.is_multi == True and not (rec.start_date and rec.end_date):
                raise ValidationError('Start Date AND End Date cannot be BLANK for Multi Transaction Schemes')
                return False
        
        return True
    
    @api.onchange('scheme_geography')
    def _set_scheme_geography(self):
        
        if self.scheme_geography == 'global':
            self.region_ids = None
            self.district_ids = None
            self.city_ids = None
        elif self.scheme_geography == 'region':
            self.district_ids = None
            self.city_ids = None
        elif self.scheme_geography == 'districts':
            self.region_ids = None
            self.city_ids = None
        elif self.scheme_geography == 'city':
            self.region_ids = None
            self.district_ids = None
        else:
            self.region_ids = None
            self.district_ids = None
            self.city_ids = None



class FmcgSchemesLine(models.Model):
    
    _name = 'fmcg.schemes.line'
    _description = 'FMCG Schemes Product Lines'
    
    scheme_id = fields.Many2one(comodel_name='fmcg.schemes', required=True, ondelete='cascade', index=True, copy=False, stored=True)
    product_id = fields.Many2one('product.product', string="Product")
    cross_product_id = fields.Many2one('product.product', string='Offered Product')
    paid_qty = fields.Float('Buy Qty.')
    free_qty = fields.Float('Free Qty.')
    scheme_product_disper = fields.Float('Discount %')
    scheme_product_disamt = fields.Float('Discount')
    
    