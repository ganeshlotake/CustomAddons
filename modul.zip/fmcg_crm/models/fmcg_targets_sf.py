# -*- coding: utf-8 -*-
from odoo.exceptions import UserError, AccessError, ValidationError
from odoo import models, fields, api, _
from datetime import datetime, date, time, timedelta, timezone

class SalesTarget(models.Model):
    _name = 'fmcg.sales_target'
    _description = 'Employee Sales Targets'

    name = fields.Char(string="Target Name", required=True, stored=True)
    target_type = fields.Selection(string="Target Type", selection=[('bycat', 'By Category'), ('byprod', 'By Product')], stored=True)
    employee_id = fields.Many2one("hr.employee", string="Employee", stored=True, required=True)
    manager_id = fields.Many2one("hr.employee", string="Manager", stored=True, required=True, compute='_get_manager')
    mgr_target_id = fields.Many2one("fmcg.sales_target", string="Manager Target", stored=True)
    year_start = fields.Date("Fiscal Year Start")
    year_end = fields.Date("Fiscal Year End")
    name = fields.Char("Target Name")
    ratio_to_parent = fields.Float("% of Manager's Target")
    company_id = fields.Many2one("res.company", string="Company", stored=True, required=True, compute='_get_company')
    target_qty = fields.Float("Total Target Qty (Kg).")
    target_amount = fields.Float("Total Target Amount (Rs.)")
    target_line_ids = fields.One2many(comodel_name="fmcg.sales_target.lines", inverse_name="target_id", stored=True, string="Target By Products")
    
    @api.one
    @api.depends('employee_id')
    def _get_manager(self):
        self.manager_id = self.employee_id.parent_id
        if self.manager_id:
            mgrtargetid = self.env['fmcg.sales_target'].search([('employee_id', '=', self.manager_id.id)], limit=1)
            self.mgr_target_id = mgrtargetid.id
            self.year_start = mgrtargetid.year_start
            self.year_end = mgrtargetid.year_end
            self.target_qty = mgrtargetid.target_qty
            self.target_amount = mgrtargetid.target_amount
            self.target_line_ids = mgrtargetid.target_line_ids

    @api.one
    @api.depends('employee_id')
    def _get_company(self):
        self.company_id = self.employee_id.company_id
    
    @api.one
    @api.depends('employee_id', 'manager_id')
    def _get_manager_target(self):
        self.mgr_target_id = self.env['fmcg.sales_target'].search([('employee_id', '=', self.manager.id)], limit=1).id


class SalesTargetLines(models.Model):
    
    _name = 'fmcg.sales_target.lines'
    _description = 'Employee Sales Target Lines'
    
    target_id = fields.Many2one(comodel_name="fmcg.sales_target", string="Target By Products", required=True, ondelete='cascade', index=True, copy=False, stored=True)
    employee_id = fields.Many2one("hr.employee", string="Employee ID", stored=True)
    manager_id  = fields.Many2one("hr.employee", string="Manager ID", stored=True)
    category_id = fields.Many2one("product.category", string="Category", stored=True)
    product_id = fields.Many2one("product.product", string="Product", stored=True)
    manager_target_ratio = fields.Float("% of Manager")
    wt_mgr_min = fields.Float("Manager Qty. (Min)")         # , default="_get_manager_qty_min")
    wt_mgr_max = fields.Float("Manager Qty. (Max)")         # , default="_get_manager_qty_max")
    vl_mgr_min = fields.Float("Manager Amt. (Min)")         # , default="_get_manager_amt_min")
    vl_mgr_max = fields.Float("Manager Amt. (Max)")         # , default="_get_manager_amt_max")
    weight_min = fields.Float("Target Weight (Min)")        # , default="_get_weight_min")
    weight_max = fields.Float("Target Weight (Max)")        # , default="_get_weight_max")
    amount_min = fields.Float("Target Amount (Min)")        # , default="_get_amount_min")
    amount_max = fields.Float("Target Amount (Max)")        # , default="_get_amount_max")
    name = fields.Char("Remarks")
    
#     @api.one
#     @api.depends('manager_target_ratio', 'product_id', 'category_id')
#     def _get_manager_qty_min(self):
#         
#         if parent.target_type == 'bycat':
#             self.wt_mgr_min = self.env['fmcg.sales_target_lines'].search([('employee_id', '=', self.manager_id), ()])
