# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------------------------------#
#   Module Name:    SBiz eCom Suite                                                                 #
#   Description:    Collective Single Module for e-Commerce Business Requirements                   #
#   File Name:      sbiz_ecom_delivery.py (/models)                                                 #
#   Purpose:        The model / classes to sets up the Delivery Mechanism for a typical ecommerce   #
#                   business where deliveries are last mile deliveries and are handled by the       #
#                   e-commerce operator itself.                                                     #
#   Author:         Jayant Bulbule                                                                  #
#   Date Created:   28-Oct-2019                                                                     #
#   Last Modified:  --/--/----                                                                      #
#   Last Mod. By:                                                                                   #
#---------------------------------------------------------------------------------------------------#

#---------------------------------------------------------------------------------------------------#
#                                   Modification History                                            #
#---------------------------------------------------------------------------------------------------#
#  Date        Modified By          Purpose                                           Change Mark   #
#  ----------  -------------------  -----------------------------------------------   ------------- #
#                                                                                                   #
#                                                                                                   #
#                                                                                                   #
#---------------------------------------------------------------------------------------------------#

from datetime import datetime, timedelta
from odoo import models, fields,api, _
from odoo.exceptions import UserError, ValidationError

DELIVERY_DAYS = [
        (1, 'Monday'),
        (2, 'Tuesday'),
        (3, 'Wednesday'),
        (4, 'Thursday'),
        (5, 'Friday'),
        (6, 'Saturday'),
        (7, 'Sunday')
    ]

DELIVERY_SESSIONS = [
        ('morning', 'Morning'),
        ('noon', 'Noon'),
        ('afternoon', 'Afternoon'),
        ('evening', 'Evening'),
        ('night', 'Night')
    ]

DELIVERY_TIMESLOTS = [
        ( 1, '00:00'),
        ( 2, '00:30'),
        ( 3, '01:00'),
        ( 4, '01:30'),
        ( 5, '02:00'),
        ( 6, '02:30'),
        ( 7, '03:00'),
        ( 8, '03:30'),
        ( 9, '04:00'),
        (10, '04:30'),
        (11, '05:00'),
        (12, '05:30'),
        (13, '06:00'),
        (14, '06:30'),
        (15, '07:00'),
        (16, '07:30'),
        (17, '08:00'),
        (18, '08:00'),
        (19, '09:00'),
        (20, '09:30'),
        (21, '10:00'),
        (22, '10:30'),
        (23, '11:00'),
        (24, '11:30'),
        (25, '12:00'),
        (26, '12:30'),
        (27, '13:00'),
        (28, '13:30'),
        (29, '14:00'),
        (30, '14:30'),
        (31, '15:00'),
        (32, '15:30'),
        (33, '16:00'),
        (34, '16:30'),
        (35, '17:00'),
        (36, '17:30'),
        (37, '18:00'),
        (38, '18:30'),
        (39, '19:00'),
        (40, '19:30'),
        (41, '20:00'),
        (42, '20:30'),
        (43, '21:00'),
        (44, '21:30'),
        (45, '22:00'),
        (46, '22:30'),
        (47, '23:00'),
        (48, '23:30')
    ]

class sbizEcomDelivery(models.Model):

    _name = 'geographies.delivery_slot'
    _description = 'e-Commerce Delivery Slots for SBiz e-Commerce Suite'
    _inherit = 'mail.thread'

    name         = fields.Char(string='Delivery Slot', required=True, track_visibility='onchange')
    delivery_day = fields.Selection(selection=DELIVERY_DAYS, string='Delivery Day', required=True, track_visibility='onchange')
    city_id      = fields.Many2one('res.city', string='City', required=True, track_visibility='onchange')
    route_id     = fields.Many2one('geographies.routes', string='Route', required=True, track_visibility='onchange')
    session      = fields.Selection(selection=DELIVERY_SESSIONS, string='Session', required=True, track_visibility='onchange')
    time_start   = fields.Selection(selection=DELIVERY_TIMESLOTS, string='Start Time', required=True, track_visibility='onchange')
    time_finish  = fields.Selection(selection=DELIVERY_TIMESLOTS, string='End Time', required=True, track_visibility='onchange')
    time_cutoff  = fields.Selection(selection=DELIVERY_TIMESLOTS, string='Cut-off Time', required=True, track_visibility='onchange')
    days_cutoff  = fields.Integer(string='Cut-off Days', help='No. of days prior to delivery day. Enter ZERO for same day.', track_visibility='onchange')

    @api.onchange('delivery_day', 'session', 'city_id', 'route_id')
    def get_slot_name(self):
        self.name = ''
        if self.city_id:
            self.name = self.city_id.name + ' '
        if self.route_id:
            self.name += self.route_id.name + ' '
        if self.delivery_day:
            value = dict(DELIVERY_DAYS)[self.delivery_day]
            self.name += value + ' '
        if self.session:
            self.name += self.session + ' '

    @api.onchange('time_finish')
    def validate_finish_time(self):
        if self.time_finish:
            if self.time_finish <= self.time_start:
                raise UserError(_('Finish Time of delivery slot cannot be same as before the Start Time'))

    @api.onchange('time_cutoff')
    def validate_cutoff(self):
        if self.time_cutoff:
            if self.time_cutoff >= self.time_start:
                if not self.days_cutoff:
                    self.days_cutoff = 1
                elif self.days_cutoff == 0:
                    raise UserError(_('Your cutoff time is after the delivery slot start time. Please enter cut off days appropriately.'))


class WebsiteSaleOrder(models.Model):

    _inherit = 'sale.order'

    order_comments = fields.Text(string='Order Comments')

