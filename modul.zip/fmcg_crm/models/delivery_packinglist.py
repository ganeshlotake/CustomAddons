# -*- coding: utf-8 -*-
from odoo import models,fields,api,_
from datetime import datetime, timedelta, date, time, timezone
from odoo.exceptions import UserError,ValidationError


class PackingList(models.TransientModel):
    _name = "stock.packing.list"

    stock_packing_list_line_ids = fields.One2many('stock.packing.list.line','stock_packing_list_id')

class PackingListLine(models.TransientModel):
    _name = 'stock.packing.list.line'
    
    stock_packing_list_id = fields.Many2one('stock.packing.list')
    sale_order_id = fields.Many2one('sale.order')
    packing_person = fields.Many2one(related="sale_order_id.packing_person_id",store = True,string="Packing Person")
    picking_person = fields.Many2one(related="sale_order_id.picking_person_id",store = True,string="Picking Person")
    partner_id = fields.Many2one(related='sale_order_id.partner_id',string="Customer", store=True)
    product_id = fields.Many2one(related='sale_order_id.order_line.product_id',string="Product", store=True)
    product_qty = fields.Float(related='sale_order_id.order_line.product_uom_qty',string="Quantity", store=True)
    product_uom_id = fields.Many2one(related='sale_order_id.order_line.product_uom',string="UOM", store=True)
    categ_id = fields.Many2one(related='product_id.categ_id',string='Product Category',store=True)
    date_order = fields.Datetime(related='sale_order_id.date_order',string="Date Order", store=True)
