# -*- coding: utf-8 -*-

from odoo import models, fields, api

class vstore(models.Model):
    _name = 'fmcg.manual_retail_orders'

    customer_id = fields.Many2one('res.partner', string="customer")
    route_id = fields.Many2one('geographies.routes', string='Route', stored=True)
    image = fields.Binary('Image', required=True)
    datetime = fields.Datetime('DateTime', default=lambda self: fields.Datetime.now(),readonly=True) 
    description = fields.Text()

