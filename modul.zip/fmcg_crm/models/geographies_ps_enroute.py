from odoo.exceptions import UserError,ValidationError
from odoo import models, fields, api


class Geographiespsenroutes(models.Model):
    _name='geographies.ps_enroutes'
    _rec_name ='area_ids'
    
    route_id    = fields.Many2one('geographies.ps_routes')
    city        = fields.Many2one('res.city',string="City")
    suburb_ids   = fields.Many2one('geographies.suburbs',string="Suburb")
    area_ids    = fields.Many2one('geographies.areas',string="Area")
    ps_id_enroute = fields.Integer(string='Prestashop EnRoutes ID')