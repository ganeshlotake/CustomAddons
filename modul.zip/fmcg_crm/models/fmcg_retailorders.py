# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from dateutil.relativedelta import relativedelta
from datetime import date, datetime, time, timedelta, timezone
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
import logging
import json
import sys

_logger = logging.getLogger(__name__)

class fmcg_CatImage(models.Model):
    
    _inherit = 'product.category'
    
    shortname = fields.Char(string='Short Name', size=10, help='This name will be shown on the Mobile App')
    mobapp = fields.Boolean(string='Show On App?')
    catcode = fields.Char(string='Category Code', size=2, help='This is used for Product Series')
    image = fields.Binary(string='Image', attachment=True)



class fmcg_RetailOrder(models.Model):
    
    _name = 'sale.retailorder'
    _description = 'Retailers Orders'
    
    order_no = fields.Char('Order No.', required=True, stored=True)
    date = fields.Datetime('Order Date', required=True, stored=True)
    customer_id = fields.Many2one('res.partner', string='Retailer', required=True, stored=True)
    company_id = fields.Many2one('res.company', string='Company', required=True, stored=True)
    distributor_id = fields.Many2one('res.partner', string="Distributor", required=True, stored=True)
    order_type = fields.Selection(string='Order Type', selection=[('online', 'Online'), ('manual', 'Manual'), ('phone', 'Telephonic')], stored=True)
    order_state = fields.Boolean(string='Order State')
    reason_id = fields.Many2one('crm.lost.reason', string='Lost Reason', stored=True)
    lat = fields.Char('Latitude')
    lon = fields.Char('Longitude')
    salesman_id = fields.Many2one('hr.employee', required=True, stored=True)
    joint_id = fields.Many2one('hr.employee', required=True, stored=True)
    order_pic = fields.Binary('Manual Order Picture', stored=True)
    gross_total = fields.Float('Gross', stored=True)
    disamt_total = fields.Float('Discount', stored=True)
    taxamt_total = fields.Float('Tax Amount', stored=True)
    amount_total = fields.Float('Net Amount', stored=True)
    weight_total = fields.Float('Total Weight', stored=True)
    line_ids = fields.One2many(comodel_name='sale.retailorder.line', inverse_name='order_id', string='Order Items', stored=True, ondelete='cascade')
    
    @api.model
    def fmcg_retailorder_request(self, employeeid=False, retailerid=False):

        if not employeeid or employeeid == False:
            retval = {'success': False, 
                'message': 'Missing Parameter: Employee Id', 
                'category_list': [], 
                'product_list': [], 
                'sku_list': [],
                'loss_reasons': [],
                }
            return retval

        # if not retailerid or retailerid == False:
        #     retval = {'success': False, 
        #         'message': 'Missing Parameter: Retailer Id', 
        #         'category_list': [], 
        #         'product_list': [], 
        #         'sku_list': [],
        #         'loss_reasons': [],
        #         }
        #     return retval

        products = []
        prdlst = []
        categs = []
        catlst = []
        schemes = []
        skulst = []
        reasons = []

        loss_reasons = self.env['crm.lost.reason'].search([('active', '=', True)])
        if not loss_reasons or loss_reasons == False:
            reasons.append({'reason_id': 0, 'reason': 'No Reasons created yet!'})
        else:
            for res in loss_reasons:
                reasons.append({'reason_id': res.id, 'reason': res.name})

        cat_rec = self.env['product.category'].search([('mobapp', '=', True)])
        if not cat_rec or len(cat_rec) == 0:
            retval = {'success': False, 
                'message': 'No Categories found!', 
                'category_list': [], 
                'product_list': [], 
                'sku_list': [],
                'loss_reasons': [],
                }
        for cat in cat_rec:
            categs.append({'category_id': cat.id, 'category_name': cat.shortname, 'image': cat.image})
            catlst.append(cat.id)
        
        prod_rec = self.env['product.product'].search([('categ_id', 'in', catlst), ('base', '=', True)])
        for prd in prod_rec:
            products.append({'product_id': prd.id, 'product_name': prd.name, 'cat_id': prd.categ_id.id})
            skurec = self.env['product.product'].search([('base_id', '=', prd.product_tmpl_id.id)])
            for sku in skurec:
                
                schmrec = self.env['fmcg.schemes.line'].search([('product_id', '=', sku.id)], limit=1)
                pricerec = self.env['product.pricelist.item'].search([('product_id', '=', sku.id)], limit=1)

                if schmrec and len(schmrec) == 1:
                    schmavail = True
                    if schmrec.free_qty != 0:
                        schmtype = 'qty'
                    else:
                        schmtype = 'discount'
                    schmqty = schmrec.paid_qty
                    schmfree = schmrec.free_qty
                    schmdper = schmrec.scheme_product_disper
                    schmdval = schmrec.scheme_product_disamt
                    schmprod = schmrec.cross_product_id.id
                else:
                    schmtype = 'nil'
                    schmqty  = 0
                    schmfree = 0
                    schmdper = 0
                    schmdval = 0
                    schmprod = 0

                if pricerec and len(pricerec) == 1:
                    price1 = pricerec.price_ret_pc
                else:
                    price1 = 0.00

                skujson = {'sku_id': sku.id, 
                    'sku_pack': sku.pack_id.name, 
                    'sku_weight': sku.weight, 
                    'product_id': prd.id, 
                    'price': price1, 
                    'scheme_type': schmtype, 
                    'scheme_qty': schmqty, 
                    'scheme_free': schmfree, 
                    'scheme_disper': schmdper, 
                    'scheme_disamt': schmdval,
                    'scheme_product': schmprod,
                    }
                skulst.append(skujson)
                _logger.info("SKU Line %s" % skujson)

        retval = {'success': True,
            'message': 'Success!', 
            'category_list': categs, 
            'product_list': products, 
            'sku_list': skulst,
            'loss_reasons': reasons}

        return retval

    @api.model
    def get_orderno(self, companyid):

        company_id = self.env['res.company'].browse(companyid)
        last_order = self.env['sale.retailorder'].search([('company_id', '=', company_id.id)], order='order_no desc', limit=1).order_no
        if not last_order or last_order == False:
            last_order = company_id.shortname + '/RO/' + str(0).rjust(12, '0') if company_id.shortname else 'XYZ/RO/000000000000'
        last_order_num = int(last_order[-(len(last_order)-7):])
        next_order_num = last_order_num + 1
        next_order = company_id.shortname + '/RO/' + str(next_order_num).rjust(12, '0') if company_id.shortname else 'XYZ/RO/' + str(next_order_num).rjust(12, '0')
        return next_order


    @api.model
    def fmcg_retailorder_write(self, retailorder=False):

        if not retailorder or retailorder == False:
            retval = {'success': False, 'message': 'Invalid Parameter: Input Arguments', 'id': 0}
            return retval

        ro_main = retailorder['retailorder'][0]['ro_main']
        ro_line = retailorder['retailorder'][1]['ro_line']

        if not ro_main or ro_main == False:
            retval = {'success': False, 'message': 'Invalid Parameter: Order Main', 'id': 0}
            return retval

        if not ro_line or ro_line == False:
            if ro_main['order_type'] == 'online' and ro_main['order_state'] == True:
                retval = {'success': False, 'message': 'Missing Product Lines on Online Order', 'id': 0}
                return retval

        emprec  = self.env['hr.employee'].browse(ro_main['salesman_id'])
        if not emprec or emprec == False:
            retval = {'success': False, 'message': 'Sales Person not found ...', 'id': 0}
            return retval

        if not ro_main['retailer_id'] or ro_main['retailer_id'] == False:
            retval = {'success': False, 'message': 'Invalid Parameter: Retailer Id', 'id': 0}
            return retval
        else:
            retrec = self.env['res.partner'].browse(ro_main['retailer_id'])
            if not retrec or retrec == False:
                retval = {'success': False, 'message': 'Invalid Parameter: Retailer Id', 'id': 0}
                return retval

        if not ro_main['distributor_id'] or ro_main['distributor_id'] == False:
            retval = {'success': False, 'message': 'Invalid Parameter: Distributor Id', 'id': 0}
            return retval
        else:
            retrec = self.env['res.partner'].browse(ro_main['distributor_id'])
            if not retrec or retrec == False:
                retval = {'success': False, 'message': 'Invalid Parameter: Distributor Id', 'id': 0}
                return retval

        orderno = self.get_orderno(emprec.company_id.id)

        my_ordpic = ro_main['order_pic']
        if not my_ordpic or my_ordpic == '':
            my_ordpic = ''
        elif type(my_ordpic) == 'bytes':
            my_ordpic = "".join(chr, my_ordpic)

        new_id = self.env['sale.retailorder'].create({
            'customer_id': ro_main['retailer_id'], 
            'distributor_id': ro_main['distributor_id'], 
            'order_no': orderno, 
            'date': ro_main['date'], 
            'order_type': ro_main['order_type'] if ro_main['order_type'] else '', 
            'order_state': ro_main['order_state'] if ro_main['order_state'] else False, 
            'company_id': emprec.company_id.id, 
            'reason_id': ro_main['reason_id'] if ro_main['reason_id'] else 0, 
            'lat': ro_main['lat'] if ro_main['lat'] else '', 
            'lon': ro_main['lon'] if ro_main['lon'] else '', 
            'salesman_id': ro_main['salesman_id'] if ro_main['salesman_id'] else 0, 
            'joint_id': ro_main['joint_id'] if ro_main['joint_id'] else 0, 
            'order_pic': my_ordpic, 
            'gross_total': ro_main['gross_total'] if ro_main['gross_total'] else 0.00, 
            'disamt_total': ro_main['discount'] if ro_main['discount'] else 0.00, 
            'taxamt_total': ro_main['tax_total'] if ro_main['tax_total'] else 0.00, 
            'amount_total': ro_main['amount_total'] if ro_main['amount_total'] else 0.00, 
            'weight_total': ro_main['weight_total'] if ro_main['weight_total'] else 0.00
            })

        if ro_main['order_type'] == 'online' and ro_main['order_state'] == True:
            lineids = self.get_lineids(ro_line, new_id.id)
            self.env['sale.retailorder'].write((1, new_id.id, {'line_ids': lineids}))

#        _logger.info('Line IDs = %s' % lineids)
        self.env.cr.commit()
        retval = {'success': True, 'message': 'Order %s saved successfully!' % orderno, 'id': new_id.id}
        return retval


    @api.model
    def get_lineids(self, ro_line, new_id):
        lineids = []
        self.env.cr.savepoint()
        for line in ro_line:
            prodrec = self.env['product.product'].browse(line['product_id'])
            if not prodrec or prodrec == False:
                retval = {'success': False, 'message': 'Product Id %s not found!' % line['product_id'], 'id': 0}
                lineids = []
                self.env.cr.rollback()
                return lineids

            new_line_id = self.env['sale.retailorder.line'].create({
                'order_id': new_id, 
                'product_id': line['product_id'], 
                'qty': line['qty'], 
                'free': line['free'], 
                'total_qty': line['total_qty'], 
                'price': line['price'], 
                'gross': line['gross'], 
                'disper': line['disper'], 
                'disamt': line['disamt'], 
                'amount': line['amount']})

            lineids.append(new_line_id.id)

        return lineids


class fmcg_RetailOrderLines(models.Model):
    
    _name = 'sale.retailorder.line'
    _description = 'Retailers Order Lines'
    
    order_id = fields.Many2one('sale.retailorder', string='Order Id', stored=True, required=True)
    product_id = fields.Many2one('product.product', string='Product', stored=True, required=True)
    scheme_id = fields.Many2one('fmcg.schemes', string='Scheme', stored=True)
    qty = fields.Integer('Quantity')
    free = fields.Integer('Free Qty.')
    total_qty = fields.Integer('Total Qty.', compute='_get_totqty', stored=True)
    price = fields.Float('Price/Unit', stored=True)
    gross = fields.Float('Gross', compute='_get_gross', stored=True)
    disper = fields.Float('Discount %')
    disamt = fields.Float('Discount', compute='_get_discount', stored=True)
    tax_ids = fields.Many2one('account.tax', string="Taxes", stored=True)
    tax_amt = fields.Float('Tax Amount', stored=True)
    amount = fields.Float('Net Amount', compute='_get_item_amount', stored=True)
    
    @api.one
    @api.depends('qty', 'free')
    def _get_totqty(self):
        self.total_qty = self.qty + self.free
    
    @api.one
    @api.depends('qty', 'price')
    def _get_gross(self):
        self.gross = self.qty * self.price
    
    @api.one
    @api.depends('qty', 'gross')
    def _get_discount(self):
        self.disamt = self.gross * self.disper / 100
    
    @api.one
    @api.depends('qty', 'free', 'price', 'disper', 'disamt', 'tax_ids')
    def _get_item_amount(self):
        self.amount = self.gross + self.tax_amt - self.disamt
    
