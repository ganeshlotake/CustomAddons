from odoo import models, fields, api, _

class fmcg_PriceList(models.Model):
    
    _inherit = 'product.pricelist'
    
    region_id = fields.Many2one('geographies.regions', string='Applicable to Region')


class fmcg_PriceListItems(models.Model):
    
    _inherit = 'product.pricelist.item'
    
    price_piece = fields.Float('Price/Pc')
    price_ret_pc = fields.Float('Retailer Price/Pc')
    price_ret_kg = fields.Float('Retailer Price/Kg')
    price_mrp = fields.Float('Max.Retail Price')
    distributor_margin = fields.Float('Distributor Margin')
    distributor_disper = fields.Float('Distributor Discount')
    price_tax = fields.Many2many('account.tax', string="Tax")

    @api.onchange('fixed_price')
    def _compute_price_piece(self):

        if self.applied_on == '1_product':
            pkgwt = self.product_tmpl_id.weight
            boxwt = self.product_tmpl_id.box_wt
            if pkgwt != 0.00:
                nopcs = int(boxwt / pkgwt)
            else:
                nopcs = 0.00
            if nopcs != 0.00:
                self.price_piece = self.fixed_price / nopcs
        elif self.applied_on == '0_product_variant':
            pkgwt = self.product_id.weight
            boxwt = self.product_id.box_wt
            if pkgwt != 0.00:
                nopcs = int(boxwt / pkgwt)
            else:
                nopcs = 0.00
            if nopcs != 0.00:
                self.price_piece = self.fixed_price / nopcs

    @api.onchange('price_piece')
    def _compute_fixed_price(self):
        if self.applied_on == '1_product':
            pkgwt = self.product_tmpl_id.weight
            boxwt = self.product_tmpl_id.box_wt
            if pkgwt != 0.00:
                nopcs = int(boxwt / pkgwt)
            else:
                nopcs = 0.00
            if nopcs != 0.00:
                self.fixed_price = self.price_piece * nopcs
        elif self.applied_on == '0_product_variant':
            pkgwt = self.product_id.weight
            boxwt = self.product_id.box_wt
            if pkgwt != 0.00:
                nopcs = int(boxwt / pkgwt)
            else:
                nopcs = 0.00
            if nopcs != 0.00:
                self.fixed_price = self.price_piece * nopcs
