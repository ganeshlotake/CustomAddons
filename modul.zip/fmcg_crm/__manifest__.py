# -*- coding: utf-8 -*-
{
    'name': "FMCG CRM",

    'summary': """
       fmcg crm """,

    'description': """
        fmcg crm
    """,

    'author': "Jayant Bulbule, SynerBize, Inc.",
    'website': "http://www.synerbize.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base', 'base_address_city', 'crm', 'sale_crm', 'sale',
        'base_geolocalize', 'auth_signup', 'pob', 'sale_stock'],

    # always loaded
    'data': [
        'report/sbiz_header_footer_standard_packing_list.xml',
        'report/sbiz_header_footer_invoice_unreturned_materials.xml',
        'views/geographies.xml',
        'views/fmcg_sale.xml',
        'views/product_extended.xml',
        'views/sbiz_ecom_delivery_views.xml',
        'views/fmcg_partner_view.xml',
        'views/auth_signup_extend_views.xml',
        #'views/fmcg_sale_order_extended.xml',
        'views/templates.xml',
    	'views/product_pack.xml',
        'views/fmcg_sale_allocate.xml',
        'views/sbiz_ecom_config.xml',
        'views/sbiz_ecom_user_account.xml',
        'views/delivery_packing_list.xml',
        'report/template_demo.xml',
        'report/route_sheet_template.xml',
        'report/route_sheet.xml',
        'report/invoice_pos_main_report.xml',
        'report/invoice_pos_report.xml',
        'report/route_allocation_wizard_view.xml',
        #'report/sale_picklist_report.xml',
        #'report/sale_picklist_main_report.xml',
        'report/sbiz_report_template_packing_list.xml',
        'report/sbiz_report_template_body_packing_list.xml',
        'report/sbiz_packing_list_view.xml',
        'report/sbiz_invoice_unreturned_report_view.xml',
        'report/sbiz_report_template_invoice_unreturned_materials.xml',
        'report/sbiz_report_template_body_invoice_unreturned_materials.xml',
        'views/res_partner_form_inherit.xml',
        'views/account_invoice_inherit_view.xml',
        'views/stock_piciking_inhe_view.xml',
        'views/fmcg_sale_pob_extend.xml',
	'views/fmcg_purchase.xml',
	'views/geographies_ps_enroutes.xml',
        'views/geographies_ps_routes.xml',
#        'views/geographies_extend.xml',
   ],

    # loading javascript file
    # 'js': ['static/src/js/geo.js'],


    # only loaded in demonstration mode
    # 'demo': [
    #     'demo/demo.xml',
    # ],
    'application': True,
}
