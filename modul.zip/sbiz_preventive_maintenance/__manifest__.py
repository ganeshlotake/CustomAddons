# -*- coding: utf-8 -*-
{
    'name': "sbiz_preventive_maintenance",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,

    'author': "My Company",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/12.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'maintenance','hr_maintenance', 'mail','portal'],

    # always loaded
    'data': [
        'views/SBiz_preventive_checklist_view.xml',
        'views/SBiz_maintenance_location_view.xml',
        'views/SBiz_res_users_view.xml',
        'views/sbiz_config_settings.xml',
        'views/SBiz_cmms_equipment_view.xml',
        'security/preventive_security_group.xml',
        'wizard/SBiz_preventive_order_remark_wizard_view.xml',
        'views/SBiz_preventive_order_view.xml',
        'wizard/SBiz_preventive_wizard_view.xml',
        'views/SBiz_preventive_schedule_view.xml',
        'views/SBiz_preventive_menu.xml',
        'wizard/SBiz_order_creation_wizard_view.xml',
        'views/SBiz_email_templates.xml',
        # 'views/SBiz_preventive_order_line_timer.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}