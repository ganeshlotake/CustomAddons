# -*- coding: utf-8 -*-

from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT


maintenance_calendar_start = ''
maintenance_calendar_end   = ''

#Added by ajinkya joshi on 25-07-2020
class CmmsEquipment(models.Model):
    _name = 'cmms.equipment'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = ' CMMS Equipment Master'
    _order = 'id'
    _rec_name   = 'equipment_name'
    
    equipment_name          = fields.Char('Name', required=True, track_visibility='onchange')
    image                   = fields.Binary(string="Image", track_visibility='onchange')
    tag_id                  = fields.Char(string='Tag ID',required=True,store=True)
    company_id              = fields.Many2one('res.company', string='Plant',default=lambda self: self.env.user.company_id,required=True,store=True)
    maintenance_team_ids    = fields.Many2many(comodel_name='maintenance.team',string="Responsible Teams",required=True,store=True)
    location_id             = fields.Many2one('maintenance.location',string="Location",required=True,store=True)
    location                = fields.Char(string="Functional Location",required=True,store=True)
    parent_equipment_code   = fields.Many2one('cmms.equipment',string='Parent Equipment')
    equipment_abc_indicator = fields.Selection(selection=[('a', 'A'), ('b', 'B'), ('c', 'C')], string="ABC Indicator",required=True,store=True)
    equipment_asset_code    = fields.Char('Asset Code',required=True,store=True)
    partner_id              = fields.Many2one('res.partner',string="Maintenance Partner")
    partner_ref             = fields.Char('Vendor Invoice')
    make                    = fields.Char('Make',required=True,store=True)
    model                   = fields.Char('Model',required=True,store=True)
    serial_no               = fields.Char('Serial No.',required=True,store=True)
    purchase_date           = fields.Date('Purchase Date')
    start_date              = fields.Date('Warranty/AMC Start Date')
    end_date                = fields.Date('Warranty/AMC End Date')
    checklist_id            = fields.Many2one('preventive.checklist', string="Check List", required=True, store=True)
    frequency               = fields.Integer('Frequency',required=True,store=True)
    frequency_type          = fields.Selection(selection=[('days', 'Days'), ('months', 'Months')], default='months',string="Frequency Type",required=True,store=True)
    negative_tolerance      = fields.Float('Tolerance Days From',required=True,store=True,compute='get_tolerance_from_equipment_abc_indicator',readonly=False)
    positive_tolerance      = fields.Float('Tolerance Days To',required=True,store=True,compute='get_tolerance_from_equipment_abc_indicator',readonly=False)
    last_maintenance_date   = fields.Date('Last Maintenance Date',required=True,store=True)
    barcode                 = fields.Char('Barcode',required=True,store=True)
    active                  = fields.Boolean('Active',default=True)
    attachment              = fields.Many2many(comodel_name='ir.attachment',string="Attachment(s)")
    maintenance_history_ids = fields.One2many('preventive.equipment.history','equipment_id')
    planner_ids             = fields.Many2many(comodel_name='res.users', string='Planner',  domain=[('user_role','=',1)], required=True, store=True, track_visibility='onchange')
    technician_ids          = fields.Many2many(comodel_name='res.users', string='Technician', store=True, domain=[('user_role','=',2)], track_visibility='onchange')
    business_user_ids       = fields.Many2many(comodel_name='res.users', string='Business User',required=True,store=True, domain=[('user_role','=',3)], track_visibility='onchange')
    qa_user_ids             = fields.Many2many(comodel_name='res.users', string='QA User', store=True, domain=[('user_role','=',4)], track_visibility='onchange')
    supervisor_ids          = fields.Many2many(comodel_name='res.users', string='Supervisor',required=True,store=True, domain=[('user_role','=',5)], track_visibility='onchange')
    attachment_line         = fields.One2many(comodel_name='preventive.equipment.attachment', inverse_name='equipment_id')
    schedule_ids            = fields.One2many(comodel_name="preventive.schedule", inverse_name="equipment_id", string="Schedule", stored=True)
    description             = fields.Text('Description', track_visibility='onchange')
    state                   = fields.Selection(selection=[('created', 'Created'), ('scheduled', 'Scheduled')], 
				string="Status", readonly=True, index=True, default='created', track_visibility='onchange')
    checklist_lines         = fields.One2many('cmms.equipment.checklist','equipment_id', string='Checklist Lines')

    @api.multi
    def copy(self):
        if self.env.uid > 2:
            raise ValidationError('You are not authorized to deplicate the records from Calibration Instrument. Please contact System Administrator.')

    @api.multi
    def unlink(self):
        if self.env.uid > 2:
            raise UserError(_('You are not authorized to delete the records from Calibration Instrument. Please contact System Administrator.'))
        res = super(CmmsEquipment, self).unlink()
        return res

    @api.onchange('checklist_id')
    def assign_checklist(self):
        if not self.checklist_id:
            return

        active_id = self.env.context.get('active_id')
        if active_id :
            checklist_recs = self.env['cmms.equipment.checklist'].search([('equipment_id', '=', active_id)])
            if checklist_recs or len(checklist_recs) > 0:
                checklist_recs.unlink()
                        
        checklist_recs = self.env['preventive.checklist.action'].search([('checklist_id', '=', self.checklist_id.id)])
        recids = []
        for rec in checklist_recs:
            addrow = {
                'equipment_id' : self.id,
                'action_no'    : rec.action_no,
                'action_name'  : rec.action_name,
                'description'  : rec.description,
                'hours'        : rec.hours,
                'minutes'      : rec.minutes,
            }
            newid = self.env['cmms.equipment.checklist'].create(addrow)
            recids.append(newid.id)

        self.checklist_lines = recids

    

    @api.onchange('positive_tolerance')
    def to_check_enter_value_ispositive(self):
        if self.positive_tolerance:
            if self.positive_tolerance < 0 :
                raise UserError(_("Please Enter Positive Value"))


    @api.onchange('negative_tolerance')
    def to_check_enter_value_isnegative(self):
        if self.negative_tolerance:
            if self.negative_tolerance > 0 :
                raise UserError(_('Please Enter Negative Value'))

        
    @api.constrains('id')
    def send_mail(self):
        template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_create_equipment')
        template.send_mail(self.id,template.id) 
     
    #created by ajinkya joshi on 10-july-2020    
    @api.model
    def create(self,vals):
        if vals['frequency'] == 0:
            raise UserError(_("Frequency must be greater than 0"))   
        res = super(CmmsEquipment,self).create(vals)
        return res
        
        
        
    @api.multi
    def write(self,vals):
        li=[]
        if  'frequency' in vals and vals['frequency']==0:
            raise ValidationError(_("Frequency must be greater than 0"))
        res = super(CmmsEquipment,self).write(vals)
        mail_obj = self.env['mail.mail']
        mail_sub = " Equipment """+self.equipment_name +""" ID has been modified"""
        for i in self.planner_ids:
            if i:
                li.append(i.login)
        for j in li:
            #  template = self.env['ir.model.data'].get_object('calibration_custom_model', 'to_send_mail_modify_instrument')
            #  template.send_mail(i.id,template.id)
            body_html = """<p>Dear User,<br/>
                Equipment <strong>"""+self.equipment_name+"""</strong> ID has been modified <br/>
                
                Please access the Equipment"""+self.equipment_name+""" at 
                <div style="text-align: center; margin: 16px 0px 16px -1046px; font-size: 14px;">
                        <a href="""+str(self.get_base_url())+"""/web#id=${object.id}&amp;action=594&amp;model=cmms.equipment&amp;view_type=form&amp;menu_id=497" target="_blank" style="text-decoration:none;background-color: #875A7B; padding: 8px 16px 8px 16px; text-decoration: none; color: #fff; border-radius: 5px; font-size:13px;">
                            View Modified Equipment
                        </a>
                </div> for additional details.
                <br/><br/>

                Regards!<br/>
                It is a system generated message,please do not reply.</p>
                """
            mail_rec = {
                    'email_from': self.company_id.email,
                    'email_to'  : j,
                    'body_html' : body_html,
                    'subject'   : mail_sub,
                }
            mail = mail_obj.create(mail_rec)
            mail.send()
        return res #{'type': 'ir.actions.act_window_close'}
        
    @api.multi
    def get_base_url(self):
        base = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        return base
    
    @api.depends('equipment_abc_indicator')
    def get_tolerance_from_equipment_abc_indicator(self):
        MAINTENANCE_CALENDAR_START = self.env['ir.config_parameter'].sudo().get_param('maintenance.maintenance_calendar_start')
        MAINTENANCE_CALENDAR_END   = self.env['ir.config_parameter'].sudo().get_param('maintenance.maintenance_calendar_end')
        if self.equipment_abc_indicator:
            if self.equipment_abc_indicator == 'a':
                ir_config_parameter_obj = self.env['res.config.settings'].search([('maintenance_calendar_start','=',MAINTENANCE_CALENDAR_START),('maintenance_calendar_end','=',MAINTENANCE_CALENDAR_END)])
                self.negative_tolerance = int(ir_config_parameter_obj.a_setting_tol_from)
                self.positive_tolerance = int(ir_config_parameter_obj.a_setting_tol_to)
            elif self.equipment_abc_indicator == 'b':
                ir_config_parameter_obj = self.env['res.config.settings'].search([('maintenance_calendar_start','=',MAINTENANCE_CALENDAR_START),('maintenance_calendar_end','=',MAINTENANCE_CALENDAR_END)])
                self.negative_tolerance = int(ir_config_parameter_obj.b_setting_tol_from)
                self.positive_tolerance = int(ir_config_parameter_obj.b_setting_tol_to)
            elif self.equipment_abc_indicator == 'c':
                ir_config_parameter_obj = self.env['res.config.settings'].search([('maintenance_calendar_start','=',MAINTENANCE_CALENDAR_START),('maintenance_calendar_end','=',MAINTENANCE_CALENDAR_END)])
                self.negative_tolerance = int(ir_config_parameter_obj.c_setting_tol_from)
                self.positive_tolerance = int(ir_config_parameter_obj.c_setting_tol_to)

class MaintenanceHistory(models.Model):
    _name = 'preventive.equipment.history'
    _description = 'Preventive Equipment History'


    equipment_id                    = fields.Many2one('cmms.equipment',string="Equipment")
    inspection_lot                  = fields.Char('Inspection Lot')  
    last_maintenance_date           = fields.Datetime('Last Maintenance On')
    next_maintenance_date           = fields.Datetime('Next Maintenance Date')
    master_order                    = fields.Char()
    cert_no                         = fields.Char('Certificate Number')
    cert_date                       = fields.Datetime('Certificate Date')
    cert_file                       = fields.Binary('Upload Document')
    company_id                      = fields.Many2one('res.company',string='Company / Plant')
    order_no                        = fields.Many2one('preventive.order',string="Order No")
    planner_id                      = fields.Many2one('res.users',string="Planner")
    bu_user_id                      = fields.Many2one('res.users',string="BU User")
    qauser_id                       = fields.Many2one('res.users',string="QA User")
    supervisor_id                   = fields.Many2one('res.users',string="Supervisor User")
    order_success                   =  fields.Boolean('Order Success')
    order_status                    = fields.Selection(string='Status',selection=[
                                        ('create', 'Create'),('active', 'Active'),('assign','Assign'),('start','Start'),
                                        ('release','Release'),('pre_approval','Pre-Approval'),('in_process','In Process'),
                                        ('complete','Complete'),('post_approval','Post Approval'),('closed','Closed'),('rejected','Rejected'),('unassign','Unassign'),('expired','Expired')])
    remark                          = fields.Char('Remark')
    result                          = fields.Char('Result')
    attachment_ids                  = fields.Many2many('ir.attachment',string='Files')
class EquipmentMasterAttachment(models.Model):
    _name = 'preventive.equipment.attachment'
    _description = 'Preventive Equipment Attachment'
    _order = 'attachment'

    name            = fields.Char(string='Name')
    equipment_id    = fields.Many2one(comodel_name='cmms.equipment')
    attachment      = fields.Binary(string='Attachment', attachment="True")
    description     = fields.Char(string='Description')
    company_id      = fields.Many2one(comodel_name='res.company', string='Company / Plant',  store=True, related='equipment_id.company_id')


class UserRoleMasters(models.Model):
    _name        = 'preventive.user.role'   
    _description = 'Preventive User Role Master'
    _rec_name    = 'user_role'

    user_role    = fields.Char(string="User Role")
    group_name   = fields.Char(string="Group Name")
    company_id   = fields.Many2one(comodel_name='res.company', string='Company / Plant',  store=True, default=1)

    @api.model
    def create(self, values):
        if values:
            if values['group_name'] not in ['Preventive Planner','Preventive Technician','Preventive Business User','Preventive QA User','Preventive Supervisor User']: 
                raise UserError(_("Please Used Group Name As Preventive Planner or Preventive Technician or Preventive Business User or Preventive QA User or Preventive Supervisor User"))
            elif values['user_role'] not in ['Engineering Planner','Technician','Business User','QA User','Supervisor User']:
                raise UserError(_("Please Assign User Role As Engineering Planner or Technician or Business User or QA User or Supervisor User")) 
            res = super(UserRoleMasters, self).create(values)
            return res

class EquipmentChecklistAction(models.Model):
    _name        = 'cmms.equipment.checklist'
    _description = 'Equipment Checklist'

    equipment_id = fields.Many2one('cmms.equipment',string="Equipment")
    action_no    = fields.Char('Action No')
    action_name  = fields.Char('Action Name')
    description  = fields.Text('Action Description')
    hours        = fields.Integer('Hours')
    minutes      = fields.Integer('Minutes')
