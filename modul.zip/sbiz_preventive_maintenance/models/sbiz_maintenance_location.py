from odoo.exceptions import ValidationError
from odoo import api, fields, models ,_


class  MaintenanceLocation(models.Model):
    
    _name = 'maintenance.location'
    _description = 'SBiz Plant Maintenance - Functional Location'
    
    _sql_constraints = [
        ('name_uniq', 'UNIQUE (name)',  'Functional Location Already Exists!')
    ]
    
    name = fields.Char(string="Functional Location", required=True, store=True)
    parent_id = fields.Many2one(comodel_name='maintenance.location', string="Parent Location")
    location_type = fields.Selection(string="Location Type", selection=[('int', 'Internal'), ('ext', 'External')],required=True,store=True)
    company_id = fields.Many2one(comodel_name='res.company', string="Plant", required=True, store=True)
    barcode = fields.Char(string="BarCode")
    