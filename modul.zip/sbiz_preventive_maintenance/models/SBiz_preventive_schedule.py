# -*- coding: utf-8 -*-

from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT

#Added by ajinkya joshi on 25-07-2020
class PreventiveSchedule(models.Model):
    _name           = 'preventive.schedule'
    _description    = 'Preventive Schedule'
    _order          = 'name'
    _inherit        = ['mail.thread', 'mail.activity.mixin']
    
    name                            = fields.Char('Scheduel Name',readonly=True,store=True,index=True,copy=False,default=lambda self: _('New'))
    current_user                    = fields.Many2one('res.users',string="User") 
    equipment_id                    = fields.Many2one('cmms.equipment',string="Equipment")
    last_maintenance_date           = fields.Date('Last Maintenance Date')
    due_date                        = fields.Date('Due Date')
    from_date                       = fields.Date('From Date')
    to_date                         = fields.Date('To Date')
    final_date                      = fields.Date('Final Date')
    planner_id                      = fields.Many2one('res.users',string="Planner", domain=[('user_role','=',1)])
    technician_id                   = fields.Many2one('res.users',string="Technician", domain=[('user_role','=',2)])
    business_user_id                = fields.Many2one('res.users',string="Business User", domain=[('user_role','=',3)])
    qa_user_id                      = fields.Many2one('res.users',string="QA User", domain=[('user_role','=',4)])
    supervisor_id                   = fields.Many2one('res.users',string="Supervisor", domain=[('user_role','=',5)])
    state                           = fields.Selection(selection=[
                                        ('draft', 'Draft'), ('in_approval', 'In Approval'),('su_approved', 'Supervisor Approved'), ('bu_approved', 'Business Approved'), 
                                        ('qa_approved', 'QA Approved'), ('reject', 'Rejected'), ('order_ok', 'Order Created'), ('expired', 'Expired')], string='State', track_visibility='onchange')
    order_created                   = fields.Selection(selection=[('created','Created'),('notcreated','Not Created')],default='notcreated')
    supervisor_approval             = fields.Selection(string="Supervisor Approval",selection=[('draft','Draft'),('approve','Approved'),('requested','Requested'),('reject','Rejected')],default='draft')
    bu_approval                     = fields.Selection(string='BU Approval',selection=[('draft','Draft'),('approve','Approved'),('requested','Requested'),('reject','Rejected')],default='draft')
    qa_approval                     = fields.Selection(string='QA Approval',selection=[('draft','Draft'),('approve','Approved'),('requested','Requested'),('reject','Rejected')],default='draft')
    rejected_remark                 = fields.Char('Remark')
    company_id                      = fields.Many2one('res.company',string="Company / Plant")

    #added by ajinkyajoshi on 15-june-2020
    @api.model
    def create(self, vals):
        if 'equipment_id' in vals:                         
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('preventive.schedule') or _('New')
            result = super(PreventiveSchedule, self).create(vals)        

            return result

    @api.onchange('final_date')
    def validate_final_date(self):
        if self.final_date < self.from_date or self.final_date > self.to_date:
            raise UserError(_('The Final Date MUST be between From and To dates'))


    @api.multi
    def get_remark(self):
        my_remark = ''
        if self:
            if self.rejected_remark:
                my_remark = self.rejected_remark
            else:
                my_remark = ''
        return my_remark
        
    


    @api.model
    def schedule_form_action(self, values):
        active_id = values
        context = self.env.context
        return {
                'name': _('Schedule Edit Form'),
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'preventive.schedule',
                'res_id': active_id,
                'context': context,
                'view_id': self.env.ref('sbiz_preventive_maintenance.preventive_schedule_editing_form').id,
                'type': 'ir.actions.act_window',
                'target':'new'
            }


    @api.multi
    def unlink(self):
        if self.env.uid > 2:
            raise UserError(_('You are not authorized to delete the records from Preventive Schedule. Please contact System Administrator.'))
        res = super(PreventiveSchedule, self).unlink()
        return res
    
    @api.multi
    def copy(self):
        if self.env.uid > 2:
            raise ValidationError('You are not authorized to duplicate the records from Preventive Order. Please contact System Administrator.')
 
    
    @api.multi
    def get_base_url(self):
        """When using multi-website, we want the user to be redirected to the
        most appropriate website if possible."""
        base_url =  self.env['ir.config_parameter'].sudo().get_param('web.base.url')        
        return base_url
