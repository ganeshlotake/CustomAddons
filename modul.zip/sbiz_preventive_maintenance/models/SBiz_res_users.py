# -*- coding: utf-8 -*-

from datetime import date, datetime, timedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT

class ResUsersExtended(models.Model):
    _inherit = 'res.users'

    user_role  = fields.Many2one(comodel_name="preventive.user.role")
    maintenance_team_ids = fields.Many2many(comodel_name='maintenance.team', string='Responsible Team', 
        store=True, required=True)

    @api.constrains('user_role')
    def assign_groups_access(self):
        user_object=self.search([('id','=',self.id)])
        if  user_object:
            maintenance_user_object   = self.env['preventive.user.role'].search([('id','=',user_object.user_role.id)])
            res_groups_object         = self.env['res.groups'].search([('name','=',maintenance_user_object.group_name)])
            if maintenance_user_object.user_role == 'Engineering Planner':
                if maintenance_user_object.group_name == 'Preventive Planner':
                    res_groups_object.users=[(4,user_object.id)]        
            elif maintenance_user_object.user_role == 'Technician':
                if maintenance_user_object.group_name == 'Preventive Technician':
                    res_groups_object.users=[(4,user_object.id)]
            elif maintenance_user_object.user_role == 'Business User':
                if maintenance_user_object.group_name == 'Preventive Business User':
                    res_groups_object.users=[(4,user_object.id)]
            elif maintenance_user_object.user_role == 'QA User':
                if maintenance_user_object.group_name == 'Preventive QA User':
                    res_groups_object.users=[(4,user_object.id)]
            elif maintenance_user_object.user_role == 'Supervisor User':
                if maintenance_user_object.group_name == 'Preventive Supervisor User':
                    res_groups_object.users=[(4,user_object.id)]

    @api.multi
    def copy(self):
        if self.env.uid > 2:
            raise ValidationError('You are not authorized to deplicate the records from User. Please contact System Administrator.')
