# -*- coding: utf-8 -*-

from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT

#Added by ajinkya joshi on 25-07-2020
class PreventiveChecklist(models.Model):
    _name = 'preventive.checklist'
    _description = 'Preventive Checklist Header'
    _order = 'check_no'
    
    check_no                        = fields.Char('Check No',required=True, readonly=True, index=True, copy=False, default=lambda self: _('New'),store=True)
    name                            = fields.Char('Name',required=True,store=True)
    description                     = fields.Text('Description')   
    duration                        = fields.Float('Duration(Days)',required=True,store=True)
    active                          = fields.Boolean('Active',default=True)
    checklist_action_ids            = fields.One2many('preventive.checklist.action','checklist_id')
    
    
    @api.model
    def create(self, vals):
        if vals.get('check_no', _('New')) == _('New'):
            vals['check_no'] = self.env['ir.sequence'].next_by_code('preventive.checklist') or _('New')
        result = super(PreventiveChecklist, self).create(vals)
        return result

    
    @api.constrains('checklist_action_ids')
    def validate_hours_and_mintues(self):
        if self.checklist_action_ids:
            for i in self.checklist_action_ids:
                if i.hours == 0 and i.minutes == 0:
                    raise UserError(_("Hours and Minutes must be greater than 0"))

class PreventiveChecklistAction(models.Model):
    _name = 'preventive.checklist.action'
    _description = 'Preventive Checklist Action Details'

    checklist_id                    = fields.Many2one('preventive.checklist',string="Checklist")
    action_no                       = fields.Char('Action No',required=True, readonly=True, index=True, copy=False, default=lambda self: _('New'))
    action_name                     = fields.Char('Action Name',required=True,store=True)
    description                     = fields.Text('Action Description')
    hours                           = fields.Integer('Hours')
    minutes                         = fields.Integer('Minutes')
    previous_action                 = fields.Many2one('preventive.checklist.action')
    
    @api.model
    def create(self, vals):
        if vals.get('action_no', _('New')) == _('New'):
            order_line_no = self.env['ir.sequence'].next_by_code('preventive.checklist.action') or _('New')
            checklist_id = vals['checklist_id']
            checklist_obj = self.env['preventive.checklist'].search([('id','=',checklist_id)])
            vals['action_no'] = order_line_no.replace('X',checklist_obj.check_no)
        result = super(PreventiveChecklistAction, self).create(vals)
        return result

   



    