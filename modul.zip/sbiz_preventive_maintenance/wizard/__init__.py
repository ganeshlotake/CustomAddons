# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import SBiz_preventive_equipment_wizard
from . import SBiz_preventive_schedule_wizard
from . import SBiz_preventive_order_remark_wizard

