from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT


# create_by | create_date | update_by | update_date
#           |  27/07/2020 |           | 
    

class PreventiveOrderRemark(models.Model):
    _name        = 'preventive.order.remark'
    _description = 'Order Remarks'

            
    remark               = fields.Text(string='Remark')    
    status               = fields.Char(string='Action (Reject or Approve)')
    user_id              = fields.Many2one(comodel_name='res.users')
    order_id             = fields.Many2one(comodel_name='preventive.order')
    order_status         = fields.Selection(related='order_id.order_status',string="Order Status", store=True)    
    safety_clearance     = fields.Boolean(string="Safety Clearance taken")
    production_clearance = fields.Boolean(string="Production Clearance Taken")
    electrical_clearance = fields.Boolean(string="Electrical Clearance Taken") 
    technician_id        = fields.Many2one(comodel_name='res.users', string='Technician', domain="[('user_role','=',2)]")  
    remark_date          = fields.Datetime(string='Remark Date', default=datetime.now()) 
    clearance_date       = fields.Date(string='Clearance Date', default=date.today())
    can_be_used          = fields.Boolean(string='Can Be Used',related="order_id.can_be_used",store=True,readonly=False)
    boolean_flag         = fields.Boolean(string="Boolean Flag", related="order_id.order_success",store=True)

    # Following Logic Is For Remark Approve And Go To Next State Of Order
    @api.multi
    def approve(self,values):
        active_id = values['active_id']
        preventive_order_object=self.env['preventive.order'].search([('id','=',active_id)])
        if preventive_order_object:
            template              = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_stagewise_approval')
            template_assigned     = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_for_assigned_order')
            template_preapproval  = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_for_preapproval_order') 
            template_postapproval = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_for_postapproval_order')
            template_closed       = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance','to_send_mail_for_closed_order')
            template_complete     = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance','to_send_mail_for_complete_order')
            if preventive_order_object.order_status == 'in_process':
                calibartion_order_object_line = self.env['preventive.order.line'].search([('yes','=',False),('no','=',False),('preventive_order_id','=',preventive_order_object.id)])
                for i in calibartion_order_object_line:
                    if i:
                        raise ValidationError(_("Please enter the checklist feedback"))
            
            if preventive_order_object.order_status == 'complete':     
                if self.can_be_used == False:
                    preventive_order_object.can_be_used = self.can_be_used
                    instrument_obj = self.env['cmms.equipment'].search([('id','=',preventive_order_object.instrument_id.id)])
                    instrument_obj.write({'active':False})
                    schedule_obj = self.env['preventive.schedule'].search([('instrument_id','=',preventive_order_object.instrument_id.id),('due_date','>',preventive_order_object.due_date)])
                    for i in schedule_obj:
                        i.write({'state':'expired'})
                    order_obj = self.env['preventive.order'].search([('instrument_id','=',preventive_order_object.instrument_id.id),('order_status','!=','closed')])
                    for j in order_obj:
                        j.write({'order_status':'closed'})
                        preventive_hist = {
                            'order_no':preventive_order_object.id,
                            'equipment_id':preventive_order_object.equipment_id.id,
                            'last_maintenance_date': date.today(),
                            'order_status': preventive_order_object.order_status,
                            'remark' : self.remark,
                            'planner_id': preventive_order_object.planner_id.id,
                            'bu_user_id': preventive_order_object.business_id.id,
                            'qauser_id': preventive_order_object.qa_id.id,
                            'supervisor_id': preventive_order_object.supervisor_id.id,
                            'result':'Pass' if preventive_order_object.order_success == True else 'Fail',
                            'company_id' : preventive_order_object.company_id.id,
                        }
                        preventive_hist_obj = self.env['preventive.equipment.history']
                        preventive_hist_obj.create(preventive_hist)
                if not self.remark:
                    raise UserError(_("Please Remark"))
            if preventive_order_object.order_status == 'release':
                if self.clearance_date:
                    if self.clearance_date < date.today():
                        raise UserError("Clerance Date Should Be Todays Date Or Future Date")
                if not self.remark:
                    raise UserError(_("Please Eneter Remark"))
            if preventive_order_object.order_status == 'create':
                preventive_order_object.write({'order_status':'active'})
                template.send_mail(preventive_order_object.id, template.id)
            elif preventive_order_object.order_status == 'active':
                if not self.technician_id :
                    raise UserError(_("Please Assign Technician"))
                preventive_order_object.write({'order_status':'assign'})
                preventive_order_object.write({'technician_id':self.technician_id.id})
                template_assigned.send_mail(preventive_order_object.id, template_assigned.id)
            elif preventive_order_object.order_status == 'assign':
                preventive_order_object.write({'order_status':'start'})
                template.send_mail(preventive_order_object.id, template.id)
            elif preventive_order_object.order_status == 'start':
                preventive_order_object.write({'order_status':'release'})
                template.send_mail(preventive_order_object.id, template.id)
            elif preventive_order_object.order_status == 'release':
                if not self.safety_clearance or not self.production_clearance or not self.electrical_clearance:
                    raise UserError(_("Please check Safety, Production and Electrical Clearance"))
                preventive_order_object.write({'order_status':'pre_approval'})
                template_preapproval.send_mail(preventive_order_object.id, template_preapproval.id)
            elif preventive_order_object.order_status == 'pre_approval':
                preventive_order_object.write({'order_status':'in_process'})
                template_preapproval.send_mail(preventive_order_object.id, template_preapproval.id)
            elif preventive_order_object.order_status == 'in_process':               
                preventive_order_object.write({'order_status':'complete','actual_completion_date': date.today()})
                template_complete.send_mail(preventive_order_object.id, template_complete.id)
            elif preventive_order_object.order_status == 'complete':
                preventive_order_object.write({'order_status':'post_approval_su'})
                template_postapproval.send_mail(preventive_order_object.id, template_postapproval.id)
            elif preventive_order_object.order_status == 'post_approval_su':
                preventive_order_object.write({'order_status':'post_approval_bu'})
                template_postapproval.send_mail(preventive_order_object.id, template_postapproval.id)
            elif preventive_order_object.order_status == 'post_approval_bu':
                preventive_order_object.write({'order_status':'post_approval_qa'})
                template_postapproval.send_mail(preventive_order_object.id, template_postapproval.id)
            elif preventive_order_object.order_status == 'post_approval_qa': 
                preventive_order_object.write({'order_status':'closed'})
                preventive_hist = {
                    'order_no':preventive_order_object.id,
                    'equipment_id':preventive_order_object.equipment_id.id,
                    'last_maintenance_date': date.today(),
                    'order_status': preventive_order_object.order_status,
                    'remark' : self.remark,
                    'planner_id': preventive_order_object.planner_id.id,
                    'bu_user_id': preventive_order_object.business_id.id,
                    'qauser_id': preventive_order_object.qa_id.id,
                    'supervisor_id': preventive_order_object.supervisor_id.id,
                    'result':'Pass' if preventive_order_object.order_success == True else 'Fail',
                    'company_id' : preventive_order_object.company_id.id,
                }
                preventive_hist_obj = self.env['preventive.equipment.history']
                hid = preventive_hist_obj.create(preventive_hist)
                if preventive_order_object.attachment_ids:
                    hid.attachment_ids = preventive_order_object.attachment_ids                    
                template_closed.send_mail(preventive_order_object.id, template_closed.id)
            elif preventive_order_object.order_status == 'unassign':
                preventive_order_object.write({'order_status':'assign'})
                preventive_order_object.write({'technician_id':self.technician_id.id})
                template.send_mail(preventive_order_object.id, template.id)  
            reject_vals = {
                'remark':self.remark,
                'status':'Approve',
                'user_id':values['uid'],
                'order_id':active_id,
                'remark_date':self.remark_date
            }
            preventive_remark=self.env['preventive.order.remark']
            preventive_remark.create(reject_vals)
            remarkdata = preventive_remark.search([('user_id','=',False),('safety_clearance','=',False),('production_clearance','=',False),('electrical_clearance','=',False),('boolean_flag','=',True)])
            remarkdata.unlink()
    
    @api.multi
    def rework(self,values):
        active_id = values['active_id']
        preventive_order_object=self.env['preventive.order'].search([('id','=',active_id)])
        if preventive_order_object:
            if preventive_order_object.order_status == 'post_approval':
                preventive_order_object.write({'order_status':'complete'})
            elif preventive_order_object.order_status == 'complete':
                preventive_order_object.write({'order_status':'in_process'})
            elif preventive_order_object.order_status == 'in_process':
                preventive_order_object.write({'order_status':'pre_approval'})
            elif preventive_order_object.order_status == 'pre_approval':
                preventive_order_object.write({'order_status':'release'})
            elif preventive_order_object.order_status == 'release':
                preventive_order_object.write({'order_status':'start'})
            elif preventive_order_object.order_status == 'start':
                preventive_order_object.write({'order_status':'assign'})
            elif preventive_order_object.order_status == 'assign':
                preventive_order_object.write({'order_status':'active'})
            elif preventive_order_object.order_status == 'active':
                preventive_order_object.write({'order_status':'create'})           
            reject_vals = {
                'remark':self.remark,
                'status':'Rework',
                'user_id':values['uid'],
                'order_id':active_id,
                'remark_date':self.remark_date
            }
            preventive_remark=self.env['preventive.order.remark']
            preventive_remark.create(reject_vals)
            remarkdata = preventive_remark.search([('user_id','=',False),('safety_clearance','=',False),('production_clearance','=',False),('electrical_clearance','=',False),('boolean_flag','=',True)])
            remarkdata.unlink()

    # Following Logic Is For Remark Reject And Go To Rejected Order State
    @api.multi
    def reject(self,values):
        active_id = values['active_id']
        preventive_order_object=self.env['preventive.order'].search([('id','=',active_id)])
        if preventive_order_object:
            reject_vals = {
                'remark':self.remark,
                'status':'Reject',
                'user_id':values['uid'],
                'order_id':active_id,
                'remark_date':self.remark_date
            }
            preventive_order_object.write({'order_status':'rejected'})
            preventive_remark=self.env['preventive.order.remark']
            preventive_remark.create(reject_vals)
            remarkdata = preventive_remark.search([('user_id','=',False),('safety_clearance','=',False),('production_clearance','=',False),('electrical_clearance','=',False),('boolean_flag','=',True)])
            remarkdata.unlink()

    # Added By '' Following Logic Is For Unassign User With Remark 
    @api.multi
    def unassign_user(self,values):
        active_id = values['active_id']
        preventive_order_object=self.env['preventive.order'].search([('id','=',active_id)])
        if preventive_order_object:
            unassign_user_vals = {
                'remark':self.remark,
                'status':'Unassign',
                'user_id':values['uid'],
                'order_id':active_id,
                'remark_date':self.remark_date
            }
            preventive_order_object.write({'order_status':'unassign'})
            preventive_order_object.write({'technician_id':False})
            preventive_remark=self.env['preventive.order.remark']
            preventive_remark.create(unassign_user_vals)
            remarkdata = preventive_remark.search([('user_id','=',False),('safety_clearance','=',False),('production_clearance','=',False),('electrical_clearance','=',False),('boolean_flag','=',True)])
            remarkdata.unlink()
