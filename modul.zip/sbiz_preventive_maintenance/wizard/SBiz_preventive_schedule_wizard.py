from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError,Warning
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT
from odoo import http
from odoo.osv.orm import except_orm
import logging
_logger = logging.getLogger(__name__)

maintenance_calendar_start = ''
maintenance_calendar_end   = ''

class PreventiveScheduleTransient(models.TransientModel):
    _name = 'preventive.schedule.transient'
    _description = 'Preventive Schedule Wizard'

    name = fields.Char('Remark')


    @api.multi
    def set_to_draft(self, values):
        active_ids = values['active_ids']
        record_set = self.env['preventive.schedule'].search([('id', 'in', active_ids), ('state', '=', 'reject')])
        record_num = len(record_set)
        for rec in record_set:
            rec.write({'state':'draft',
                       'rejected_remark':False})
        self.env.cr.commit()
        return {'type': 'ir.actions.act_window_close'}




    @api.multi
    def create_preventive_order(self,values):
        active_ids = values['active_ids']
        preventive_schedule_object = self.env['preventive.schedule'].search([('bu_approval','=','approve'),('qa_approval','=','approve'),('supervisor_approval','=','approve'),('id', 'in', active_ids)])
        if not preventive_schedule_object:
            raise UserError(_('You selected some records without QA,BU and SU Approval. Please set all the records with appropriate values for QA,BU and SU Approval and try again ...'))
        MAINTENANCE_CALENDAR_START = self.env['ir.config_parameter'].sudo().get_param("maintenance.maintenance_calendar_start")
        MAINTENANCE_CALENDAR_END   = self.env['ir.config_parameter'].sudo().get_param("maintenance.maintenance_calendar_end")
        for id in active_ids:
            schedule = self.env['preventive.schedule'].browse(id)
            preventive_order_object=self.env['preventive.order'].search([('equipment_id','=',schedule.equipment_id.id), ('due_date','=',schedule.due_date)])
            if preventive_order_object:
                continue
            if not preventive_order_object:
                order_no = self.env['ir.sequence'].next_by_code('preventive.order') # or 'New'
                preventive_order = {
                    'order_no'               : order_no,
                    'order_date'             : date.today(),
                    'order_description'      : '',
                    'equipment_id'           : schedule.equipment_id.id,
                    'location_id'            : schedule.equipment_id.location_id.id,
                    'area'                   : '',
                    'tag_id'                 : schedule.equipment_id.tag_id,
                    'due_date'               : schedule.due_date,
                    'from_date'              : schedule.from_date,
                    'to_date'                : schedule.to_date,
                    'final_date'             : schedule.final_date,
                    'planner_id'             : schedule.equipment_id.planner_ids[0].id,
                    'technician_id'          : schedule.technician_id.id,
                    'business_id'            : schedule.business_user_id.id,
                    'qa_id'                  : schedule.qa_user_id.id,
                    'supervisor_id'          : schedule.supervisor_id.id,
                    'order_type'             : 'auto',
                    'company_id'             : schedule.equipment_id.company_id.id
                }
                oid = self.env['preventive.order'].create(preventive_order)
                if oid:
                    schedule.write({'state': 'order_ok'})
                    if schedule.equipment_id.checklist_lines:                         
                        for line in schedule.equipment_id.checklist_lines:  
                            print(oid.order_no)
                            order_line_no = self.env['ir.sequence'].next_by_code('preventive.order.line')
                            add_lines = {
                                        'preventive_order_id': oid.id,
                                        'operation_no':order_line_no.replace('X',oid.order_no),
                                        'action_no':line.action_no,
                                        'action_name':line.action_name,
                                        'technician_id':oid.technician_id.id if oid.technician_id else False                                                                         
                                    }
                            newid = self.env['preventive.order.line']
                            newid.create(add_lines)
                create_order_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_create_order')
                create_order_template.send_mail(oid.id,create_order_template.id)
        self.env.cr.commit()
        raise UserError(_("Order has been Successfully Created"))


    @api.multi
    def request_schedule_approvals(self, values):
        
        active_ids = values['active_ids']
        context = self.env.context
        mail_obj = self.env['mail.mail']
        planner  = self.env.uid
        mail_fr2 = self.env['res.users'].browse(planner)
        mail_frm = mail_fr2.login
        mail_svu = self.env['preventive.schedule'].read_group(domain=[('id', 'in', active_ids), ('supervisor_approval', '=', 'draft')], fields=['supervisor_id'], groupby=['supervisor_id'])
        mail_buu = self.env['preventive.schedule'].read_group(domain=[('id', 'in', active_ids), ('supervisor_approval', '=', 'draft'),('bu_approval', '=', 'draft')], fields=['business_user_id'], groupby=['business_user_id'])
        mail_qau = self.env['preventive.schedule'].read_group(domain=[('id', 'in', active_ids), ('bu_approval', '=', 'draft'), ('qa_approval', '=', 'draft')], fields=['qa_user_id'], groupby=['qa_user_id'])
        mail_sub = " Preventive Schedule Approval Request"
        baseurl  = self.env['preventive.schedule']
        if active_ids:
            calibration_ids=self.env['preventive.schedule'].search([('id','in',active_ids)])
            for i in calibration_ids:
                if not i.supervisor_approval == 'draft':
                    raise UserError('Few of the selected records are not in Draft mode')
                if not i.bu_approval == 'draft':
                    raise UserError('Few of the selected records are not in Draft mode')
                if not i.qa_approval == 'draft':
                    raise UserError('Few of the selected records are not in Draft mode')
                if not i.state == 'draft':
                    raise UserError('Few of the selected records are not in Draft mode')
                if i:
                    i.supervisor_approval = 'requested'
                    i.state = 'in_approval'
                if not i.business_user_id:
                    raise UserError('Please Ensure Business User And Other Users Are Assigned')
                if not i.qa_user_id:
                    raise UserError('Please Select QA User')
        for supervisor_user in mail_svu:
            mail_to = self.env['res.users'].browse(supervisor_user['supervisor_id'][0]).login
            body_html = """<p>Dear User,<br/>
                The preventive schedule has been sent for you review and approval.<br/>
         
                Please access the schedule at 
                <div style="text-align: center; margin: 16px 0px 16px -1046px; font-size: 14px;">
                        <a href="""+str(baseurl.get_base_url()) +"""/web?&amp;action=679&amp;model=preventive.schedule&amp;view_type=list&amp;menu_id=497" target="_blank" style="text-decoration:none;background-color: #875A7B; padding: 8px 16px 8px 16px; text-decoration: none; color: #fff; border-radius: 5px; font-size:13px;">
                            View Requested Schedule
                        </a>
                </div>
                <br/><br/>

                Regards!<br/>
                It is a system generated message,please do not reply.</p>
                """.format(http.request.httprequest)
            mail_rec = {
                    'email_from': mail_frm,
                    'email_to'  : mail_to,
                    'body_html' : body_html,
                    'subject'   : mail_sub,
                }
            mail = mail_obj.create(mail_rec)
            mail.send()
            
        for business_user in mail_buu:
            mail_to = self.env['res.users'].browse(business_user['business_user_id'][0]).login
            body_html = """<p>Dear User,<br/>
                The preventive schedule has been sent for you review and approval.<br/>
         
                Please access the schedule at 
                <div style="text-align: center; margin: 16px 0px 16px -1046px; font-size: 14px;">
                        <a href="""+str(baseurl.get_base_url()) +"""/web?&amp;action=679&amp;model=preventive.schedule&amp;view_type=list&amp;menu_id=497" target="_blank" style="text-decoration:none;background-color: #875A7B; padding: 8px 16px 8px 16px; text-decoration: none; color: #fff; border-radius: 5px; font-size:13px;">
                            View Requested Schedule
                        </a>
                </div>
                <br/><br/>

                Regards!<br/>
                It is a system generated message,please do not reply.</p>
                """.format(http.request.httprequest)
            mail_rec = {
                    'email_from': mail_frm,
                    'email_to'  : mail_to,
                    'body_html' : body_html,
                    'subject'   : mail_sub,
                }
            mail = mail_obj.create(mail_rec)
            mail.send()
            
        for qa_user in mail_qau:
            mail_to_qa = self.env['res.users'].browse(qa_user['qa_user_id'][0]).login
            body_html = """<p>Dear User,<br/>
                The preventive schedule has been sent for you review and approval.<br/>
         
                Please access the schedule at
                <div style="text-align: center; margin: 16px 0px 16px -1046px; font-size: 14px;">
                        <a href="""+ str(baseurl.get_base_url()) +"""/web?&amp;action=690&amp;model=preventive.schedule&amp;view_type=list&amp;menu_id=497" target="_blank" style="text-decoration:none;background-color: #875A7B; padding: 8px 16px 8px 16px; text-decoration: none; color: #fff; border-radius: 5px; font-size:13px;">
                            View Requested Schedule
                        </a>
                </div> 
                <br/>

                Regards!<br/>
                It is a system generated message,please do not reply.</p>
                """.format(http.request.httprequest)
            
            
            mail_rec_qa = {
                'email_from': mail_frm,
                'email_to'  : mail_to_qa,
                'body_html' : body_html,
                'subject'   : mail_sub,
            }

            mail = mail_obj.create(mail_rec)
            mail_qa = mail_obj.create(mail_rec_qa)
            mail.send()
            mail_qa.send()

        
        return {'type': 'ir.actions.act_window_close'}      
        

    @api.multi
    def request_approvals_for_supervisor_user(self,values):
        active_ids = values['active_ids']
        for activeid in active_ids:
            preventive_schedule_object=self.env['preventive.schedule'].search([('id','=',activeid)])
            for supervisorapproval in preventive_schedule_object:
                if supervisorapproval.supervisor_approval == 'requested':
                    supervisorapproval.write({'supervisor_approval':'approve',
                                            'state':'su_approved',
                                       'rejected_remark':self.name})
                    approve_mail_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_approve_su')
                    approve_mail_template.send_mail(supervisorapproval.id,approve_mail_template.id)
    
    @api.multi
    def request_approvals_for_business_user(self,values):
        active_ids = values['active_ids']
        for activeid in active_ids:
            preventive_schedule_object=self.env['preventive.schedule'].search([('id','=',activeid)])
            for buapprovals in preventive_schedule_object:
                if buapprovals.state == 'su_approved':
                    buapprovals.write({'bu_approval':'approve',
                                       'state':'bu_approved',
                                       'rejected_remark':self.name})
                    approve_mail_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_approve_bu')
                    approve_mail_template.send_mail(buapprovals.id,approve_mail_template.id) 
                   



    @api.multi
    def request_approvals_for_qa_user(self,values):
        active_ids = values['active_ids']
        for activeid in active_ids:
            preventive_schedule_object=self.env['preventive.schedule'].search([('id','=',activeid)])
            for qaapprovals in preventive_schedule_object:
                if qaapprovals.state == 'bu_approved':
                    qaapprovals.write({'qa_approval':'approve',
                                       'state':'qa_approved',
                                        'rejected_remark':self.name})
                    approve_mail_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_approve_qa')
                    approve_mail_template.send_mail(qaapprovals.id,approve_mail_template.id)
                else:
                    raise UserError(_("These Schedule is Already Approved."))

    @api.multi
    def approvals_rejection_for_bu_and_qa(self,values):
        active_ids = values['active_ids']
        for activeid in active_ids:
            preventive_schedule_object=self.env['preventive.schedule'].search([('id','=',activeid)])
            for rejection in preventive_schedule_object:
                if rejection.state == 'draft' and rejection.bu_approval == 'draft' and rejection.supervisor_approval == 'draft' and rejection.qa_approval == 'draft':
                    raise UserError(_("Please check selected schedule is in draft would not recject")) 
                else:
                    res_user_obj = self.env['res.users'].search([('id','=',self.env.uid)])
                    if res_user_obj.user_role =='business':
                        if rejection.bu_approval == 'approve':
                            raise UserError(_("Cannot Reject. It is already approved."))
                    if rejection.state == 'reject':
                        raise UserError(_("You are all ready rejected please check"))
                    if rejection.supervisor_approval == 'requested':
                        if not self.name:
                            raise UserError(_("Please Enter Rejection Remark"))
                        rejection.write({'rejected_remark':self.name,
                                         'supervisor_approval':'draft',
                                         'bu_approval':'draft',
                                         'qa_approval':'draft',
                                         'state':'reject'})
                        reject_mail_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_reject_su')
                        reject_mail_template.send_mail(rejection.id,reject_mail_template.id)
                    elif rejection.bu_approval == 'draft':
                        if not self.name:
                            raise UserError(_("Please Enter Rejection Remark"))
                        rejection.write({'rejected_remark':self.name,
                                         'supervisor_approval':'draft',
                                         'bu_approval':'draft',
                                         'qa_approval':'draft',
                                         'state':'reject'})
                        reject_mail_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_reject_bu')
                        reject_mail_template.send_mail(rejection.id,reject_mail_template.id)
                    else:
                        if rejection.state == 'bu_approved':
                            if not self.name:
                                raise UserError(_("Please Enter Rejection Remark"))
                            rejection.write({'rejected_remark':self.name,
                                             'supervisor_approval':'draft',
                                             'bu_approval':'draft',
                                             'qa_approval':'draft',
                                             'state':'reject'})
                            reject_mail_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_reject_qa')
                            reject_mail_template.send_mail(rejection.id,reject_mail_template.id)
