# -*- coding: utf-8 -*-
{
    'name': "sbiz_breakdown_maintenance_request",

    'summary': """
        Breakdown Maintenance Service""",

    'description': """
        Breakdown Maintenance Service
    """,

    'author': "SynerBize, Inc. (hello@synerbize.com)",
    'website': "http://www.synerbize.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/12.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'BDMS',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'maintenance','hr_maintenance', 'mail','portal','stock'],

    # always loaded
    'data': [
        'wizard/SBiz_bdms_request_remark_wizard_view.xml',
        'views/SBiz_maintenance_location_view.xml',
        'views/SBiz_res_users_view.xml',
        'views/sbiz_config_settings.xml',
        'views/SBiz_cmms_equipment_view.xml',
        'security/preventive_security_group.xml',
        'wizard/SBiz_bdms_order_remark_wizard_view.xml',
        'views/SBiz_bdms_order_view.xml',
        # 'views/SBiz_bdms_request_order_view.xml',
        # 'wizard/SBiz_preventive_wizard_view.xml',
        'views/SBiz_bdms_maintenance_request_view.xml',
        'views/SBiz_preventive_menu.xml',
        'wizard/SBiz_bdms_order_creation_wizard_view.xml',
        
        'views/SBiz_email_templates.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}