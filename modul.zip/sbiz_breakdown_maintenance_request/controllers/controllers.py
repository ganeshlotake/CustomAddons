# -*- coding: utf-8 -*-
from odoo import http

# class SbizPreventiveMaintenanceModel(http.Controller):
#     @http.route('/sbiz_preventive_maintenance_model/sbiz_preventive_maintenance_model/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/sbiz_preventive_maintenance_model/sbiz_preventive_maintenance_model/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('sbiz_preventive_maintenance_model.listing', {
#             'root': '/sbiz_preventive_maintenance_model/sbiz_preventive_maintenance_model',
#             'objects': http.request.env['sbiz_preventive_maintenance_model.sbiz_preventive_maintenance_model'].search([]),
#         })

#     @http.route('/sbiz_preventive_maintenance_model/sbiz_preventive_maintenance_model/objects/<model("sbiz_preventive_maintenance_model.sbiz_preventive_maintenance_model"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('sbiz_preventive_maintenance_model.object', {
#             'object': obj
#         })