from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT


# create_by | create_date | update_by | update_date
#           |  27/07/2020 |           | 
    

class bdmsOrderRemark(models.Model):
    _name        = 'bdms.request.remark'
    _description = 'BDMS Request Remarks'
    _inherit = ["mail.thread"]


            
    remark               = fields.Text(string='Remark')    
    status               = fields.Char(string='Action (Reject or Approve)',track_visibility='onchange')
    user_id              = fields.Many2one(comodel_name='res.users')
    request_id           = fields.Many2one(comodel_name='bdms.maintenance_request')
    order_status         = fields.Selection(related='request_id.state',string="Order Status", store=True)    
    safety_clearance     = fields.Boolean(string="Safety Clearance taken",related='request_id.safety_clearance',store=True,readonly=False)
    production_clearance = fields.Boolean(string="Business Head Clearance Taken",related='request_id.production_clearance',store=True,readonly=False)
    electrical_clearance = fields.Boolean(string="Supervisor Clearance Taken",related='request_id.electrical_clearance',store=True,readonly=False) 
    technician_id        = fields.Many2one(comodel_name='res.users', string='Technician', domain="[('user_role','=',2)]")  
    remark_date          = fields.Datetime(string='Remark Date', default=datetime.now()) 
    clearance_date       = fields.Datetime(string='Clearance Date', default=datetime.now(),readonly=True)
#    can_be_used          = fields.Boolean(string='Can Be Used',related="request_id.can_be_used",store=True,readonly=False)

    # Following Logic Is For Remark Approve And Go To Next State Of Order
    @api.multi
    def approve(self,values):
        active_id = values['active_id']
        bdms_request_object=self.env['bdms.maintenance_request'].search([('id','=',active_id)])
        if bdms_request_object:            
            template_assigned     = self.env['ir.model.data'].get_object('sbiz_breakdown_maintenance_request', 'to_send_mail_for_assigned_request')
            template_Superpreapproval  = self.env['ir.model.data'].get_object('sbiz_breakdown_maintenance_request', 'to_send_mail_for_superpreapproval_request') 
            template_BHeadpreapproval  = self.env['ir.model.data'].get_object('sbiz_breakdown_maintenance_request', 'to_send_mail_for_BHeadpreapproval_request') 
            template_Qapreapproval     = self.env['ir.model.data'].get_object('sbiz_breakdown_maintenance_request', 'to_send_mail_for_Qapreapproval_request') 
            template_SOpreapproval     = self.env['ir.model.data'].get_object('sbiz_breakdown_maintenance_request', 'to_send_mail_for_SOpreapproval_request') 
            template_Superpostapproval = self.env['ir.model.data'].get_object('sbiz_breakdown_maintenance_request', 'to_send_mail_for_superpostapproval_request')
            template_BHeadpostapproval = self.env['ir.model.data'].get_object('sbiz_breakdown_maintenance_request', 'to_send_mail_for_BHeadpostapproval_request')
            template_Qapostapproval = self.env['ir.model.data'].get_object('sbiz_breakdown_maintenance_request', 'to_send_mail_for_Qapostapproval_request')
            template_SOpostapproval = self.env['ir.model.data'].get_object('sbiz_breakdown_maintenance_request', 'to_send_mail_for_SOpostapproval_request')

            template_closed       = self.env['ir.model.data'].get_object('sbiz_breakdown_maintenance_request','to_send_mail_for_closed_request')
            # template_complete     = self.env['ir.model.data'].get_object('sbiz_breakdown_maintenance_request','to_send_mail_for_complete_request')
            
            if bdms_request_object.state == 'create':
                if not self.technician_id :
                    raise UserError(_("Please Assign Technician"))
                bdms_request_object.write({'state':'assign'})
                bdms_request_object.technician_ids = self.technician_id  
                template_assigned.send_mail(bdms_request_object.id, template_assigned.id)
            elif bdms_request_object.state == 'assign':
                bdms_request_object.write({'state':'start'})
                template_Superpreapproval.send_mail(bdms_request_object.id, template_Superpreapproval.id)
            elif bdms_request_object.state == 'start':
                self.electrical_clearance = True
                if  not self.electrical_clearance:
                    raise UserError(_("Please check Supervisor Clearance"))       
                bdms_request_object.write({'state':'pre_supervisorapprove'})
                template_BHeadpreapproval.send_mail(bdms_request_object.id, template_BHeadpreapproval.id)
            elif bdms_request_object.state == 'pre_supervisorapprove':
                self.production_clearance = True
                if  not self.production_clearance:
                    raise UserError(_("Please check Business Clearance"))
                bdms_request_object.write({'state':'pre_buheadapproved','electrical_clearance':self.electrical_clearance})
                template_Qapreapproval.send_mail(bdms_request_object.id, template_Qapreapproval.id)
            elif bdms_request_object.state == 'pre_buheadapproved': 
                bdms_request_object.write({'state':'pre_qaapproved','production_clearance':self.production_clearance})
                template_SOpreapproval.send_mail(bdms_request_object.id, template_SOpreapproval.id)
            elif bdms_request_object.state == 'pre_qaapproved': 
                self.safety_clearance = True
                if not self.safety_clearance:
                    raise UserError(_("Please check Safety Clearance"))   
                bdms_request_object.write({'state':'in_process','safety_clearance':self.safety_clearance}) 
                #template_complete.send_mail(bdms_request_object.id, template_complete.id)               
            elif bdms_request_object.state == 'in_process':  
                if not bdms_request_object.maintenance_request_line_ids:
                    raise UserError(_("Please enter Technician remark")) 
                bdms_request_object.write({'state':'complete'})
                template_Superpostapproval.send_mail(bdms_request_object.id, template_Superpostapproval.id)
            elif bdms_request_object.state == 'complete':                         
                bdms_request_object.write({'state':'post_supervisorapprove'})
                template_BHeadpostapproval.send_mail(bdms_request_object.id, template_BHeadpostapproval.id)
            elif bdms_request_object.state == 'post_supervisorapprove':
                bdms_request_object.write({'state':'post_buheadapproved'})
                template_Qapostapproval.send_mail(bdms_request_object.id, template_Qapostapproval.id)
            elif bdms_request_object.state == 'post_buheadapproved':
                bdms_request_object.write({'state':'post_qaapproved'})
                template_SOpostapproval.send_mail(bdms_request_object.id, template_SOpostapproval.id)
            elif bdms_request_object.state == 'post_qaapproved':
                bdms_request_object.write({'state':'post_soapproved'})                
            elif bdms_request_object.state == 'post_soapproved': 
                bdms_request_object.write({'state':'closed'})
                breakdown_hist = {
                    'request_no':bdms_request_object.id,
                    'equipment_id':bdms_request_object.equipment_id.id,
                    'last_maintenance_date': datetime.now(),
                    'order_status': bdms_request_object.state,
                    'remark' : self.remark,
                    'planner_id': bdms_request_object.planner_id.id,
                    'bu_user_id': bdms_request_object.business_head_id.id,
                    'qauser_id': bdms_request_object.qa_id.id,
                    'supervisor_id': bdms_request_object.supervisor_id.id,                   
                    'company_id' : bdms_request_object.company_id.id,
                }
                breakdown_hist_obj = self.env['cmms.equipment.history.bdms.request']
                hid = breakdown_hist_obj.create(breakdown_hist) 
                if bdms_request_object.attachment_ids:
                    hid.attachment_ids = bdms_request_object.attachment_ids                    
                template_closed.send_mail(bdms_request_object.id, template_closed.id)
            elif bdms_request_object.state == 'unassign':
                bdms_request_object.write({'state':'assign'})
                bdms_request_object.technician_ids = self.technician_id                

            print(self)
            reject_vals = {
                'remark':self.remark,
                'status':'Approve',
                'user_id':self.env.uid,
                'request_id':active_id,
                'remark_date':self.remark_date
            }
            bdms_request_remark=self.env['bdms.request.remark']
            self.write(reject_vals)
            remarkdata = bdms_request_remark.search([('user_id','=',False),('safety_clearance','=',False),('production_clearance','=',False),('electrical_clearance','=',False)])
            remarkdata.unlink()

    @api.model
    def create(self,values):        
        res = super(bdmsOrderRemark,self).create(values)
        return res

    
    @api.multi
    def rework(self,values):
        active_id = values['active_id']
        breakdown_request_object=self.env['bdms.maintenance_request'].search([('id','=',active_id)])
        if breakdown_request_object:
            if breakdown_request_object.order_status == 'post_soapproved':
                breakdown_request_object.write({'order_status':'post_qaapproved'})
            elif breakdown_request_object.order_status == 'post_qaapproved':
                breakdown_request_object.write({'order_status':'post_buheadapproved'})
            elif breakdown_request_object.order_status == 'post_buheadapproved':
                breakdown_request_object.write({'order_status':'post_supervisorapprove'})
            elif breakdown_request_object.order_status == 'post_supervisorapprove':
                breakdown_request_object.write({'order_status':'complete'})
            elif breakdown_request_object.order_status == 'complete':
                breakdown_request_object.write({'order_status':'in_process'})
            elif breakdown_request_object.order_status == 'in_process':
                breakdown_request_object.write({'order_status':'pre_qaapproved'})
            elif breakdown_request_object.order_status == 'pre_qaapproved':
                breakdown_request_object.write({'order_status':'pre_buheadapproved'})
            elif breakdown_request_object.order_status == 'pre_buheadapproved':
                breakdown_request_object.write({'order_status':'pre_supervisorapprove'})
            elif breakdown_request_object.order_status == 'pre_supervisorapprove':
                breakdown_request_object.write({'order_status':'release'})
            elif breakdown_request_object.order_status == 'release':
                breakdown_request_object.write({'order_status':'start'})
            elif breakdown_request_object.order_status == 'start':
                breakdown_request_object.write({'order_status':'assign'})
            elif breakdown_request_object.order_status == 'assign':
                breakdown_request_object.write({'order_status':'active'})  
            elif breakdown_request_object.order_status == 'active':
                breakdown_request_object.write({'order_status':'create'})                     
            reject_vals = {
                'remark':self.remark,
                'status':'Rework',
                'user_id':values['uid'],
                'request_id':active_id,
                'remark_date':self.remark_date
            }
            bdms_request_remark=self.env['bdms.request.remark']
            self.write(reject_vals)
            remarkdata = bdms_request_remark.search([('user_id','=',False),('safety_clearance','=',False),('production_clearance','=',False),('electrical_clearance','=',False)])
            remarkdata.unlink()


    @api.multi
    @api.returns('mail.message', lambda value: value.id)
    def message_post(self, **kwargs):
        thread_id = self.id       
        return super(bdmsOrderRemark, self.browse(thread_id)).message_post(**kwargs)


    # Following Logic Is For Remark Reject And Go To Rejected Order State
    @api.multi
    def reject(self,values):
        active_id = values['active_id']
        if not self.remark:
            raise UserError(_("Please Enter Remark"))
        breakdown_request_object=self.env['bdms.maintenance_request'].search([('id','=',active_id)])
        if breakdown_request_object:
            reject_vals = {
                'remark':self.remark,
                'status':'Reject',
                'user_id':values['uid'],
                'request_id':active_id,
                'remark_date':self.remark_date
            }
            breakdown_request_object.write({'state':'in_process'})
            bdms_request_remark=self.env['bdms.request.remark']
            self.write(reject_vals)
            self.message_post(body=_('Statement confirmed, journal items were created.'))
            remarkdata = bdms_request_remark.search([('user_id','=',False),('safety_clearance','=',False),('production_clearance','=',False),('electrical_clearance','=',False)])
            remarkdata.unlink()

    # Added By '' Following Logic Is For Unassign User With Remark 
    @api.multi
    def unassign_user(self,values):
        active_id = values['active_id']
        breakdown_request_object=self.env['bdms.maintenance_request'].search([('id','=',active_id)])
        if breakdown_request_object:
            unassign_user_vals = {
                'remark':self.remark,
                'status':'Unassign',
                'user_id':values['uid'],
                'order_id':active_id,
                'remark_date':self.remark_date
            }
            breakdown_request_object.write({'state':'unassign'})
            breakdown_request_object.technician_ids = False
            bdms_request_remark=self.env['bdms.request.remark']
            self.write(unassign_user_vals)
            remarkdata = bdms_request_remark.search([('user_id','=',False),('safety_clearance','=',False),('production_clearance','=',False),('electrical_clearance','=',False)])
            remarkdata.unlink()

