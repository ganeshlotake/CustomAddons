# -*- coding: utf-8 -*-

from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT

import logging
_logger = logging.getLogger(__name__)

maintenance_calendar_start = ''
maintenance_calendar_end   = ''

class PreventiveEquipmentTransient(models.TransientModel):
    _name        = 'preventive.equipment.transient'
    _description = 'Preventive Equipment Transient'

    @api.model
    def _get_start_date(self):
        maintenance_calendar_start = self.env['ir.config_parameter'].sudo().get_param('maintenance.maintenance_calendar_start')
        maintenance_calendar_start += ' 00:00:00'
        return datetime.strptime(maintenance_calendar_start,'%Y-%m-%d %H:%M:%S').date()

    @api.model
    def _get_end_date(self):
        maintenance_calendar_end   = self.env['ir.config_parameter'].sudo().get_param('maintenance.maintenance_calendar_end')
        maintenance_calendar_end  += ' 00:00:00'
        return datetime.strptime(maintenance_calendar_end,'%Y-%m-%d %H:%M:%S').date()

    start_date = fields.Date(string="Start Date", default=lambda self: self._get_start_date())
    end_date   = fields.Date(string="End Date", default=lambda self: self._get_end_date())

    @api.multi
    def generate_schedule(self, values):
        active_ids = values['active_ids']
        date_missing = self.env['cmms.equipment'].search([('last_maintenance_date', '=', False), ('id', 'in', active_ids)])
        if date_missing or len(date_missing) > 0:
            raise UserError(_('You selected some records without Last Maintenance Date set. Please set all the records with appropriate values for Last Maintenance Date and try again ...'))

        for id in active_ids:
            instrument = self.env['cmms.equipment'].browse(id)
            if instrument.state == 'scheduled' or instrument.schedule_ids:
                continue

            frequency = instrument.frequency
            freq_type = instrument.frequency_type
            last_date = instrument.last_maintenance_date
            if freq_type == 'months':
                due_date = last_date + relativedelta(months=frequency)
            else:
                due_date = last_date + relativedelta(days=frequency)

            maintenance_calendar_start = self.start_date
            maintenance_calendar_end   = self.end_date

            while due_date < maintenance_calendar_start:

                if freq_type == 'months':
                    due_date = last_date + relativedelta(months=frequency)
                else:
                    due_date = last_date + relativedelta(days=frequency)

                last_date = due_date

            schedule_ids = []

            while (due_date >= maintenance_calendar_start and due_date <= maintenance_calendar_end):
                date1 = due_date + relativedelta(days=instrument.negative_tolerance)
                date2 = due_date + relativedelta(days=instrument.positive_tolerance)
                schedule = {
                    'equipment_id'          : instrument.id,
                    'last_maintenance_date' : last_date,
                    'planner_id'            : instrument.planner_ids[0].id if instrument.planner_ids else None,
                    'business_user_id'      : instrument.business_user_ids[0].id if instrument.business_user_ids else None,
                    'qa_user_id'            : instrument.qa_user_ids[0].id if instrument.qa_user_ids else None,
                    'technician_id'         : instrument.technician_ids[0].id if instrument.technician_ids else None,
                    'supervisor_id'         : instrument.supervisor_ids[0].id if instrument.supervisor_ids else None,
                    'due_date'              : due_date,
                    'final_date'            : due_date,
                    'bu_approval'           : False,
                    'qa_approval'           : False,
                    'from_date'             : date1,
                    'to_date'               : date2,
                    'state'                 : 'draft',
                    'bu_approval'           : 'draft',
                    'supervisor_approval'   : 'draft',
                    'qa_approval'           : 'draft',
                }
                newid = self.env['preventive.schedule'].create(schedule)
                schedule_ids.append(newid.id)
                last_date = due_date
                if freq_type == 'months':
                    due_date = last_date + relativedelta(months=frequency)
                else:
                    due_date = last_date + relativedelta(days=frequency)

            instrument.schedule_ids = schedule_ids
            instrument.state = 'created'
            mail_obj = self.env['mail.mail']
            mail_sub = "Preventive Schedule Created"
            planner_li =[]
            bu_li =[]
            qa_li=[]
            su_li=[]
            if instrument.planner_ids:
                for planner in instrument.planner_ids:
                    planner_li.append(planner)
                for qa in instrument.qa_user_ids:
                    qa_li.append(qa)
                for bu in instrument.business_user_ids:
                    bu_li.append(bu)
                for su in instrument.supervisor_ids:
                    su_li.append(su)
                for j in planner_li:
                    body_html = """<p>Dear User,<br/>
                    The preventive schedule has been created by Engineering Planner """+j.login+""". This is for your information <br/>
                    
                    Please access the schedule at <br/> 
                    <div style="text-align: center; margin: 16px 0px 16px -1046px; font-size: 14px;">
                            <a href="""+str(instrument.get_base_url())+"""/web?&amp;action=673&amp;model=preventive.schedule&amp;view_type=list&amp;menu_id=497" target="_blank" style="text-decoration:none;background-color: #875A7B; padding: 8px 16px 8px 16px; text-decoration: none; color: #fff; border-radius: 5px; font-size:13px;">
                            View Generated Schedules
                            </a>
                    </div> for additional details.
                    <br/><br/>

                    Regards!<br/>
                    It is a system generated message,please do not reply.</p>
                    """
                    mail_rec = {
                        'email_from': instrument.company_id.email,
                        'email_cc'  : j.login,
                        'email_to'  : [bu.login for bu in bu_li],
                        'email_to'  : [qa.login for qa in qa_li],
                        'email_to'  : [su.login for su in su_li],
                        'body_html' : body_html,
                        'subject'   : mail_sub,
                    }
                    mail = mail_obj.create(mail_rec)
                    mail.send()
            # schedule_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_gen_sch')
            # schedule_template.send_mail(instrument.id,schedule_template.id) 
            self.env.cr.commit()
            raise UserError(_("Schedule has been Created"))
