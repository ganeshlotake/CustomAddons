# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import SBiz_preventive_equipment_wizard
from . import SBiz_bdms_order_creation_wizard
from . import SBiz_bdms_order_remark_wizard
from . import SBiz_bdms_request_remark_wizard

