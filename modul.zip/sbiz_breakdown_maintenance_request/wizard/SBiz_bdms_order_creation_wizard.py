from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError,Warning
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT
from odoo import http
from odoo.osv.orm import except_orm
import logging
_logger = logging.getLogger(__name__)

maintenance_calendar_start = ''
maintenance_calendar_end   = ''

class BDMSRequestTransient(models.TransientModel):
    _name = 'bdms.request.transient'
    _description = 'Breakdown Request Wizard'

    name = fields.Char('Remark')


    @api.multi
    def set_to_draft(self, values):
        active_ids = values['active_ids']
        record_set = self.env['preventive.schedule'].search([('id', 'in', active_ids), ('state', '=', 'reject')])
        record_num = len(record_set)
        for rec in record_set:
            rec.write({'state':'draft',
                       'rejected_remark':False})
        self.env.cr.commit()
        return {'type': 'ir.actions.act_window_close'}




    @api.multi
    def create_bdms_order(self,values):
        active_ids = values['active_ids']
        breakdown_request_object=self.env['bdms.maintenance_request'].read_group([('id','in',active_ids),('state','=','create'),('order_created','=','notcreated')], 'equipment_id', 'equipment_id',lazy=False)
        for l in breakdown_request_object:
            print(l['__domain'][1][2])
            line_obj = self.env['bdms.maintenance_request'].search([('id','in',active_ids),('state','=','create'),('order_created','=','notcreated'),('equipment_id','=',l['__domain'][1][2])])
            
            reuest_obj = self.env['cmms.equipment'].browse(l['__domain'][1][2])
            if breakdown_request_object:                
                request_order = {                   
                    'order_date'             : date.today(),
                    'order_description'      : '',
                    'equipment_id'           : reuest_obj.id,
                    'location_id'            : reuest_obj.location_id.id,
                    'area'                   : '',
                    'tag_id'                 : reuest_obj.tag_id,   
                    'planner_id'             : reuest_obj.planner_ids[0].id if reuest_obj.planner_ids else False,                                       
                    'qa_id'                  : reuest_obj.qa_user_ids[0].id if reuest_obj.qa_user_ids else False,
                    'supervisor_id'          : reuest_obj.supervisor_ids[0].id if reuest_obj.supervisor_ids else False,                   
                    'order_type'             : 'auto',
                    'company_id'             : reuest_obj.company_id.id
                }
                oid = self.env['bdms.order'].create(request_order)
                if oid:          
                    oid.technician_ids = reuest_obj.technician_ids[0] if reuest_obj.technician_ids else False
                    if line_obj:                         
                        for line in line_obj:  
                            line.write({'order_created':'created','order_number':oid.order_no})    
                            order_line_no = self.env['ir.sequence'].next_by_code('bdms.order.line')
                            seq = order_line_no.replace('X',oid.order_no)
                            seq1 = seq[:-5] 
                            add_lines = {
                                        'bdms_order_id': oid.id,
                                        'operation_no': seq1 + line.request_no,                                        
                                        'operation_name':line.name,
                                        'technician_id': line.technician_ids[0].id if line.technician_ids else False                                                                         
                                    }
                            newid = self.env['bdms.order.line']
                            newid.create(add_lines)
                # create_order_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_create_order')
                # create_order_template.send_mail(oid.id,create_order_template.id)
        self.env.cr.commit()
        raise UserError(_("Order has been Successfully Created"))


    @api.multi
    def assign_to_technician(self, values):        
        active_ids = values['active_ids']        
        mail_obj = self.env['mail.mail']
        planner  = self.env.uid
        mail_fr2 = self.env['res.users'].browse(planner)
        mail_frm = mail_fr2.login        
        
        mail_sub = " Breakdown Maintenance Request"
        for id in active_ids:
            bdms_obj  = self.env['bdms.maintenance_request'].search([('state','=','draft'),('id','=',id)])  
            if not bdms_obj:
                raise UserError(_('You selected some records without state Draft. Please set all the records with appropriate state values in draft and try again ...'))                       

            for tech in bdms_obj.technician_ids:
                bdms_obj.state='assigntotechnician'
                mail_to_tech = self.env['res.users'].browse(tech.id).login
                body_html = """<p>Dear User,<br/>
                    The preventive schedule has been sent for you review and approval.<br/>
            
                    Please access the schedule at
                    <div style="text-align: center; margin: 16px 0px 16px -1046px; font-size: 14px;">
                            <a href="""+ str(bdms_obj.get_base_url()) +"""/web?&amp;action=690&amp;model=preventive.schedule&amp;view_type=list&amp;menu_id=497" target="_blank" style="text-decoration:none;background-color: #875A7B; padding: 8px 16px 8px 16px; text-decoration: none; color: #fff; border-radius: 5px; font-size:13px;">
                                View Requested Schedule
                            </a>
                    </div> 
                    <br/>

                    Regards!<br/>
                    It is a system generated message,please do not reply.</p>
                    """ . format(http.request.httprequest)            
                
                mail_rec_tech = {
                    'email_from': mail_frm,
                    'email_to'  : mail_to_tech,
                    'body_html' : body_html,
                    'subject'   : mail_sub,
                }

                mail_tech = mail_obj.create(mail_rec_tech)            
                mail_tech.send()

        
        return {'type': 'ir.actions.act_window_close'}      
        

    @api.multi
    def request_approvals_for_supervisor_user(self,values):
        active_ids = values['active_ids']
        for activeid in active_ids:
            preventive_schedule_object=self.env['preventive.schedule'].search([('id','=',activeid)])
            for supervisorapproval in preventive_schedule_object:
                if supervisorapproval.supervisor_approval == 'requested':
                    supervisorapproval.write({'supervisor_approval':'approve',
                                            'state':'su_approved',
                                       'rejected_remark':self.name})
                    approve_mail_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_approve_su')
                    approve_mail_template.send_mail(supervisorapproval.id,approve_mail_template.id)
    
    @api.multi
    def request_approvals_for_business_user(self,values):
        active_ids = values['active_ids']
        for activeid in active_ids:
            preventive_schedule_object=self.env['preventive.schedule'].search([('id','=',activeid)])
            for buapprovals in preventive_schedule_object:
                if buapprovals.state == 'su_approved':
                    buapprovals.write({'bu_approval':'approve',
                                       'state':'bu_approved',
                                       'rejected_remark':self.name})
                    approve_mail_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_approve_bu')
                    approve_mail_template.send_mail(buapprovals.id,approve_mail_template.id) 
                   



    @api.multi
    def request_approvals_for_qa_user(self,values):
        active_ids = values['active_ids']
        for activeid in active_ids:
            preventive_schedule_object=self.env['preventive.schedule'].search([('id','=',activeid)])
            for qaapprovals in preventive_schedule_object:
                if qaapprovals.state == 'bu_approved':
                    qaapprovals.write({'qa_approval':'approve',
                                       'state':'qa_approved',
                                        'rejected_remark':self.name})
                    approve_mail_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_approve_qa')
                    approve_mail_template.send_mail(qaapprovals.id,approve_mail_template.id)
                else:
                    raise UserError(_("These Schedule is Already Approved."))

    @api.multi
    def approvals_rejection_for_bu_and_qa(self,values):
        active_ids = values['active_ids']
        for activeid in active_ids:
            preventive_schedule_object=self.env['preventive.schedule'].search([('id','=',activeid)])
            for rejection in preventive_schedule_object:
                if rejection.state == 'draft' and rejection.bu_approval == 'draft' and rejection.supervisor_approval == 'draft' and rejection.qa_approval == 'draft':
                    raise UserError(_("Please check selected schedule is in draft would not recject")) 
                else:
                    res_user_obj = self.env['res.users'].search([('id','=',self.env.uid)])
                    if res_user_obj.user_role =='business':
                        if rejection.bu_approval == 'approve':
                            raise UserError(_("Cannot Reject. It is already approved."))
                    if rejection.state == 'reject':
                        raise UserError(_("You are all ready rejected please check"))
                    if rejection.supervisor_approval == 'requested':
                        if not self.name:
                            raise UserError(_("Please Enter Rejection Remark"))
                        rejection.write({'rejected_remark':self.name,
                                         'supervisor_approval':'draft',
                                         'bu_approval':'draft',
                                         'qa_approval':'draft',
                                         'state':'reject'})
                        reject_mail_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_reject_su')
                        reject_mail_template.send_mail(rejection.id,reject_mail_template.id)
                    elif rejection.bu_approval == 'draft':
                        if not self.name:
                            raise UserError(_("Please Enter Rejection Remark"))
                        rejection.write({'rejected_remark':self.name,
                                         'supervisor_approval':'draft',
                                         'bu_approval':'draft',
                                         'qa_approval':'draft',
                                         'state':'reject'})
                        reject_mail_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_reject_bu')
                        reject_mail_template.send_mail(rejection.id,reject_mail_template.id)
                    else:
                        if rejection.state == 'bu_approved':
                            if not self.name:
                                raise UserError(_("Please Enter Rejection Remark"))
                            rejection.write({'rejected_remark':self.name,
                                             'supervisor_approval':'draft',
                                             'bu_approval':'draft',
                                             'qa_approval':'draft',
                                             'state':'reject'})
                            reject_mail_template = self.env['ir.model.data'].get_object('sbiz_preventive_maintenance', 'to_send_mail_reject_qa')
                            reject_mail_template.send_mail(rejection.id,reject_mail_template.id)
