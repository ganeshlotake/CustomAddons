# -*- coding: utf-8 -*-

from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT

#Added by ajinkya joshi on 25-07-2020
class BreakdownRequestOrder(models.Model):
    _name           = 'bdms.maintenance_request.order'
    _description    = 'BDMS Maintenance Request Order'
    _order          = 'order_no'
    _rec_name       = 'order_no'
    _inherit        = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    
    order_no                        = fields.Char('Order No',required=True, readonly=True, index=True, copy=False, default=lambda self: _('New'))
    order_date                      = fields.Date('Order Date')
    order_description               = fields.Text('Order Description')
    equipment_id                    = fields.Many2one('cmms.equipment',string="Equipment")
    tag_id                          = fields.Char('Tag ID')
    location_id                     = fields.Many2one('maintenance.location',string="Location")
    area                            = fields.Char('Area')
    due_date                        = fields.Date('Due Date')
    from_date                       = fields.Date('From Date')
    to_date                         = fields.Date('To Date')
    final_date                      = fields.Date('Final Date')
    clearance_date                  = fields.Date('Clearance Date')
    actual_completion_date          = fields.Date('Actual Completion Date')
    bdms_line                       = fields.One2many('bdms.maintenance_request.line','bdms_order_id')
    supervisor_id                   = fields.Many2one('res.users',string="Supervisor", domain=[('user_role','=',5)], track_visibility='onchange')
    planner_id                      = fields.Many2one('res.users',string="Planner", domain=[('user_role','=',1)], track_visibility='onchange')
    technician_ids                  = fields.Many2many('res.users',string="Technician", domain=[('user_role','=',2)], track_visibility='onchange')
    business_id                     = fields.Many2one('res.users',string="Business", domain=[('user_role','=',3)], track_visibility='onchange')
    qa_id                           = fields.Many2one('res.users',string="QA", domain=[('user_role','=',4)], track_visibility='onchange')
    cqa_id                           = fields.Many2one('res.users',string="CQA", domain=[('user_role','=',6)], track_visibility='onchange')
    attachment_ids                  = fields.Many2many(comodel_name='ir.attachment')    
    material_consumed_ids           = fields.One2many('bdms.maintenance_request.material_consumed','bdms_order_id')
    env_condition                   = fields.Char('Environmental Condition')
    humidity                        = fields.Char('Humidity')
    other_remarks                   = fields.Char('Other Remarks')
    company_id                      = fields.Many2one('res.company',string="Company")
    bdms_frequency                  = fields.Integer(related='equipment_id.frequency',string="Frequency",store=True)
    bdms_frequency_type             = fields.Selection(related='equipment_id.frequency_type',string="Frequency Type",store=True)
    negative_tolerance              = fields.Float(related='equipment_id.negative_tolerance',string="Tolerance Range From",store=True)
    positive_tolerance              = fields.Float(related='equipment_id.positive_tolerance',store=True,string='Tolerance Range To')
    abc_indicator                   = fields.Selection(related='equipment_id.equipment_abc_indicator',store=True ,string='ABC Indicator')
    remark_id                       = fields.One2many(comodel_name='bdms.order.remark',inverse_name='order_id')
    can_be_used                     = fields.Boolean('Can Be Used')
    order_type                      = fields.Selection(string='Order Type', selection=[('manual', 'Manual'), ('auto', 'Auto-Generated')], store=True, default='manual')
    order_status                    = fields.Selection(string='Status',selection=[
                                        ('create', 'Create'),('active', 'Active'),('assign','Assign'),('start','Start'),
                                        ('release','Release'),('pre_approval','Pre-Approval-BU'),('in_process','In Process'),
                                        ('complete','Complete'),('post_approval_su','Post Approval-SU'),('post_approval_bu','Post Approval-BU'),('post_approval_qa','Post Approval-QA'),('closed','Closed'),('rejected','Rejected'),('unassign','Unassign'),('expired','Expired')],
                                        default='create', track_visibility='onchange')
    order_success                   = fields.Boolean(string='Checklist Success', default=True)
    ambient_temp                    = fields.Char('Ambient Temp')
    instrument_description          = fields.Text(string='Instrument Description')
    
    @api.multi
    def _get_default_userole_plan(self):
        res_obj = self.env['res.users'].search([('id','=',self.env.uid)])
        if res_obj:
            if res_obj.user_role.id == 2 or res_obj.user_role.id == 3 or res_obj.user_role.id == 4 :
                self.access_field_plan = False
            else:
                self.access_field_plan = True
    access_field_plan               = fields.Boolean(string="Access Field Plan",compute='_get_default_userole_plan')
    
    @api.multi
    def _get_default_userole(self):
        res_obj = self.env['res.users'].search([('id','=',self.env.uid)])
        if res_obj:
            if res_obj.user_role.id == 1 or res_obj.user_role.id == 3 or res_obj.user_role.id == 4 :
                self.access_field_tech = False
            else:
                self.access_field_tech = True
    access_field_tech               = fields.Boolean(string="Access Field Tech",compute='_get_default_userole')
    
    @api.model
    def create(self, vals):
        if vals.get('order_no', _('New')) == _('New'):
            vals['order_no'] = self.env['ir.sequence'].next_by_code('bdms.maintenance_request.order') or _('New')
        result = super(BreakdownRequestOrder, self).create(vals)
        return result
    
    
    @api.multi
    def get_status(self):
        my_status =''
        if self:
            if self.order_status == 'create':
                my_status = 'Create'
            elif self.order_status == 'active':
                my_status = 'Active'
            elif self.order_status == 'assign':
                my_status = 'Assign'
            elif self.order_status == 'start':
                my_status = 'Start'
            elif self.order_status == 'release':
                my_status = 'Release'
            elif self.order_status == 'pre_approval':
                my_status = 'Pre-Approval'
            elif self.order_status == 'in_process':
                my_status = 'In-Process'
            elif self.order_status == 'complete':
                my_status = 'Complete'
            elif self.order_status == 'post_approval':
                my_status = 'Post-Approval'
            elif self.order_status == 'closed':
                my_status = 'Closed'
            elif self.order_status == 'rejected':
                my_status = 'Rejected'
            elif self.order_status == 'unassign':
                my_status = 'Un-Assign'
        return my_status
    
    @api.multi
    def result_passfail(self):
        myflag = ''
        for line in self.bdms_line:
            if line.no == True:
                myflag = 'Fail'
                break
            else:
                myflag = 'Pass'
        return myflag
    
    @api.multi
    def copy(self):
        if self.env.uid > 2:
            raise ValidationError('You are not authorized to deplicate the records from Calibration Order. Please contact System Administrator.')
        
    @api.multi
    def unlink(self):
        if self.env.uid > 2:
            raise UserError(_('You are not authorized to delete the records from Calibration Orders. Please contact System Administrator.'))
        res = super(BreakdownRequestOrder, self).unlink()
        return res
    
    @api.constrains('bdms_line')
    def validate_passfail(self):
        myflag = True
        for line in self.bdms_line:
            if line.no == False:
                myflag = False
                break
        self.order_success = myflag
        return myflag
    
    @api.multi
    def get_base_url(self):
        base = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        return base

    @api.onchange('final_date')
    def validate_final_date(self):
        if self.final_date < self.from_date or self.final_date > self.to_date:
            raise UserError(_('The Final Date Must be between From and To dates'))
        
    @api.multi
    @api.onchange('equipment_id')
    def to_get_business_user_for_respective_selected_equipment(self):
        bu_user_list=[]                    
        domain={}
        if self.equipment_id:
            preventive_equipment_object = self.env['cmms.equipment'].search([('id','=',self.equipment_id.id)])
            for instrument in preventive_equipment_object:
                if instrument.business_user_ids:
                    for buid in instrument.business_user_ids:
                        if buid:
                            bu_user_list.append(buid.id)
                    domain['business_id']=[('id','in',bu_user_list)]
                    return {'domain':domain}
        
        
    @api.multi
    @api.onchange('equipment_id')
    def to_get_technician_for_respective_selected_equipment(self):
        technician_list=[]                    
        domain={}
        if self.equipment_id:
            preventive_equipment_object = self.env['cmms.equipment'].search([('id','=',self.equipment_id.id)])
            for instrument in preventive_equipment_object:
                if instrument.technician_ids:
                    for tid in instrument.technician_ids:
                        if tid:
                            technician_list.append(tid.id)
                    domain['technician_ids']=[('id','in',technician_list)]
                    return {'domain':domain}
                
    @api.multi
    @api.onchange('equipment_id')
    def to_get_planner_for_respective_selected_equipment(self):
        planner_list=[]                    
        domain={}
        if self.equipment_id:
            preventive_equipment_object = self.env['cmms.equipment'].search([('id','=',self.equipment_id.id)])
            for instrument in preventive_equipment_object:
                if instrument.planner_ids:
                    for pid in instrument.planner_ids:
                        if pid:
                            planner_list.append(pid.id)
                    domain['planner_id']=[('id','in',planner_list)]
                    return {'domain':domain}
                
    @api.multi
    @api.onchange('equipment_id')
    def to_get_supervisor_for_respective_selected_equipment(self):
        super_list=[]                    
        domain={}
        if self.equipment_id:
            preventive_equipment_object = self.env['cmms.equipment'].search([('id','=',self.equipment_id.id)])
            for instrument in preventive_equipment_object:
                if instrument.supervisor_ids:
                    for sid in instrument.supervisor_ids:
                        if sid:
                            super_list.append(sid.id)
                    domain['supervisor_id']=[('id','in',super_list)]
                    return {'domain':domain}
                
    @api.multi
    @api.onchange('equipment_id')
    def to_get_qa_user_for_respective_selected_instrument(self):
        qa_user_list=[]                    
        domain={}
        if self.equipment_id:
            preventive_equipment_object = self.env['cmms.equipment'].search([('id','=',self.equipment_id.id)])
            for instrument in preventive_equipment_object:
                if instrument.qa_user_ids:
                    for quid in instrument.qa_user_ids:
                        if quid:
                            qa_user_list.append(quid.id)
                    domain['qa_id']=[('id','in',qa_user_list)]
                    return {'domain':domain}
    
    @api.multi
    def assigned_calibration_order(self):
        for order in self:
            if not order.planner_id:
                raise UserError(_("Please Select Engineering Planner"))
            elif not order.technician_ids:
                raise UserError(_("Please Select Technician"))
            elif not order.business_id:
                raise UserError(_("Please Select Business User"))
            elif not order.qa_id:
                raise UserError(_("Please Select QA User"))
            elif not order.supervisor_id:
                raise UserError(_("Please Select Supervisor User"))
        return self.write({'order_status':'assign'})
    
class BreakdownRequestOrderLine(models.Model):
    _name           = 'bdms.maintenance_request.line'
    _description    = 'BDMS Maintenance Request Line'
    _order          = 'operation_no'
    
    bdms_order_id                   = fields.Many2one('bdms.maintenance_request.order')
    operation_no                    = fields.Char('Operation No',required=True, readonly=True, index=True, copy=False, default=lambda self: _('New'))
    operation_name                  = fields.Char('Operation Name')
    technician_id                   = fields.Many2one('res.users',string="Technician", domain=[('user_role','=',2)])
    start_date                      = fields.Datetime('Start Date Time',readonly=True,store=True)
    end_date                        = fields.Datetime('End Date Time',readonly=True,store=True)
    work_center                     = fields.Many2one('cmms.work.center',string="Work Center")    
    duration                        = fields.Float('Duration (Minutes)',readonly=True,store=True,compute='_compute_duration')
    remark                          = fields.Text('Remark')
    attachment_ids                  = fields.Many2many(comodel_name='ir.attachment',string="Attachment(s)")
    oprs_flag                       = fields.Char('Time Start and End Calculate',default="I")
    
    @api.multi
    def start_order(self):
        self.oprs_flag = 'S'
        self.start_date = datetime.now()
        
        
        
    @api.multi
    def end_order(self):
        self.oprs_flag = 'E'
        self.end_date = datetime.now()
        diff = fields.Datetime.from_string(self.end_date) - fields.Datetime.from_string(
                            self.start_date)
        print('diff',diff,'round',round(diff.total_seconds() / 60.0, 2))
        
        self.duration = round(diff.total_seconds() / 60.0, 2)
                        
   
class BreakdownMaterialConsumed(models.Model):
    _name           = 'bdms.maintenance_request.material_consumed'
    _description    = 'BDMS Maintenance Request Material Consumed'

    bdms_order_id                   = fields.Many2one('bdms.maintenance_request.order')
    bdms_request_id                 = fields.Many2one('bdms.maintenance_request.line',string="Operation ID")
    product_id                      = fields.Many2one('product.product',required=True,string='Product')
    quantity                        = fields.Float('Quantity')
    remarks                         = fields.Char('Remarks')
    company_id                      = fields.Many2one(comodel_name='res.company', string='Company / Plant',  store=True, related='bdms_order_id.company_id')
