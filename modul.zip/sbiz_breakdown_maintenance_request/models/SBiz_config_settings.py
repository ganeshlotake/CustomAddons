# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------------------------------#
#   Module Name:    SBiz_plant_maintenance                                                                       #
#   Description:    Collective Single Module for eCommerce related functionality                    #
#   File Name:      sbiz_config_settings.py (/models)                                               #
#   Purpose:        The model / classes to extend the Settings / Configurations for the eCom system #
#                   to accommodate addtional setting values that are needed for SBiz_ecom module    #
#   Author:         Jayant Bulbule                                                                  #
#   Date Created:   26-July-2020                                                                     #
#   Last Modified:  --/--/----                                                                      #
#   Last Mod. By:                                                                                   #
#---------------------------------------------------------------------------------------------------#

#---------------------------------------------------------------------------------------------------#
#                                   Modification History                                            #
#---------------------------------------------------------------------------------------------------#
#  Date        Modified By          Purpose                                           Change Mark   #
#  ----------  -------------------  -----------------------------------------------   ------------- #
#                                                                                                   #
#                                                                                                   #
#                                                                                                   #
#---------------------------------------------------------------------------------------------------#

from odoo import models, fields,api, _
import logging
from datetime import datetime,date,timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
_logger = logging.getLogger(__name__)


class ResConfigSettings(models.TransientModel):

    _inherit = 'res.config.settings'

    maintenance_calendar_start  = fields.Char(
        string='Maintenance Calendar Start Date', 
        config_parameter='maintenance.maintenance_calendar_start',
        placeholder='yyyy-mm-dd',
        help='Enter the Start Date for the Maintenance Calendar Year in your company.',
        required=True)
    maintenance_calendar_end    = fields.Char(
        string='Maintenance Calendar End Date', 
        config_parameter='maintenance.maintenance_calendar_end',
        placeholder='yyyy-mm-dd',
        help='Enter the Last Date for the Maintenance Calendar Year in your company.',
        required=True)
    a_setting_tol_from          = fields.Char(
        string='Tolerance From For Indicator A',
        config_parameter='maintenance.a_setting_tol_from',
        placeholder='Negative value',
        help='Enter the Negative value for the Equipment Indicator.',
        required=True,
        store=True)
    a_setting_tol_to            = fields.Char(
        string='Tolerance To For Indicator A',
        config_parameter='maintenance.a_setting_tol_to',
        placeholder='Poistive value',
        help='Enter the Positive value for the Equipment Indicator.',
        required=True,
        store=True
    )
    b_setting_tol_from          = fields.Char(
        string='Tolerance From For Indicator B',
        config_parameter='maintenance.b_setting_tol_from',
        placeholder='Negative value',
        help='Enter the Negative value for the Equipment Indicator.',
        required=True,
        store=True)
    b_setting_tol_to            = fields.Char(
        string='Tolerance To For Indicator B',
        config_parameter='maintenance.b_setting_tol_to',
        placeholder='Positive value',
        help='Enter the Positive value for the Equipment Indicator.',
        required=True,
        store=True)
    c_setting_tol_from          = fields.Char(
        string='Tolerance From For Indicator C',
        config_parameter='maintenance.c_setting_tol_from',
        placeholder='Negative value',
        help='Enter the Negative value for the Equipment Indicator.',
        required=True,
        store=True)
    c_setting_tol_to            = fields.Char(
        string='Tolerance To For Indicator C',
        config_parameter='maintenance.c_setting_tol_to',
        placeholder='Positive value',
        help='Enter the Positive value for the Equipment Indicator.',
        required=True,
        store=True)
    
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res.update(
            maintenance_calendar_start  = self.env['ir.config_parameter'].sudo().get_param('maintenance.maintenance_calendar_start'),
            maintenance_calendar_end    = self.env['ir.config_parameter'].sudo().get_param('maintenance.maintenance_calendar_end'),
            a_setting_tol_from          = self.env['ir.config_parameter'].sudo().get_param('maintenance.a_setting_tol_from'),
            a_setting_tol_to            = self.env['ir.config_parameter'].sudo().get_param('maintenance.a_setting_tol_to'),
            b_setting_tol_from          = self.env['ir.config_parameter'].sudo().get_param('maintenance.b_setting_tol_from'),
            b_setting_tol_to            = self.env['ir.config_parameter'].sudo().get_param('maintenance.b_setting_tol_to'),
            c_setting_tol_from          = self.env['ir.config_parameter'].sudo().get_param('maintenance.c_setting_tol_from'),
            c_setting_tol_to            = self.env['ir.config_parameter'].sudo().get_param('maintenance.c_setting_tol_to')
        )
        return res
    
    def set_values(self):
        super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param('maintenance.maintenance_calendar_start', self.maintenance_calendar_start)
        self.env['ir.config_parameter'].sudo().set_param('maintenance.maintenance_calendar_end',   self.maintenance_calendar_end)
        self.env['ir.config_parameter'].sudo().set_param('maintenance.a_setting_tol_from', self.a_setting_tol_from)
        self.env['ir.config_parameter'].sudo().set_param('maintenance.a_setting_tol_to', self.a_setting_tol_to)
        self.env['ir.config_parameter'].sudo().set_param('maintenance.b_setting_tol_from', self.b_setting_tol_from)
        self.env['ir.config_parameter'].sudo().set_param('maintenance.b_setting_tol_to', self.b_setting_tol_to)
        self.env['ir.config_parameter'].sudo().set_param('maintenance.c_setting_tol_from', self.c_setting_tol_from)
        self.env['ir.config_parameter'].sudo().set_param('maintenance.c_setting_tol_to', self.c_setting_tol_to)

    @api.onchange('a_setting_tol_to')
    def to_check_enter_value_aispositive(self):
        if self.a_setting_tol_to:
            if int(self.a_setting_tol_to) < 0 :
                raise UserError(_("Please Enter Positive Value"))


    @api.onchange('a_setting_tol_from')
    def to_check_enter_value_aisnegative(self):
        if self.a_setting_tol_from:
            if int(self.a_setting_tol_from) > 0 :
                raise UserError(_('Please Enter Negative Value'))

    @api.onchange('b_setting_tol_to')
    def to_check_enter_value_bispositive(self):
        if self.b_setting_tol_to:
            if int(self.b_setting_tol_to) < 0 :
                raise UserError(_("Please Enter Positive Value"))


    @api.onchange('b_setting_tol_from')
    def to_check_enter_value_bisnegative(self):
        if self.b_setting_tol_from:
            if int(self.b_setting_tol_from) > 0 :
                raise UserError(_('Please Enter Negative Value'))

    @api.onchange('c_setting_tol_to')
    def to_check_enter_value_cispositive(self):
        if self.c_setting_tol_to:
            if int(self.c_setting_tol_to) < 0 :
                raise UserError(_("Please Enter Positive Value"))


    @api.onchange('c_setting_tol_from')
    def to_check_enter_value_cisnegative(self):
        if self.c_setting_tol_from:
            if int(self.c_setting_tol_from) > 0 :
                raise UserError(_('Please Enter Negative Value'))