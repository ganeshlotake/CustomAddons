# -*- coding: utf-8 -*-

from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT


class BDMSMaintenanceRequest(models.Model):
    _name           = 'bdms.maintenance_request'
    _description    = 'Breakdown Maintenance Request'
    _order          = 'name'
    _inherit        = ['mail.thread', 'mail.activity.mixin']
    _rec_name       = 'request_no'

  

    request_no                      = fields.Char('Request No',readonly=True,store=True,index=True,copy=False,default=lambda self: _('New'))
    name                            = fields.Char('Short Description')
    requester_id                    = fields.Many2one('res.users',string="Production User",domain=[('user_role','=',3)], default=lambda s: s.env.uid) 
    equipment_id                    = fields.Many2one('cmms.equipment',string="Equipment",store=True,readonly=False)
    # equipment_abc_indicator         = fields.Selection(selection=[('a', 'A'), ('b', 'B'), ('c', 'C')],related="equipment_id.equipment_abc_indicator", string="ABC Indicator",required=True,store=True)
    requested_date                  = fields.Date('Requested Date', default=fields.Date.context_today)
    maintenance_type                = fields.Selection(selection=[('corrective','Corrective'),('breakdown','Breakdown')],default='corrective')   
    maintenance_team_id             = fields.Many2one(comodel_name='maintenance.team',string="Responsible Teams",required=True,store=True)
    supervisor_id                   = fields.Many2one('res.users',string="Supervisor", domain=[('user_role','=',5)], track_visibility='onchange')
    planner_id                      = fields.Many2one('res.users',string="Planner", domain=[('user_role','=',1)], track_visibility='onchange')
    technician_ids                  = fields.Many2many('res.users',string="Technician", domain=[('user_role','=',2)], track_visibility='onchange')
    business_head_id                = fields.Many2one('res.users',string="Business Head", domain=[('user_role','=',7)], track_visibility='onchange')
    qa_id                           = fields.Many2one('res.users',string="QA", domain=[('user_role','=',4)], track_visibility='onchange')
    cqa_id                          = fields.Many2one('res.users',string="CQA", domain=[('user_role','=',6)], track_visibility='onchange')
    saftyofficer_id                 = fields.Many2one('res.users',string="Safety Officer", domain=[('user_role','=',9)], track_visibility='onchange')
    state                           = fields.Selection(selection=[
                                        ('create', 'Create'),('assign','Assigned'),('start','Start'),
                                        ('pre_supervisorapprove', 'Pre-Approval Supervisor'),('pre_buheadapproved', 'Pre-Approval-BU Head')
                                        ,('pre_qaapproved', 'Pre-Approval-QA'),('in_process','In Process'),
                                        ('complete','Complete'),('post_supervisorapprove', 'Post-Approval Supervisor'),('post_buheadapproved', 'Post-Approval-BU Head')
                                        ,('post_qaapproved', 'Post-Approval-QA'),('post_soapproved', 'Post-Approval-SO'),('closed','Closed'),('reject', 'Rejected'),('unassign', 'Unassign')],
                                         string='State',default='create', track_visibility='onchange')
    order_created                   = fields.Selection(selection=[('created','Created'),('notcreated','Not Created')],default='notcreated')
    supervisor_approval             = fields.Selection(string="Supervisor Approval",selection=[('draft','Draft'),('approve','Approved'),('requested','Requested'),('reject','Rejected')],default='draft')
    bu_head_approval                = fields.Selection(string='BU Approval',selection=[('draft','Draft'),('approve','Approved'),('requested','Requested'),('reject','Rejected')],default='draft')
    qa_approval                     = fields.Selection(string='QA Approval',selection=[('draft','Draft'),('approve','Approved'),('requested','Requested'),('reject','Rejected')],default='draft')
    cqa_approval                    = fields.Selection(string='CQA Approval',selection=[('draft','Draft'),('approve','Approved'),('requested','Requested'),('reject','Rejected')],default='draft')
    saftyofficer_approval           = fields.Selection(string='CQA Approval',selection=[('draft','Draft'),('approve','Approved'),('requested','Requested'),('reject','Rejected')],default='draft')    
    rejected_remark                 = fields.Char('Remark')
    order_number                    = fields.Char('Order No')
    company_id                      = fields.Many2one('res.company',string="Company / Plant",related="equipment_id.company_id",store=True)
    description                     = fields.Html("Work Description")
    attachment_ids                  = fields.Many2many(comodel_name='ir.attachment')    
    material_consumed_ids           = fields.One2many('bdms.maintenance_request.material_consumed','bdms_order_id')    
    remark_id                       = fields.One2many(comodel_name='bdms.request.remark',inverse_name='request_id')
    barcode                         = fields.Char('Barcode',related="equipment_id.barcode",required=True,store=True)
    tag_id                          = fields.Char(string='Tag ID',related="equipment_id.tag_id",required=True,store=True)
    location_id                     = fields.Many2one('maintenance.location',related="equipment_id.location_id",string="Location",required=True,store=True)
    location                        = fields.Char(string="Functional Location",related="equipment_id.location",required=True,store=True)
    # tech_comment                    = fields.Html("Technician Comments")
    
    #can_be_used                     = fields.Boolean('Can Be Used')
    safety_clearance                = fields.Boolean(string="Safety Clearance taken")
    production_clearance            = fields.Boolean(string="Business Head Clearance Taken")
    electrical_clearance            = fields.Boolean(string="Supervisor Clearance Taken") 
    maintenance_request_line_ids    = fields.One2many('bdms.maintenance_request.line','request_id')
    
    @api.multi
    def _get_default_userole_plan(self):
        res_obj = self.env['res.users'].search([('id','=',self.env.uid)])
        if res_obj:
            if res_obj.user_role.id == 2 or res_obj.user_role.id == 3 or res_obj.user_role.id == 4 :
                self.access_field_plan = False
            else:
                self.access_field_plan = True
    access_field_plan               = fields.Boolean(string="Access Field Plan",compute='_get_default_userole_plan')

    @api.multi
    def _get_default_userole_bu(self):
        res_obj = self.env['res.users'].search([('id','=',self.env.uid)])
        if res_obj:
            if res_obj.user_role.id == 1 or res_obj.user_role.id == 2 or res_obj.user_role.id == 4 :
                self.access_field_bu = False
            else:
                self.access_field_bu = True
    access_field_bu               = fields.Boolean(string="Access Field Bu",compute='_get_default_userole_bu')

    @api.multi
    def _get_default_userole_tech(self):
        res_obj = self.env['res.users'].search([('id','=',self.env.uid)])
        if res_obj:
            if res_obj.user_role.id == 1 or res_obj.user_role.id == 3 or res_obj.user_role.id == 4 :
                self.access_field_bu = False
            else:
                self.access_field_bu = True
    access_field_tech              = fields.Boolean(string="Access Field Tech",compute='_get_default_userole_tech')

    @api.multi
    def assign_wizard(self):
        
        view_id = self.env.ref('sbiz_breakdown_maintenance_request.bdms_request_order_remark_action').view_id        
        return {
        'name'     : _('Breakdown Reqeust Order Remark'),
        'type'     : 'ir.actions.act_window',
        'view_type': 'form',
        'view_mode': 'form',
        'res_model': 'bdms.request.remark',       
        'view_id'  : view_id.id,
        'target'   : 'new',           
        'context'  : {'default_request_id': self.id,'default_technician_id': self.technician_ids[0].id if self.technician_ids else False}, 
        }


    @api.model
    def create(self, vals):
        if 'equipment_id' in vals:                         
            if vals.get('request_no', _('New')) == _('New'):
                strno = self.env['ir.sequence'].next_by_code('bdms.maintenance_request') or _('New')
                if vals['maintenance_type']=='corrective':
                    vals['request_no'] = strno.replace('X','C')
                else:
                    vals['request_no'] = strno.replace('X','B')
            result = super(BDMSMaintenanceRequest, self).create(vals)     
            return result

    @api.multi
    def get_remark(self):
        my_remark = ''
        if self:
            if self.rejected_remark:
                my_remark = self.rejected_remark
            else:
                my_remark = ''
        return my_remark
        
    @api.multi
    @api.onchange('equipment_id')
    def to_get_planner_for_respective_selected_equipment(self):
        planner_list=[]
        main_team_list=[]
        buhead_list=[]
        qa_list=[]
        cqa_list=[]
        so_list=[]
        sv_list=[]
        domain={}
        if self.equipment_id:
            cmms_equipment_object = self.env['cmms.equipment'].search([('id','=',self.equipment_id.id)])
            for instrument in cmms_equipment_object:
                if instrument.planner_ids:
                    for planner in instrument.planner_ids:
                        if planner:
                            planner_list.append(planner.id)
                    self.planner_id = planner_list[0]
                    domain['planner_id']=[('id','in',planner_list)]

                if instrument.maintenance_team_ids:
                    for team in instrument.maintenance_team_ids:
                        if team:
                            main_team_list.append(team.id)
                    self.maintenance_team_id = main_team_list[0]
                    domain['maintenance_team_id']=[('id','in',main_team_list)]
     
                if instrument.business_head_ids:
                    for buh in instrument.business_head_ids:
                        if buh:
                            buhead_list.append(buh.id)
                    self.business_head_id = buhead_list[0]
                    domain['business_head_id']=[('id','in',buhead_list)]

                if instrument.qa_user_ids:
                    for qa in instrument.qa_user_ids:
                        if qa:
                            qa_list.append(qa.id)
                    self.qa_id = qa_list[0]
                    domain['qa_id']=[('id','in',qa_list)]
                
                if instrument.cqa_ids:
                    for cqa in instrument.cqa_ids:
                        if cqa:
                            cqa_list.append(cqa.id)
                    self.cqa_id = cqa_list[0]
                    domain['cqa_id']=[('id','in',cqa_list)]

                if instrument.saftyofficer_ids:
                    for so in instrument.saftyofficer_ids:
                        if so:
                            so_list.append(so.id)
                    self.saftyofficer_id = so_list[0]
                    domain['saftyofficer_id']=[('id','in',so_list)]

                if instrument.supervisor_ids:
                    for sv in instrument.supervisor_ids:
                        if sv:
                            sv_list.append(sv.id)
                    self.supervisor_id = sv_list[0]
                    domain['supervisor_id']=[('id','in',sv_list)]

                    return {'domain':domain} 
    @api.model
    def schedule_form_action(self, values):
        active_id = values
        context = self.env.context
        return {
                'name': _('Schedule Edit Form'),
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'preventive.schedule',
                'res_id': active_id[0],
                'context': context,
                'view_id': self.env.ref('sbiz_preventive_maintenance.preventive_schedule_editing_form').id,
                'type': 'ir.actions.act_window',
                'target':'new'
            }

    @api.multi
    def unlink(self):
        if self.env.uid > 2:
            raise UserError(_('You are not authorized to delete the records from Breakdown Request. Please contact System Administrator.'))
        res = super(BDMSMaintenanceRequest, self).unlink()
        return res
    
    @api.multi
    def copy(self):
        if self.env.uid > 2:
            raise ValidationError('You are not authorized to duplicate the records from Breakdown Request. Please contact System Administrator.')
 
    
    @api.multi
    def get_base_url(self):
        """When using multi-website, we want the user to be redirected to the
        most appropriate website if possible."""
        base_url =  self.env['ir.config_parameter'].sudo().get_param('web.base.url')        
        return base_url

    @api.multi
    def get_tech(self):
        if self.technician_ids:
            tech = self.technician_ids[0].name
        
        return tech

    @api.multi
    def get_tech_log(self):
        if self.technician_ids:
            techlog = self.technician_ids[0].login
        
        return techlog

    @api.multi
    def get_status(self):

        my_status =''
        if self:
            if self.state == 'create':
                my_status = 'Create'            
            elif self.state == 'assign':
                my_status = 'Assign'
            elif self.state == 'start':
                my_status = 'Start'           
            elif self.state == 'pre_supervisorapprove':
                my_status = 'Pre-Approval Supervisor'
            elif self.state == 'pre_buheadapproved':
                my_status = 'Pre-Approval-BU Head'
            elif self.state == 'pre_qaapproved':
                my_status = 'Pre-Approval-QA'            
            elif self.state == 'in_process':
                my_status = 'In-Process'
            elif self.state == 'complete':
                my_status = 'Complete'
            elif self.state == 'post_supervisorapprove':
                my_status = 'Post-Approval Supervisor'
            elif self.state == 'post_buheadapproved':
                my_status = 'Post-Approval-BU Head'
            elif self.state == 'post_qaapproved':
                my_status = 'Post-Approval-QA'
            elif self.state == 'post_soapproved':
                my_status = 'Post-Approval-SO'
            elif self.state == 'closed':
                my_status = 'Closed'
            elif self.state == 'reject':
                my_status = 'Rejected'
            elif self.state == 'unassign':
                my_status = 'Un-Assign'
        return my_status

class BreakdownTechnicianRemark(models.Model):
    _name           = 'bdms.maintenance_request.line'
    _description    = 'Breakdown Maintenance Request line'

    request_id        = fields.Many2one('bdms.maintenance_request')   
    req_date          = fields.Datetime('Date',required=True,default=datetime.now())   
    task              = fields.Char('Task')
    task_desc         = fields.Char('Task Description')
    technician_id     = fields.Many2one('res.users',string="Technician", domain=[('user_role','=',2)], default=lambda s: s.env.uid, track_visibility='onchange')
    maintenance_team_id  = fields.Many2one(comodel_name='maintenance.team',string="Responsible Teams",required=True,store=True)
    status            = fields.Selection(selection=[('completed','Completed'),('notcompleted','Not Completed')],default='notcompleted')  
    company_id        = fields.Many2one(comodel_name='res.company', string='Company / Plant',  store=True, related='request_id.company_id')


        
 
class BreakdownMaterialConsumed(models.Model):
    _name           = 'bdms.maintenance_request.material_consumed'
    _description    = 'Breakdown Maintenance Request Material Consumed'

    bdms_order_id                   = fields.Many2one('bdms.maintenance_request')   
    product_id                      = fields.Many2one('product.product',required=True,string='Material Description')
    quantity                        = fields.Float('Quantity Requested')
    material_code                   = fields.Char('Material Code',related="product_id.default_code",store=True,readonly=False)
    uom                             = fields.Many2one(string='Unit of Measurment',related="product_id.product_tmpl_id.uom_id",store=True,readonly=False)
    remarks                         = fields.Char('Remarks')
    company_id                      = fields.Many2one(comodel_name='res.company', string='Company / Plant',  store=True, related='bdms_order_id.company_id')

    @api.model
    def create(self,vals):
        if 'quantity' in vals:
            if vals['quantity']==0:
                raise ValidationError('Quantity must be greater then 0')
        res = super(BreakdownMaterialConsumed,self).create(vals)
        return res
    
    @api.onchange('material_code')
    def material_code_onchange(self):
        if self.material_code:
            product_obj = self.env['product.product'].search([('default_code','=',self.material_code)])
            if product_obj:
                self.product_id = product_obj.id
            else:
                raise ValidationError('Product not found')
                
