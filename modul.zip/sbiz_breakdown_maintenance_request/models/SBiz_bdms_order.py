# -*- coding: utf-8 -*-

from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT

#Added by ajinkya joshi on 25-07-2020
class BreakdownOrder(models.Model):
    _name           = 'bdms.order'
    _description    = 'Breakdown Maintenance Order'
    _order          = 'order_no'
    _rec_name       = 'order_no'
    _inherit        = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    
    order_no                        = fields.Char('Order No',required=True, readonly=True, index=True, copy=False, default=lambda self: _('New'))
    order_date                      = fields.Date('Order Date')
    order_description               = fields.Text('Order Description')
    equipment_id                    = fields.Many2one('cmms.equipment',string="Equipment")
    tag_id                          = fields.Char('Tag ID')
    location_id                     = fields.Many2one('maintenance.location',string="Location",related="equipment_id.location_id",required=True,store=True)
    location                        = fields.Char(string="Functional Location",related="equipment_id.location",required=True,store=True)
    area                            = fields.Char('Area')
    due_date                        = fields.Date('Due Date')
    final_date                      = fields.Date('Final Date')
    clearance_date                  = fields.Datetime('Clearance Date')
    actual_completion_date          = fields.Date('Actual Completion Date')
    bdms_line                       = fields.One2many('bdms.order.line','bdms_order_id')
    supervisor_id                   = fields.Many2one('res.users',string="Supervisor", domain=[('user_role','=',5)], track_visibility='onchange')
    planner_id                      = fields.Many2one('res.users',string="Planner", domain=[('user_role','=',1)], track_visibility='onchange')
    technician_ids                  = fields.Many2many('res.users',string="Technician", domain=[('user_role','=',2)], track_visibility='onchange')
    business_id                     = fields.Many2one('res.users',string="Business", domain=[('user_role','=',3)], track_visibility='onchange')
    business_head_id                = fields.Many2one('res.users',string="Business Head", domain=[('user_role','=',7)], track_visibility='onchange')
    qa_id                           = fields.Many2one('res.users',string="QA", domain=[('user_role','=',4)], track_visibility='onchange')
    cqa_id                           = fields.Many2one('res.users',string="CQA", domain=[('user_role','=',6)], track_visibility='onchange')
    saftyofficer_id                 = fields.Many2one('res.users',string="Safty Officer", domain=[('user_role','=',9)], track_visibility='onchange')
    attachment_ids                  = fields.Many2many(comodel_name='ir.attachment')    
    material_consumed_ids           = fields.One2many('bdms.material_consumed','bdms_order_id')
    env_condition                   = fields.Char('Environmental Condition')
    humidity                        = fields.Char('Humidity')
    other_remarks                   = fields.Char('Other Remarks')
    company_id                      = fields.Many2one('res.company',string="Company")
    bdms_frequency                  = fields.Integer(related='equipment_id.frequency',string="Frequency",store=True)
    bdms_frequency_type             = fields.Selection(related='equipment_id.frequency_type',string="Frequency Type",store=True)
    negative_tolerance              = fields.Float(related='equipment_id.negative_tolerance',string="Tolerance Range From",store=True)
    positive_tolerance              = fields.Float(related='equipment_id.positive_tolerance',store=True,string='Tolerance Range To')
    abc_indicator                   = fields.Selection(related='equipment_id.equipment_abc_indicator',store=True ,string='ABC Indicator')
    remark_id                       = fields.One2many(comodel_name='bdms.order.remark',inverse_name='order_id')
    can_be_used                     = fields.Boolean('Can Be Used')
    order_type                      = fields.Selection(string='Order Type', selection=[('manual', 'Manual'), ('auto', 'Auto-Generated')], store=True, default='manual')
    order_status                    = fields.Selection(selection=[
                                        ('create', 'Create'),('assign','Assigned'),('start','Start'),
                                        ('pre_supervisorapprove', 'Pre-Approval Supervisor'),('pre_buheadapproved', 'Pre-Approval-BU Head')
                                        ,('pre_qaapproved', 'Pre-Approval-QA'),('in_process','In Process'),
                                        ('complete','Complete'),('post_supervisorapprove', 'Post-Approval Supervisor'),('post_buheadapproved', 'Post-Approval-BU Head')
                                        ,('post_qaapproved', 'Post-Approval-QA'),('post_soapproved', 'Post-Approval-SO'),('closed','Closed'),('reject', 'Rejected'),('unassign', 'Unassign')],
                                         string='State',default='create', track_visibility='onchange')
    order_success                   = fields.Boolean(string='Checklist Success', default=True)
    ambient_temp                    = fields.Char('Ambient Temp')
    instrument_description          = fields.Text(string='Instrument Description')
    safety_clearance                = fields.Boolean(string="Safety Clearance taken")
    production_clearance            = fields.Boolean(string="Production Clearance Taken")
    electrical_clearance            = fields.Boolean(string="Electrical Clearance Taken") 

    @api.multi
    def _get_default_userole_plan(self):
        res_obj = self.env['res.users'].search([('id','=',self.env.uid)])
        if res_obj:
            if res_obj.user_role.id == 2 or res_obj.user_role.id == 3 or res_obj.user_role.id == 4 :
                self.access_field_plan = False
            else:
                self.access_field_plan = True
    access_field_plan               = fields.Boolean(string="Access Field Plan",compute='_get_default_userole_plan')
    
    @api.multi
    def _get_default_userole(self):
        res_obj = self.env['res.users'].search([('id','=',self.env.uid)])
        if res_obj:
            if res_obj.user_role.id == 1 or res_obj.user_role.id == 3 or res_obj.user_role.id == 4 :
                self.access_field_tech = False
            else:
                self.access_field_tech = True
    access_field_tech               = fields.Boolean(string="Access Field Tech",compute='_get_default_userole')
    
    @api.model
    def create(self, vals):
        if vals.get('order_no', _('New')) == _('New'):
            vals['order_no'] = self.env['ir.sequence'].next_by_code('bdms.order') or _('New')
        result = super(BreakdownOrder, self).create(vals)
        return result

    @api.multi
    def assign_wizard(self):
       
        view_id = self.env.ref('sbiz_breakdown_maintenance_request.breakdown_request_order_remark_action').view_id        
        return {
        'name'     : _('Breakdown Reqeust Order Remark'),
        'type'     : 'ir.actions.act_window',
        'view_type': 'form',
        'view_mode': 'form',
        'res_model': 'bdms.order.remark',
       
        'view_id'  : view_id.id,
        'target'   : 'new',           
        'context'  : {'default_order_id': self.id,'default_technician_id': self.technician_ids[0].id if self.technician_ids else False}, 
        }

    @api.multi
    def get_tech(self):
        if self.technician_ids:
            tech = self.technician_ids[0].name
        
        return tech
        
    @api.multi
    def get_tech_log(self):
        if self.technician_ids:
            techlog = self.technician_ids[0].login
        
        return techlog

    @api.multi
    def get_status(self):
        my_status =''
        if self:
            if self.order_status == 'create':
                my_status = 'Create'            
            elif self.order_status == 'assign':
                my_status = 'Assign'
            elif self.order_status == 'start':
                my_status = 'Start'           
            elif self.order_status == 'pre_supervisorapprove':
                my_status = 'Pre-Approval Supervisor'
            elif self.order_status == 'pre_buheadapproved':
                my_status = 'Pre-Approval-BU Head'
            elif self.order_status == 'pre_qaapproved':
                my_status = 'Pre-Approval-QA'            
            elif self.order_status == 'in_process':
                my_status = 'In-Process'
            elif self.order_status == 'complete':
                my_status = 'Complete'
            elif self.order_status == 'post_supervisorapprove':
                my_status = 'Post-Approval Supervisor'
            elif self.order_status == 'post_buheadapproved':
                my_status = 'Post-Approval-BU Head'
            elif self.order_status == 'post_qaapproved':
                my_status = 'Post-Approval-QA'
            elif self.order_status == 'post_soapproved':
                my_status = 'Post-Approval-SO'
            elif self.order_status == 'closed':
                my_status = 'Closed'
            elif self.order_status == 'reject':
                my_status = 'Rejected'
            elif self.order_status == 'unassign':
                my_status = 'Un-Assign'
        return my_status
   
    
    @api.multi
    def copy(self):
        if self.env.uid > 2:
            raise ValidationError('You are not authorized to deplicate the records from Calibration Order. Please contact System Administrator.')
        
    @api.multi
    def unlink(self):
        if self.env.uid > 2:
            raise UserError(_('You are not authorized to delete the records from Calibration Orders. Please contact System Administrator.'))
        res = super(BreakdownOrder, self).unlink()
        return res
    
    
    @api.multi
    def get_base_url(self):
        base = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        return base

    @api.onchange('final_date')
    def validate_final_date(self):
        if self.final_date < self.from_date or self.final_date > self.to_date:
            raise UserError(_('The Final Date Must be between From and To dates'))
        
    @api.multi
    @api.onchange('equipment_id')
    def to_get_business_user_for_respective_selected_equipment(self):
        bu_user_list=[]                    
        domain={}
        if self.equipment_id:
            preventive_equipment_object = self.env['cmms.equipment'].search([('id','=',self.equipment_id.id)])
            for instrument in preventive_equipment_object:
                if instrument.business_user_ids:
                    for buid in instrument.business_user_ids:
                        if buid:
                            bu_user_list.append(buid.id)
                    domain['business_id']=[('id','in',bu_user_list)]
                    return {'domain':domain}
        
        
    @api.multi
    @api.onchange('equipment_id')
    def to_get_technician_for_respective_selected_equipment(self):
        technician_list=[]                    
        domain={}
        if self.equipment_id:
            preventive_equipment_object = self.env['cmms.equipment'].search([('id','=',self.equipment_id.id)])
            for instrument in preventive_equipment_object:
                if instrument.technician_ids:
                    for tid in instrument.technician_ids:
                        if tid:
                            technician_list.append(tid.id)
                    domain['technician_ids']=[('id','in',technician_list)]
                    return {'domain':domain}
                
    @api.multi
    @api.onchange('equipment_id')
    def to_get_planner_for_respective_selected_equipment(self):
        planner_list=[]                    
        domain={}
        if self.equipment_id:
            preventive_equipment_object = self.env['cmms.equipment'].search([('id','=',self.equipment_id.id)])
            for instrument in preventive_equipment_object:
                if instrument.planner_ids:
                    for pid in instrument.planner_ids:
                        if pid:
                            planner_list.append(pid.id)
                    domain['planner_id']=[('id','in',planner_list)]
                    return {'domain':domain}
                
    @api.multi
    @api.onchange('equipment_id')
    def to_get_supervisor_for_respective_selected_equipment(self):
        super_list=[]                    
        domain={}
        if self.equipment_id:
            preventive_equipment_object = self.env['cmms.equipment'].search([('id','=',self.equipment_id.id)])
            for instrument in preventive_equipment_object:
                if instrument.supervisor_ids:
                    for sid in instrument.supervisor_ids:
                        if sid:
                            super_list.append(sid.id)
                    domain['supervisor_id']=[('id','in',super_list)]
                    return {'domain':domain}
                
    @api.multi
    @api.onchange('equipment_id')
    def to_get_qa_user_for_respective_selected_instrument(self):
        qa_user_list=[]                    
        domain={}
        if self.equipment_id:
            preventive_equipment_object = self.env['cmms.equipment'].search([('id','=',self.equipment_id.id)])
            for instrument in preventive_equipment_object:
                if instrument.qa_user_ids:
                    for quid in instrument.qa_user_ids:
                        if quid:
                            qa_user_list.append(quid.id)
                    domain['qa_id']=[('id','in',qa_user_list)]
                    return {'domain':domain}
    
    @api.multi
    def assigned_calibration_order(self):
        for order in self:
            if not order.planner_id:
                raise UserError(_("Please Select Engineering Planner"))
            elif not order.technician_ids:
                raise UserError(_("Please Select Technician"))
            elif not order.business_id:
                raise UserError(_("Please Select Business User"))
            elif not order.qa_id:
                raise UserError(_("Please Select QA User"))
            elif not order.supervisor_id:
                raise UserError(_("Please Select Supervisor User"))
        return self.write({'order_status':'assign'})
    
class BreakdownOrderLine(models.Model):
    _name           = 'bdms.order.line'
    _description    = 'Breakdown Order Line'
    _order          = 'operation_no'
    _rec_name       = 'operation_no'
    
    bdms_order_id                   = fields.Many2one('bdms.order')
    operation_no                    = fields.Char('Operation No',required=True, readonly=True, index=True, copy=False, default=lambda self: _('New'))
    operation_name                  = fields.Char('Operation Name')
    technician_id                   = fields.Many2one('res.users',string="Technician", domain=[('user_role','=',2)], default=lambda s: s.env.uid,)
    start_date                      = fields.Datetime('Start Date Time',readonly=True,store=True)
    end_date                        = fields.Datetime('End Date Time',readonly=True,store=True)
    work_center                     = fields.Many2one('cmms.work.center',string="Work Center")    
    duration                        = fields.Float('Duration (Minutes)',readonly=True,store=True,compute='_compute_duration')
    remark                          = fields.Text('Remark')
    attachment_ids                  = fields.Many2many(comodel_name='ir.attachment',string="Attachment(s)")
    oprs_flag                       = fields.Char('Time Start and End Calculate',default="I")
    material_consumed_ids           = fields.One2many('bdms.material_consumed','bdms_request_id')
    
    @api.multi
    def start_order(self):
        self.oprs_flag = 'S'
        self.start_date = datetime.now()       
        
        
    @api.multi
    def end_order(self):
        self.oprs_flag = 'E'
        self.end_date = datetime.now()
        diff = fields.Datetime.from_string(self.end_date) - fields.Datetime.from_string(
                            self.start_date)
        #print('diff',diff,'round',round(diff.total_seconds() / 60.0, 2))
        
        self.duration = round(diff.total_seconds() / 60.0, 2)
    
    @api.model
    def create(self,vals):
        if vals.get('operation_no', _('New')) == _('New'):
            order_line_no = self.env['ir.sequence'].next_by_code('bdms.order.line')
            order_id = self.env['bdms.order'].search([('id','=',vals['bdms_order_id'])])            
            seq = order_line_no.replace('X',order_id.order_no)
            #seq1 = seq[:-5]
            vals['operation_no'] = seq
        res =super(BreakdownOrderLine,self).create(vals)
        return res 


class CmmsWorkCenter(models.Model):
    _name           = 'cmms.work.center'
    _description    = 'CMMS Work Center'
    _order          = 'center_name'
    rec_name        = 'center_name'
    
    
    center_name                     = fields.Char('Work Center Name',)
    time_efficiency                 = fields.Float('Time Efficiency')
    capacity                        = fields.Float('Capacity')
    time_before_prod                = fields.Float('Time before prod.')
    time_after_prod                 = fields.Float('Time after prod.')
    
    
class BreakdownMaterialConsumed(models.Model):
    _name           = 'bdms.material_consumed'
    _description    = 'Breakdown Order Material Consumed'

    bdms_order_id                   = fields.Many2one('bdms.order')
    bdms_request_id                 = fields.Many2one('bdms.order.line',required=True,string='Material Description')
    product_id                      = fields.Many2one('product.product',required=True,string='Product')
    quantity                        = fields.Float('Quantity Requested')
    material_code                   = fields.Char('Material Code',related="product_id.default_code",store=True,readonly=False)
    uom                             = fields.Many2one(string='Unit of Measurment',related="product_id.product_tmpl_id.uom_id",store=True,readonly=False)
    remarks                         = fields.Char('Remarks')
    company_id                      = fields.Many2one(comodel_name='res.company', string='Company / Plant',  store=True, related='bdms_order_id.company_id')

    @api.model
    def create(self,vals):
        if 'quantity' in vals:
            if vals['quantity']==0:
                raise ValidationError('Quantity must be greater then 0')
        res = super(BreakdownMaterialConsumed,self).create(vals)
        return res
    
    @api.onchange('material_code')
    def material_code_onchange(self):
        if self.material_code:
            product_obj = self.env['product.product'].search([('default_code','=',self.material_code)])
            if product_obj:
                self.product_id = product_obj.id
            else:
                raise ValidationError('Product not found')
                